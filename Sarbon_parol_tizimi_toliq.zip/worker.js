// + Verifikatsiya/Badge/Sharh moduli (D1 "DB" binding, ADMIN_BOT_TOKEN, ADMIN_IDS, PASSPORT_HMAC_KEY, DOC_KEY)
// Sarbon Worker v6 (+Google kirish) — hamma boshqaruv Telegram botdan, tugmalar bilan.
// Cloudflare sozlamalari (o'zgarmagan): BOT_TOKEN, CHAT_ID, WEBHOOK_SECRET, CUSTOMER_BOT_TOKEN (Secret),
//   ALLOWED_ORIGIN (Text) = https://sarbonuz.github.io, PRODUCTS (KV binding)

const FIRST_ORDERS = 2; // "birinchi buyurtmalar" chegirmasi va SARBON10 shuncha buyurtmaga amal qiladi
const DEFAULT_SETTINGS = { rate: 1750, usd: 12800, markup: 40, cargoAuto: 6, cargoAvia: 9, hideStatic: false, promos: { SARBON10: 10 } };
const CATEGORIES = [
  ["gadjet", "Gadjet"], ["kompyuter", "Kompyuter"], ["bolalar", "Bolalar"], ["kiyim", "Kiyim"],
  ["uy", "Uy-ro'zg'or"], ["gozal", "Go'zallik"], ["sport", "Sport"], ["avto", "Avto"],
];
const catName = (k) => (CATEGORIES.find((c) => c[0] === k) || [k, k || "—"])[1];
const BG = ["#E8E3F5", "#DCE3FA", "#FADDE6", "#FBEFD0", "#DDF1DC", "#D5F0EE"];
const STATUSES = {
  tasdiqlandi: "✅ Tasdiqlandi", yolda: "🚚 Cargo yo'lda", uzb: "🇺🇿 O'zbekistonga yetdi",
  uzpost: "📮 UzPostga topshirildi", yetkazildi: "📦 Filialga yetdi", topshirildi: "🎁 Buyurtma mijozga topshirildi", bekor: "❌ Bekor",
};
const MIME = { jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif", mp4: "video/mp4", mov: "video/quicktime", webm: "video/webm", m4v: "video/mp4" };
const SZ = {
  L: ["XS", "S", "M", "L", "XL", "XXL", "3XL"],
  N: ["36", "37", "38", "39", "40", "41", "42", "43", "44", "45"],
  K: ["26", "27", "28", "29", "30", "31", "32", "33", "34", "35"],
};
const SZN = { L: "👕 Harf", N: "👟 36–45", K: "🧒 26–35" };
const COLOR_PRESET = ["Qora", "Oq", "Kulrang", "Qizil", "Ko'k", "Havorang", "Yashil", "Sariq", "Pushti", "Binafsha", "Jigarrang", "Bej"];
const KG = ["0.1", "0.2", "0.3", "0.5", "0.8", "1", "1.5", "2", "3", "5", "8", "10"];

const NEXT = { yangi: "tasdiqlandi", tasdiqlandi: "yolda", yolda: "uzb", uzb: "uzpost", uzpost: "yetkazildi", yetkazildi: "topshirildi" };
const ST_SHORT = { yangi: "🆕 Yangi", tasdiqlandi: "✅ Tasdiq.", yolda: "🚚 Yo'lda", uzb: "🇺🇿 O'zbek.", uzpost: "📮 UzPost", yetkazildi: "📦 Filial", topshirildi: "🎁 Topshirildi", bekor: "❌ Bekor" };
const ST_BTN = { tasdiqlandi: "✅ Tasdiqlandi", yolda: "🚚 Yo'lda", uzb: "🇺🇿 O'zbekistonga yetdi", uzpost: "📮 UzPostda", yetkazildi: "📦 Filialga yetdi", topshirildi: "🎁 Buyurtma topshirildi", bekor: "❌ Bekor" };
// Ixcham tugmalar: faqat keyingi qadam + bekor. "Boshqa holat" bosilsa hammasi ochiladi.
const statusRows = (id, status, ctx) => {
  const st = status || "yangi", c = ctx ? ":" + ctx : "", rows = [], first = [];
  if (NEXT[st]) first.push(btn(ST_BTN[NEXT[st]], "os:" + id + ":" + NEXT[st] + c));
  if (st !== "bekor" && st !== "yetkazildi" && st !== "topshirildi") first.push(btn("❌ Bekor", "os:" + id + ":bekor" + c));
  if (first.length) rows.push(first);
  rows.push([btn("📦 Trek kod", "tk:" + id), btn("💬 Chat", "ch:" + id)]);
  rows.push([btn("⚙️ Boshqa holat", "om:" + id + c)]);
  return rows;
};
const statusRowsFull = (id, ctx) => {
  const c = ctx ? ":" + ctx : "";
  return [
    [btn(ST_BTN.tasdiqlandi, "os:" + id + ":tasdiqlandi" + c), btn(ST_BTN.yolda, "os:" + id + ":yolda" + c)],
    [btn(ST_BTN.uzb, "os:" + id + ":uzb" + c), btn(ST_BTN.uzpost, "os:" + id + ":uzpost" + c)],
    [btn(ST_BTN.yetkazildi, "os:" + id + ":yetkazildi" + c), btn(ST_BTN.bekor, "os:" + id + ":bekor" + c)],
    [btn(ST_BTN.topshirildi, "os:" + id + ":topshirildi" + c)],
    [btn("⬅️ Orqaga", "oc:" + id + c)],
  ];
};

const clean = (v, max) => String(v == null ? "" : v).replace(/[<>]/g, "").slice(0, max);
const h = (s) => String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const money = (n) => Math.round(Number(n) || 0).toLocaleString("en-US").replace(/,/g, " ") + " so'm";
const splitList = (v) => String(v || "").split(/[,;\n]/).map((x) => x.trim()).filter(Boolean);
const chunk = (a, n) => { const r = []; for (let i = 0; i < a.length; i += n) r.push(a.slice(i, i + n)); return r; };
const parsePrice = (t) => {
  t = String(t).toLowerCase().replace(/\s/g, "").replace(/so'?m|sum/g, "");
  let m = 1;
  if (/(k|ming)$/.test(t)) { m = 1000; t = t.replace(/(k|ming)$/, ""); }
  else if (/(mln|m)$/.test(t)) { m = 1e6; t = t.replace(/(mln|m)$/, ""); }
  if (m > 1) { const v = parseFloat(t.replace(",", ".")); return isFinite(v) ? Math.round(v * m) : 0; }
  return Number(t.replace(/[^\d]/g, "")) || 0;
};
const parseKg = (t) => { const v = parseFloat(String(t).replace(",", ".")); return v > 0 && v <= 100 ? v : 0; };
const json = (obj, status, origin, cc) => {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, X-Token, X-Admin", "Access-Control-Max-Age": "86400", "Vary": "Origin", "Cache-Control": cc || "no-store" };
  if (status === 204) return new Response(null, { status: 204, headers: headers });
  return new Response(typeof obj === "string" ? obj : JSON.stringify(obj), { status: status || 200, headers: headers });
};

// ---------- KATTA KAMPANIYA UCHUN YORDAMCHILAR ----------
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// KV bitta kalitga sekundiga 1 marta yozishga ruxsat beradi; band bo'lsa qayta urinadi
async function kvPut(env, key, val, opts) {
  for (let i = 0; ; i++) {
    try { return await env.PRODUCTS.put(key, val, opts); }
    catch (e) { if (i >= 3) throw e; await sleep(350 * (i + 1) + Math.random() * 400); }
  }
}
// Worker xotirasida qisqa muddatli kesh: KV o'qishlari va CPU tejaladi
const MEMO = new Map();
async function memo(key, ttl, fn) {
  const e = MEMO.get(key), now = Date.now();
  if (e && now < e.x) return e.v;
  const v = await fn();
  if (v !== "" && v != null) MEMO.set(key, { v: v, x: now + ttl });
  return v;
}
// Token: avval X-Token headerdan, bo'lmasa eski usul (?token=) dan o'qiladi
const tokenOf = (request, url) => request.headers.get("X-Token") || url.searchParams.get("token") || "";
const num = (v) => { v = Number(v); return isFinite(v) && v >= 0 && v < 1e10 ? Math.round(v) : 0; };
// Tana hajmini cheklab o'qiydi (juda katta so'rovlar bilan to'ldirib yuborishdan himoya)
async function readJson(request, max) {
  const cl = Number(request.headers.get("Content-Length") || 0);
  if (cl > max) return null;
  try {
    const t = await request.text();
    if (t.length > max) return null;
    return JSON.parse(t);
  } catch (e) { return null; }
}
// IP bo'yicha tezlik limiti (har bir Worker nusxasi ichida). Mobil operatorlarda bir IP ostida ko'p odam bo'lgani uchun limitlar keng qilingan.
const RATE_MEM = new Map();
function rateRule(m, p) {
  if (p === "/verify-webhook" || p === "/setup-verify" || p.startsWith("/admin") || p.startsWith("/api/admin/")) return null;
  if (p.startsWith("/verify/") || p.startsWith("/badge/") || p.startsWith("/review/")) return ["ver", 40];
  if (p === "/webhook" || p === "/customer-webhook" || p === "/ping" || p === "/setup" || p === "/setup-customer" || p === "/push-keygen") return null;
  if (m === "POST") {
    if (p === "/password-login") return ["pwlogin", 10];
    if (p === "/password-reset-request" || p === "/password-reset-confirm") return ["pwreset", 6];
    if (p === "/password-set") return ["pwset", 10];
    if (p === "/google-login" || p === "/google-phone" || p === "/login-exchange" || p === "/tg-login" || p === "/google-cb") return ["g", 20];
    if (p === "/chat-send") return ["chat", 30];
    if (p === "/profile") return ["prof", 20];
    if (p === "/ref-claim" || p === "/push-sub" || p === "/logout") return ["misc", 20];
    return ["order", 12];
  }
  if (p === "/login-status") return ["poll", 150];
  if (p === "/google-start" || p === "/yandex-start" || p === "/yandex-cb") return ["g", 20];
  if (p === "/chat") return ["chatget", 90];
  if (p === "/me" || p === "/my-orders" || p === "/ref-info" || p === "/chat-unread") return ["acct", 120];
  return null;
}
function isLimited(request, bucket, max) {
  const k = bucket + "|" + (request.headers.get("CF-Connecting-IP") || "?"), now = Date.now();
  let e = RATE_MEM.get(k);
  if (!e || now > e.r) { e = { n: 0, r: now + 60000 }; RATE_MEM.set(k, e); }
  e.n++;
  if (RATE_MEM.size > 5000) {
    RATE_MEM.forEach((v, kk) => { if (now > v.r) RATE_MEM.delete(kk); });
    if (RATE_MEM.size > 5000) RATE_MEM.clear();
  }
  return e.n > max;
}
const SEC_HEADERS = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "Referrer-Policy": "no-referrer",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
  "Permissions-Policy": "geolocation=(), camera=(), microphone=(), payment=()",
};

// ---------- KV ----------
const norm = (p) => {
  if (!Array.isArray(p.media)) p.media = p.img ? [{ f: String(p.img).replace("/img/", ""), t: "i" }] : [];
  if (!Array.isArray(p.colors)) p.colors = (p.rang || []).map((n) => ({ n: n, media: [] }));
  p.colors.forEach((c) => { if (!Array.isArray(c.media)) c.media = []; });
  if (!Array.isArray(p.olcham)) p.olcham = [];
  p.kg = Number(p.kg) || 0.5;
  p.rang = p.colors.map((c) => c.n);
  return p;
};
const getSettings = async (env) => Object.assign({}, DEFAULT_SETTINGS, (await env.PRODUCTS.get("settings", "json")) || {});
const saveSettings = (env, s) => env.PRODUCTS.put("settings", JSON.stringify(s));
const getList = async (env) => ((await env.PRODUCTS.get("list", "json")) || []).map(norm);
const saveList = (env, l) => env.PRODUCTS.put("list", JSON.stringify(l));
// Faqat sayt (o'qish) uchun: KV keshidan o'qiydi. Admin bot doim yangi ma'lumot o'qiydi (getList/getSettings).
const getListPub = async (env) => ((await env.PRODUCTS.get("list", { type: "json", cacheTtl: 30 })) || []).map(norm);
const getSettingsPub = async (env) => Object.assign({}, DEFAULT_SETTINGS, (await env.PRODUCTS.get("settings", { type: "json", cacheTtl: 30 })) || {});
const getOrdersMemo = (env) => memo("orders", 8000, () => getOrders(env));
const getOrders = async (env) => (await env.PRODUCTS.get("orders", "json")) || [];
const saveOrders = (env, o) => kvPut(env, "orders", JSON.stringify(o.slice(0, 200)));
const getState = (env) => env.PRODUCTS.get("state", "json");
const setState = (env, st) => (st ? env.PRODUCTS.put("state", JSON.stringify(st)) : env.PRODUCTS.delete("state"));
const getWiz = (env) => env.PRODUCTS.get("wiz", "json");
const setWiz = (env, w) => (w ? env.PRODUCTS.put("wiz", JSON.stringify(w)) : env.PRODUCTS.delete("wiz"));
const findP = (items, id) => items.find((x) => x.id === Number(id));
const priceOf = (p, s) => (p.som > 0 ? p.som : Math.round(((p.y || 0) * s.rate * (1 + s.markup / 100)) / 1000) * 1000);
const cargoOf = (p, s, m) => Math.round((p.kg * (m === "avia" ? s.cargoAvia : s.cargoAuto) * s.usd) / 1000) * 1000;
const gal = (p, ci) => {
  let l = ci >= 0 && p.colors[ci] && p.colors[ci].media.length ? p.colors[ci].media : p.media;
  if (!l.length) l = [].concat(...p.colors.map((c) => c.media));
  return l;
};

// ---------- Telegram ----------
const tg = async (env, method, body, tries) => {
  const r = await fetch("https://api.telegram.org/bot" + env.BOT_TOKEN + "/" + method, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  }).then((x) => x.json()).catch(() => ({ ok: false }));
  // Telegram juda tez yuborishdan to'xtatsa (429), ko'rsatilgan vaqt kutib qayta urinadi
  if (!r.ok && r.error_code === 429 && (tries || 0) < 2) {
    await sleep(Math.min((r.parameters && r.parameters.retry_after) || 1, 4) * 1000 + 200);
    return tg(env, method, body, (tries || 0) + 1);
  }
  return r;
};
const btn = (text, data) => ({ text: text, callback_data: data });
const say = (env, text, kb) => tg(env, "sendMessage", Object.assign({ chat_id: env.CHAT_ID, text: text }, kb ? { reply_markup: kb } : {}));
// HTML bilan, mavjud xabarni joyida yangilaydi
async function ui(env, cq, text, kb) {
  const base = { parse_mode: "HTML", reply_markup: kb };
  if (cq && cq.message && !cq.message.photo) {
    const r = await tg(env, "editMessageText", Object.assign({ chat_id: cq.message.chat.id, message_id: cq.message.message_id, text: text }, base));
    if (r.ok || /not modified/i.test(r.description || "")) return r;
  }
  return tg(env, "sendMessage", Object.assign({ chat_id: env.CHAT_ID, text: text }, base));
}

const MENU = {
  inline_keyboard: [
    [btn("🛍 Tovarlar", "prods"), btn("➕ Tovar qo'shish", "addmenu")],
    [btn("📦 Buyurtmalar", "ords"), btn("📊 Statistika", "stats")],
    [btn("👥 Akkauntlar", "ua")],
    [btn("💻 Kompyuterga yuborish", "pcm")],
    [btn("🎟 Promo-kodlar", "promos"), btn("💲 Kurs va sozlamalar", "settings")],
    [btn("🧹 Eski tovarlarni yashirish", "hideold"), btn("↩️ Eskilarni qaytarish", "showold")],
    [btn("❓ Yordam", "help")],
  ],
};
const QUICK = { "🏠 menyu": "menu", "➕ tovar qo'shish": "addmenu", "🛍 tovarlar": "prods", "📦 buyurtmalar": "ords" };

async function showMenu(env, cq) {
  return ui(env, cq, "🏠 <b>Boshqaruv menyusi</b>\nKerakli bo'limni tanlang:", MENU);
}

// ---------- tovar kartochkasi (saytdagi ko'rinishga o'xshash) ----------
function cardParts(p, s, ci) {
  const l = gal(p, ci), img = l.find((m) => m.t === "i");
  const text = [
    "<b>" + h(p.n) + "</b>",
    "🔥 " + (p.s || 0) + " ta sotilgan · ⭐ 4.8",
    "💰 <b>" + money(priceOf(p, s)) + "</b>" + (p.som > 0 ? "" : "  <i>(eski, yuan hisobidan)</i>"),
    "",
    "🚛 Avto · 15–25 kun · ~" + money(cargoOf(p, s, "avto")),
    p.av ? "✈️ Avia · 7–12 kun · ~" + money(cargoOf(p, s, "avia")) : "✈️ Avia: mumkin emas",
    "⚖️ " + p.kg + " kg",
    "📏 O'lcham: " + (p.olcham.length ? h(p.olcham.join(" · ")) : "yo'q"),
    "🎨 Rang: " + (p.colors.length ? p.colors.map((c, i) => (i === ci ? "<b>[" + h(c.n) + "]</b>" : h(c.n)) + " (" + c.media.length + ")").join(" · ") : "yo'q"),
    "🖼 Umumiy rasm/video: " + p.media.length + " ta",
    "📂 " + h(catName(p.c)) + " · #" + p.id + " · " + (p.draft ? "📝 qoralama" : p.hidden ? "🚫 yashirin" : "👁 saytda ko'rinadi"),
  ].join("\n");
  const id = p.id, rows = [];
  chunk(p.colors.map((c, i) => btn((i === ci ? "✅ " : "") + c.n, "cv:" + id + ":" + (i === ci ? -1 : i))), 3).forEach((r) => rows.push(r));
  rows.push([btn("📷 Albom (" + l.length + ")", "al:" + id + ":" + ci)]);
  rows.push([btn("✏️ Nomi", "en:" + id), btn("💲 Narxi", "ep:" + id)]);
  rows.push([btn("⚖️ Og'irlik", "ek:" + id), btn("📂 Kategoriya", "ecat:" + id)]);
  rows.push([btn("📏 O'lchamlar", "es:" + id), btn("🎨 Ranglar", "ec:" + id)]);
  rows.push([btn("🖼 Rasm/video", "mm:" + id), btn(p.av ? "✈️ Avia: ha" : "✈️ Avia: yo'q", "ea:" + id)]);
  rows.push([btn("🔥 Sotilgan", "esold:" + id), btn("📑 Nusxa", "pdup:" + id)]);
  rows.push([btn(p.hidden ? "👁 Saytda ko'rsat" : "🚫 Yashirish", "pv:" + id), btn("🗑 O'chirish", "pd:" + id)]);
  rows.push([btn("⬅️ Tovarlar", "prods")]);
  return { text: text, kb: { inline_keyboard: rows }, photo: img ? img.f : null };
}

async function showCard(env, id, ci, cq) {
  await flushUploads(env);
  const p = findP(await getList(env), id);
  if (!p) return say(env, "Bu tovar topilmadi.", MENU);
  const s = await getSettings(env), c = cardParts(p, s, ci === undefined ? -1 : ci);
  const m = cq && cq.message;
  if (m) {
    const isPhoto = !!m.photo;
    let r = null;
    if (isPhoto && c.photo) {
      r = await tg(env, "editMessageMedia", { chat_id: m.chat.id, message_id: m.message_id, media: { type: "photo", media: c.photo, caption: c.text, parse_mode: "HTML" }, reply_markup: c.kb });
    } else if (!isPhoto && !c.photo) {
      r = await tg(env, "editMessageText", { chat_id: m.chat.id, message_id: m.message_id, text: c.text, parse_mode: "HTML", reply_markup: c.kb });
    }
    if (r && (r.ok || /not modified/i.test(r.description || ""))) return r;
    await tg(env, "deleteMessage", { chat_id: m.chat.id, message_id: m.message_id });
  }
  if (c.photo) return tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: c.photo, caption: c.text, parse_mode: "HTML", reply_markup: c.kb });
  return tg(env, "sendMessage", { chat_id: env.CHAT_ID, text: c.text, parse_mode: "HTML", reply_markup: c.kb });
}

async function sendAlbum(env, list) {
  if (!list.length) return say(env, "Bu yerda rasm/video yo'q.");
  for (const part of chunk(list, 10)) {
    if (part.length === 1) {
      await tg(env, part[0].t === "v" ? "sendVideo" : "sendPhoto", Object.assign({ chat_id: env.CHAT_ID }, part[0].t === "v" ? { video: part[0].f } : { photo: part[0].f }));
    } else {
      await tg(env, "sendMediaGroup", { chat_id: env.CHAT_ID, media: part.map((m) => ({ type: m.t === "v" ? "video" : "photo", media: m.f })) });
    }
  }
  return null;
}

// ---------- ro'yxat, qidiruv ----------
async function showProducts(env, cq, page) {
  await flushUploads(env);
  const s = await getSettings(env), items = (await getList(env)).slice().reverse();
  if (!items.length) return ui(env, cq, "Hozircha tovar yo'q.", { inline_keyboard: [[btn("➕ Tovar qo'shish", "addmenu")], [btn("⬅️ Menyu", "menu")]] });
  const per = 8, pages = Math.max(1, Math.ceil(items.length / per));
  page = Math.min(Math.max(0, page || 0), pages - 1);
  const rows = items.slice(page * per, page * per + per).map((p) => [btn((p.draft ? "📝 " : p.hidden ? "🚫 " : "👁 ") + p.n + " — " + money(priceOf(p, s)), "p:" + p.id)]);
  const nav = [];
  if (page > 0) nav.push(btn("◀️", "pl:" + (page - 1)));
  nav.push(btn((page + 1) + "/" + pages, "pl:" + page));
  if (page < pages - 1) nav.push(btn("▶️", "pl:" + (page + 1)));
  rows.push(nav);
  rows.push([btn("🔍 Qidirish", "find"), btn("➕ Qo'shish", "addmenu")]);
  rows.push([btn("⬅️ Menyu", "menu")]);
  return ui(env, cq, "🛍 <b>Tovarlar</b> (" + items.length + " ta). Tovarni bosing:", { inline_keyboard: rows });
}

// ---------- tahrirlash oynalari ----------
const STEPN = 7;
async function lab(env, id, step) {
  const w = await getWiz(env);
  return w && w.id === id && w.step === step ? "<b>" + step + "/" + STEPN + "</b> " : "";
}
async function cancelKb(env, id) {
  const w = await getWiz(env);
  return { inline_keyboard: [[w && w.id === id ? btn("❌ Bekor qilish", "wc:" + id) : btn("⬅️ Tovar", "p:" + id)]] };
}
async function after(env, id, step, cq) {
  const w = await getWiz(env);
  if (w && w.id === id && w.step === step) return wizGo(env, id, step + 1, cq);
  return showCard(env, id, -1, null);
}
async function wizGo(env, id, step, cq) {
  await setWiz(env, { id: id, step: step });
  if (step === 1) return askName(env, cq, id);
  if (step === 2) return askPrice(env, cq, id);
  if (step === 3) return askKg(env, cq, id);
  if (step === 4) return sizeEditor(env, cq, id, null);
  if (step === 5) return colorEditor(env, cq, id);
  if (step === 6) return askAvia(env, cq, id);
  return startMedia(env, cq, id, true);
}
async function wizFinish(env, id, cq) {
  const items = await getList(env), p = findP(items, id);
  if (p) { p.hidden = false; p.draft = false; await saveList(env, items); }
  await setWiz(env, null);
  await setState(env, null);
  await say(env, "🎉 Tovar saytga qo'shildi! Quyida saytdagidek ko'rinishi. Hammasini tugmalar bilan o'zgartirishingiz mumkin:");
  return showCard(env, id, -1, null);
}

async function askName(env, cq, id) {
  const p = findP(await getList(env), id);
  await setState(env, { a: "n", id: id });
  return ui(env, cq, (await lab(env, id, 1)) + "📝 <b>Tovar nomini yozing</b>" + (p && !p.draft ? "\nHozirgi: " + h(p.n) : ""), await cancelKb(env, id));
}
async function askPrice(env, cq, id) {
  const items = await getList(env), p = findP(items, id), s = await getSettings(env);
  await setState(env, { a: "p", id: id });
  const cur = p && p.som > 0 ? "\nHozirgi narx: <b>" + money(p.som) + "</b>" : "";
  const rows = [];
  if (p && p.som > 0) rows.push([btn("−10%", "ppc:" + id + ":-10"), btn("−5%", "ppc:" + id + ":-5"), btn("+5%", "ppc:" + id + ":5"), btn("+10%", "ppc:" + id + ":10")]);
  rows.push((await cancelKb(env, id)).inline_keyboard[0]);
  void s;
  return ui(env, cq, (await lab(env, id, 2)) + "💰 <b>Narxini so'mda yozing</b>\nMasalan: 150000 yoki 150k yoki 150 000" + cur, { inline_keyboard: rows });
}
async function askKg(env, cq, id) {
  const p = findP(await getList(env), id);
  await setState(env, null);
  const rows = chunk(KG.map((k) => btn((p && String(p.kg) === k ? "✅ " : "") + k + " kg", "wk:" + id + ":" + k)), 4);
  rows.push([btn("✍️ Boshqa og'irlik", "wkx:" + id)]);
  rows.push((await cancelKb(env, id)).inline_keyboard[0]);
  return ui(env, cq, (await lab(env, id, 3)) + "⚖️ <b>Og'irligi qancha (kg)?</b>\nCargo narxi shundan hisoblanadi.", { inline_keyboard: rows });
}
async function sizeEditor(env, cq, id, set) {
  const p = findP(await getList(env), id);
  if (!p) return say(env, "Tovar topilmadi.", MENU);
  await setState(env, null);
  set = set || (p.c === "sport" ? "N" : p.c === "bolalar" ? "K" : "L");
  const opts = SZ[set].concat(p.olcham.filter((x) => SZ[set].indexOf(x) < 0));
  const rows = chunk(opts.map((x, i) => btn((p.olcham.indexOf(x) >= 0 ? "✅ " : "") + x, "zt:" + id + ":" + set + ":" + i)), 5);
  rows.push(Object.keys(SZ).map((k) => btn((k === set ? "• " : "") + SZN[k], "zs:" + id + ":" + k)));
  rows.push([btn("✍️ Boshqa o'lcham", "zx:" + id), btn("🚫 O'lchamsiz", "zc:" + id)]);
  rows.push([btn("✅ Tayyor", "zd:" + id)]);
  return ui(env, cq, (await lab(env, id, 4)) + "📏 <b>O'lchamlarni tanlang</b> (bosib qo'shing/olib tashlang)\nTanlangan: " + (p.olcham.length ? h(p.olcham.join(", ")) : "yo'q"), { inline_keyboard: rows });
}
const colorOpts = (p) => COLOR_PRESET.concat(p.colors.map((c) => c.n).filter((n) => COLOR_PRESET.indexOf(n) < 0));
async function colorEditor(env, cq, id) {
  const p = findP(await getList(env), id);
  if (!p) return say(env, "Tovar topilmadi.", MENU);
  await setState(env, null);
  const have = p.colors.map((c) => c.n);
  const rows = chunk(colorOpts(p).map((n, i) => btn((have.indexOf(n) >= 0 ? "✅ " : "") + n, "ct:" + id + ":" + i)), 3);
  rows.push([btn("✍️ Boshqa rang yozish", "cx:" + id), btn("🚫 Ranglarsiz", "cc:" + id)]);
  rows.push([btn("✅ Tayyor", "cd:" + id)]);
  return ui(env, cq, (await lab(env, id, 5)) + "🎨 <b>Ranglarni tanlang</b> (bosib qo'shing/olib tashlang)\nTanlangan: " + (have.length ? h(have.join(", ")) : "yo'q") + "\nHar bir rangga keyin alohida rasm/video qo'shiladi.", { inline_keyboard: rows });
}
async function askAvia(env, cq, id) {
  await setState(env, null);
  return ui(env, cq, (await lab(env, id, 6)) + "✈️ <b>Avia cargo bilan jo'natish mumkinmi?</b>\n(Batareya, suyuqlik, elektronika — mumkin emas)", {
    inline_keyboard: [[btn("✈️ Ha, mumkin", "av:" + id + ":1"), btn("🚛 Yo'q, faqat avto", "av:" + id + ":0")], (await cancelKb(env, id)).inline_keyboard[0]],
  });
}

// ---------- media ----------
function getMedia(msg) {
  if (msg.photo && msg.photo.length) return { f: msg.photo[msg.photo.length - 1].file_id, t: "i" };
  if (msg.video) return { f: msg.video.file_id, t: "v" };
  if (msg.animation) return { f: msg.animation.file_id, t: "v" };
  if (msg.document) {
    const mt = msg.document.mime_type || "";
    if (/^image\//.test(mt)) return { f: msg.document.file_id, t: "i" };
    if (/^video\//.test(mt)) return { f: msg.document.file_id, t: "v" };
  }
  return null;
}
async function queueMedia(env, msg, m) {
  const st = await getState(env);
  if (st && st.a === "pcbox") return pcStore(env, st, msg, m);
  if (!st || st.a !== "addmedia") return say(env, "Rasm/video qo'shish uchun: 🛍 Tovarlar → tovarni oching → 🖼 Rasm/video.", MENU);
  const key = "up:" + st.id + ":" + st.ci + ":" + String(msg.message_id).padStart(12, "0");
  await env.PRODUCTS.put(key, JSON.stringify(m), { expirationTtl: 86400 });
  const gid = msg.media_group_id || "m" + msg.message_id;
  if (st.g === gid) return null;
  await setState(env, Object.assign({}, st, { g: gid }));
  return say(env, "📥 Qabul qilinmoqda... Hammasini yuborib bo'lgach pastdagi tugmani bosing.");
}
async function flushUploads(env) {
  const ls = await env.PRODUCTS.list({ prefix: "up:" });
  if (!ls.keys.length) return 0;
  const items = await getList(env);
  let n = 0;
  for (const k of ls.keys.map((x) => x.name).sort()) {
    const parts = k.split(":");
    const v = await env.PRODUCTS.get(k, "json");
    await env.PRODUCTS.delete(k);
    const p = findP(items, parts[1]);
    if (!v || !p) continue;
    const arr = parts[2] === "g" ? p.media : (p.colors[Number(parts[2])] || {}).media;
    if (!arr) continue;
    arr.push(v);
    n++;
  }
  if (n) await saveList(env, items);
  return n;
}
async function askMedia(env, cq, st) {
  const p = findP(await getList(env), st.id);
  if (!p) return say(env, "Tovar topilmadi.", MENU);
  const where = st.ci === "g" ? "<b>umumiy (muqova)</b>" : "<b>«" + h((p.colors[st.ci] || {}).n) + "»</b> rangi uchun";
  const pre = st.wiz ? "<b>7/" + STEPN + "</b> (" + (st.pos + 1) + "/" + st.seq.length + ") " : "";
  const last = !st.wiz || st.pos + 1 >= st.seq.length;
  const rows = [[btn(st.wiz ? (last ? "🏁 Tugatish" : "➡️ Keyingisi / o'tkazish") : "✅ Tayyor", "mdn")]];
  if (st.wiz) rows.push([btn("❌ Bekor qilish", "wc:" + st.id)]);
  return ui(env, cq, pre + "🖼 " + where + " rasm yoki video yuboring.\nBir nechta bo'lishi mumkin (albom qilib ham yuborsangiz bo'ladi).", { inline_keyboard: rows });
}
async function startMedia(env, cq, id, wiz) {
  const p = findP(await getList(env), id);
  const seq = ["g"].concat(p.colors.map((c, i) => i));
  const st = { a: "addmedia", id: id, ci: "g", seq: seq, pos: 0, wiz: !!wiz };
  await setState(env, st);
  return askMedia(env, cq, st);
}
async function mediaChooser(env, cq, id) {
  const p = findP(await getList(env), id);
  if (!p) return say(env, "Tovar topilmadi.", MENU);
  const rows = [[btn("🖼 Umumiy (" + p.media.length + ")", "mt:" + id + ":g")]];
  chunk(p.colors.map((c, i) => btn("🎨 " + c.n + " (" + c.media.length + ")", "mt:" + id + ":" + i)), 2).forEach((r) => rows.push(r));
  rows.push([btn("⬅️ Tovar", "p:" + id)]);
  return ui(env, cq, "🖼 <b>Qaysi uchun rasm/video?</b>\nUmumiy — rang tanlanmaganda ko'rinadi. Rang — mijoz shu rangni tanlaganda ko'rinadi.", { inline_keyboard: rows });
}
async function mediaTarget(env, cq, id, t) {
  const p = findP(await getList(env), id);
  if (!p) return say(env, "Tovar topilmadi.", MENU);
  const isG = t === "g", arr = isG ? p.media : (p.colors[Number(t)] || {}).media;
  if (!arr) return mediaChooser(env, cq, id);
  const rows = [
    [btn("➕ Qo'shish", "am:" + id + ":" + t), btn("🔄 Almashtirish", "rm:" + id + ":" + t)],
    [btn("📷 Ko'rish", "al:" + id + ":" + (isG ? "g" : t)), btn("↩️ Oxirgisini o'chirish", "ml:" + id + ":" + t)],
    [btn("🧹 Hammasini tozalash", "mc:" + id + ":" + t)],
  ];
  if (!isG) rows.push([btn("✏️ Rang nomi", "cn:" + id + ":" + t)]);
  rows.push([btn("⬅️ Orqaga", "mm:" + id)]);
  return ui(env, cq, "🖼 " + (isG ? "<b>Umumiy</b>" : "<b>🎨 " + h(p.colors[Number(t)].n) + "</b>") + " — " + arr.length + " ta rasm/video", { inline_keyboard: rows });
}

// ---------- buyurtma/promo/sozlama/statistika ----------
const ST_ORDER = { yangi: 0, tasdiqlandi: 1, yolda: 2, uzb: 3, uzpost: 4, yetkazildi: 5, topshirildi: 6, bekor: 7 };
const orderText = (o) => [
  "🛒 #" + o.id + " — " + (STATUSES[o.status] || "🆕 Yangi"), "",
  "👤 " + o.name, "📞 " + o.phone,
  o.uzp ? "📍 Filial (UzPost): " + o.uzp : null,
  o.ck ? "🧾 Chek: bor ✅" : null, "",
  o.summary, "", "✅ Jami: " + money(o.total),
  o.trk ? "📦 Trek kod: " + o.trk : null,
].filter((l) => l !== null).join("\n");
async function sendOrder(env, o) {
  const pics = (o.ph || []).slice(0, 3).map((f) => ({ f: f, cap: "" }));
  if (o.ck) pics.push({ f: o.ck, cap: "🧾 Chek #" + o.id });
  if (pics.length === 1) await tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: pics[0].f, caption: pics[0].cap || undefined });
  else if (pics.length > 1) await tg(env, "sendMediaGroup", { chat_id: env.CHAT_ID, media: pics.map((x) => Object.assign({ type: "photo", media: x.f }, x.cap ? { caption: x.cap } : {})) });
  return say(env, orderText(o), { inline_keyboard: statusRows(o.id) });
}
const orderHtml = (o) => [
  "🛒 <b>#" + h(o.id) + "</b> — " + (STATUSES[o.status] || "🆕 Yangi"), "",
  "👤 " + h(o.name), "📞 " + h(o.phone),
  o.uzp ? "📍 Filial (UzPost): " + h(o.uzp) : null,
  o.ck ? "🧾 Chek: bor ✅" : null, "",
  h(o.summary), "", "✅ Jami: " + money(o.total),
  o.trk ? "📦 Trek kod: " + h(o.trk) : null,
].filter((l) => l !== null).join("\n");
const stEmoji = (st) => (ST_SHORT[st || "yangi"] || "🆕").split(" ")[0];

// Bitta xabar: holat tugmalari + buyurtmalar ro'yxati (xabar joyida yangilanadi, pastga tushmaydi)
async function showOrders(env, cq, f, page) {
  const all = await getOrders(env);
  if (!all.length) return ui(env, cq, "Buyurtmalar yo'q.", MENU);
  const cnt = {};
  all.forEach((o) => { const k = o.status || "yangi"; cnt[k] = (cnt[k] || 0) + 1; });
  const keys = ["yangi", "tasdiqlandi", "yolda", "uzb", "uzpost", "yetkazildi", "topshirildi", "bekor"];
  // 1-ekran: faqat holatlar (sonlari bilan)
  if (!f) {
    const tabs = keys.map((k) => btn(ST_SHORT[k] + " (" + (cnt[k] || 0) + ")", "ol:" + k + ":0"));
    tabs.push(btn("📦 Hammasi (" + all.length + ")", "ol:all:0"));
    const rows = chunk(tabs, 2);
    rows.push([btn("⬅️ Menyu", "menu")]);
    return ui(env, cq, "📦 <b>Buyurtmalar</b>\nJami: " + all.length + " ta\n\nHolatni tanlang:", { inline_keyboard: rows });
  }
  // 2-ekran: tanlangan holatdagi buyurtmalar (alohida sahifa)
  let list = all.slice().sort((a, b) => (b.t || 0) - (a.t || 0));
  if (f !== "all") list = list.filter((o) => (o.status || "yangi") === f);
  const per = 8, pages = Math.max(1, Math.ceil(list.length / per));
  page = Math.min(Math.max(0, Number(page) || 0), pages - 1);
  const part = list.slice(page * per, page * per + per);
  const rows = [];
  part.forEach((o) => rows.push([btn(stEmoji(o.status) + " #" + o.id + " · " + String(o.name || "").slice(0, 14) + " · " + money(o.total).replace(" so'm", ""), "oo:" + o.id + ":" + f + ":" + page)]));
  if (pages > 1) rows.push([btn(page > 0 ? "◀️" : "·", page > 0 ? "ol:" + f + ":" + (page - 1) : "nop"), btn((page + 1) + "/" + pages, "nop"), btn(page < pages - 1 ? "▶️" : "·", page < pages - 1 ? "ol:" + f + ":" + (page + 1) : "nop")]);
  rows.push([btn("⬅️ Orqaga", "ords")]);
  const title = f === "all" ? "📦 Hammasi" : (STATUSES[f] || "🆕 Yangi");
  return ui(env, cq, "<b>" + title + "</b> · " + list.length + " ta" + (list.length ? "\nBuyurtmani bosing:" : "\n\nBu holatda buyurtma yo'q."), { inline_keyboard: rows });
}
// Bitta buyurtmaning to'liq ma'lumoti (shu xabar o'rnida)
async function orderCard(env, cq, oid, f, page, full) {
  const o = (await getOrders(env)).find((x) => String(x.id) === String(oid));
  if (!o) return ui(env, cq, "Buyurtma topilmadi.", MENU);
  const ctx = (f || "all") + ":" + (page || 0);
  let rows;
  if (full) rows = statusRowsFull(o.id, ctx);
  else {
    rows = statusRows(o.id, o.status || "yangi", ctx);
    if (o.ck || (o.ph && o.ph.length)) rows.push([btn("🧾 Chek va rasmlar", "ph:" + o.id)]);
    rows.push([btn("⬅️ Ro'yxat", "ol:" + ctx)]);
  }
  return ui(env, cq, orderHtml(o), { inline_keyboard: rows });
}
async function sendOrderPhotos(env, oid) {
  const o = (await getOrders(env)).find((x) => String(x.id) === String(oid));
  if (!o) return say(env, "Buyurtma topilmadi.", MENU);
  const pics = (o.ph || []).slice(0, 3).map((f) => ({ f: f, cap: "" }));
  if (o.ck) pics.push({ f: o.ck, cap: "🧾 Chek #" + o.id });
  if (!pics.length) return say(env, "Rasm yoki chek yo'q.", MENU);
  if (pics.length === 1) return tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: pics[0].f, caption: pics[0].cap || undefined });
  return tg(env, "sendMediaGroup", { chat_id: env.CHAT_ID, media: pics.map((x) => Object.assign({ type: "photo", media: x.f }, x.cap ? { caption: x.cap } : {})) });
}
async function showStats(env, cq) {
  const items = await getList(env), orders = await getOrders(env);
  const by = {};
  orders.forEach((o) => { by[o.status || "yangi"] = (by[o.status || "yangi"] || 0) + 1; });
  const day = Date.now() - 864e5;
  const today = orders.filter((o) => o.t > day);
  return ui(env, cq,
    "📊 <b>Statistika</b>\n\n🛍 Tovarlar: " + items.length + " (saytda: " + items.filter((p) => !p.hidden && !p.draft).length + ", yashirin: " + items.filter((p) => p.hidden && !p.draft).length + ", qoralama: " + items.filter((p) => p.draft).length + ")\n" +
    "📦 Buyurtmalar: " + orders.length + "\n🕒 24 soatda: " + today.length + " ta, " + money(today.reduce((a, o) => a + (o.total || 0), 0)) + "\n\n" +
    Object.keys(by).map((k) => (STATUSES[k] || "🆕 Yangi") + ": " + by[k]).join("\n"),
    { inline_keyboard: [[btn("⬅️ Menyu", "menu")]] });
}
async function showPromos(env) {
  const s = await getSettings(env), codes = Object.keys(s.promos);
  const text = codes.length ? codes.map((c) => c + " — " + s.promos[c] + "%").join("\n") : "Promo-kodlar yo'q.";
  const rows = codes.map((c) => [btn("🗑 " + c, "pdel:" + c)]);
  rows.push([btn("⬅️ Menyu", "menu")]);
  return say(env, "🎟 Promo-kodlar:\n" + text + "\n\nYangi kod: /promo KOD 10 (10%)", { inline_keyboard: rows });
}
async function showSettings(env) {
  const s = await getSettings(env);
  return say(env,
    "💲 Sozlamalar:\nUstama: " + s.markup + "% (faqat eski, yuanli tovarlarga)\nDollar kursi: " + s.usd + " so'm\nYuan kursi: " + s.rate + " so'm\nCargo avto: $" + s.cargoAuto + "/kg, avia: $" + s.cargoAvia + "/kg\n\n" +
    "O'zgartirish: /ustama 40, /kurs 1750, /dollar 12800, /cargo 6 9",
    { inline_keyboard: [[btn("30%", "mk:30"), btn("40%", "mk:40"), btn("50%", "mk:50")], [btn("⬅️ Menyu", "menu")]] });
}
async function setHideStatic(env, v) {
  const s = await getSettings(env);
  s.hideStatic = v;
  await saveSettings(env, s);
  return say(env, v ? "🧹 Eski tovarlar saytdan yashirildi." : "↩️ Eski tovarlar qaytarildi.", MENU);
}
const HELP =
  "📘 <b>Qanday ishlaydi</b>\n\n➕ <b>Tovar qo'shish</b> — kategoriya tanlaysiz, keyin bot ketma-ket so'raydi: nom → narx (so'm) → og'irlik → o'lcham → rang → avia → rasm/video (umumiy va har bir rang uchun alohida). Hammasi tugmalar bilan.\n\n" +
  "🛍 <b>Tovarlar</b> — tovarni bossangiz saytdagidek kartochka chiqadi. Rang tugmasini bossangiz shu rangning rasmi ko'rinadi. Ostidagi tugmalar bilan hamma narsani o'zgartirasiz: nom, narx, og'irlik, kategoriya, o'lcham, rang, rasm/video, avia, sotilgan soni, nusxa, yashirish, o'chirish.\n\n" +
  "🔍 Qidirish, 📊 Statistika, 📦 Buyurtmalar holatini o'zgartirish ham shu yerda.\n\nVideo 20 MB dan oshmasin.\n\n" +
  "Buyruqlar: /narx ID SOM, /ochir ID, /yashir ID, /ustama N, /kurs N, /dollar N, /cargo AVTO AVIA, /promo KOD N, /promo_ochir KOD, /menu";

// ---------- matn ----------
async function handleText(env, text) {
  const qk = QUICK[text.trim().toLowerCase()];
  if (qk) { await setState(env, null); return handleCallback(env, { data: qk }); }
  const state = await getState(env);
  // Tovar havolasi yuborilsa (sayt yoki Telegram link), shu tovar kartochkasi ochiladi: u yerda tahrirlash va o'chirish tugmalari bor
  if (!text.startsWith("/") && (!state || state.a === "find")) {
    const lm = text.match(/(?:[?&]p=|start=p|#p)(\d{1,7})\b/);
    if (lm) {
      await setState(env, null);
      if (findP(await getList(env), lm[1])) return showCard(env, Number(lm[1]), -1, null);
      return say(env, "Bu havola bo'yicha tovar topilmadi (o'chirilgan bo'lishi mumkin).", MENU);
    }
  }
  if (state && !text.startsWith("/")) {
    if (state.a === "trk") { await setState(env, null); return setTrack(env, state.oid, text); }
    if (state.a === "chat") return adminReply(env, state.key, text);
    if (state.a === "pcbox") {
      const t = clean(text, 300).trim();
      if (t) await env.PRODUCTS.put(pcKey(state.sid, state.f || 1, "n" + Date.now()), "1", { metadata: { t: "n", x: t }, expirationTtl: 259200 });
      return say(env, "📝 Izoh " + (state.f || 1) + "-papkaga yozildi (nom, narx, rang, og'irlik kabi).");
    }
    if (state.a === "addmedia") return say(env, "Rasm yoki video yuboring. Tugagach tugmani bosing.", { inline_keyboard: [[btn("✅ Tayyor / keyingisi", "mdn")]] });
    if (state.a === "find") {
      await setState(env, null);
      const s = await getSettings(env), q = text.trim().toLowerCase();
      const res = (await getList(env)).filter((p) => p.n.toLowerCase().indexOf(q) >= 0 || String(p.id) === q).slice(0, 12);
      if (!res.length) return say(env, "Hech narsa topilmadi.", { inline_keyboard: [[btn("🔍 Qayta qidirish", "find"), btn("⬅️ Menyu", "menu")]] });
      return say(env, "Topildi: " + res.length + " ta", { inline_keyboard: res.map((p) => [btn(p.n + " — " + money(priceOf(p, s)), "p:" + p.id)]).concat([[btn("⬅️ Menyu", "menu")]]) });
    }
    const items = await getList(env), p = findP(items, state.id);
    if (!p) { await setState(env, null); return say(env, "Tovar topilmadi.", MENU); }
    const step = { n: 1, p: 2, kg: 3, szadd: 4, coladd: 5 }[state.a] || 0;
    if (state.a === "n") {
      const n = clean(text.trim(), 80);
      if (n.length < 2) return say(env, "Nom juda qisqa. Qaytadan yozing:");
      p.n = n; await saveList(env, items); await setState(env, null);
      return after(env, p.id, 1);
    }
    if (state.a === "p") {
      const v = parsePrice(text);
      if (v < 100) return say(env, "Narxni raqam bilan yozing, masalan: 150000 yoki 150k");
      p.som = v; await saveList(env, items); await setState(env, null);
      return after(env, p.id, 2);
    }
    if (state.a === "kg") {
      const v = parseKg(text);
      if (!v) return say(env, "Og'irlikni raqam bilan yozing, masalan: 0.5");
      p.kg = v; await saveList(env, items); await setState(env, null);
      return after(env, p.id, 3);
    }
    if (state.a === "szadd") {
      splitList(text).forEach((x) => { x = clean(x, 15); if (x && p.olcham.indexOf(x) < 0) p.olcham.push(x); });
      await saveList(env, items);
      return sizeEditor(env, null, p.id, null);
    }
    if (state.a === "coladd") {
      splitList(text).forEach((x) => { x = clean(x, 30); if (x && !p.colors.some((c) => c.n.toLowerCase() === x.toLowerCase())) p.colors.push({ n: x, media: [] }); });
      await saveList(env, items);
      return colorEditor(env, null, p.id);
    }
    if (state.a === "cname") {
      const n = clean(text.trim(), 30), c = p.colors[state.ci];
      if (!c || !n) { await setState(env, null); return say(env, "Rang topilmadi.", MENU); }
      c.n = n; await saveList(env, items); await setState(env, null);
      return showCard(env, p.id, -1, null);
    }
    if (state.a === "sold") {
      const v = Math.max(0, Math.round(Number(text.replace(/\s/g, "")) || 0));
      p.s = v; await saveList(env, items); await setState(env, null);
      return showCard(env, p.id, -1, null);
    }
    void step;
  }
  const parts = text.trim().split(/\s+/), cmd = parts[0].toLowerCase(), a1 = parts[1], a2 = parts[2];
  if (cmd === "/start") {
    await tg(env, "sendMessage", { chat_id: env.CHAT_ID, text: "👇 Tezkor tugmalar pastda", reply_markup: { keyboard: [[{ text: "🏠 Menyu" }, { text: "➕ Tovar qo'shish" }], [{ text: "🛍 Tovarlar" }, { text: "📦 Buyurtmalar" }]], resize_keyboard: true, is_persistent: true } });
    return showMenu(env);
  }
  if (cmd === "/menu") return showMenu(env);
  if (cmd === "/stop") { await setState(env, null); return say(env, "Chatdan chiqdingiz.", MENU); }
  if (cmd === "/trek") {
    if (!a1 || !a2) return say(env, "Format: /trek ZAKAZ_RAQAMI TREK_KOD");
    return setTrack(env, a1, parts.slice(2).join(" "));
  }
  if (cmd === "/help" || cmd === "/yordam") return ui(env, null, HELP, MENU);
  if (cmd === "/royxat") return showProducts(env, null, 0);
  if (cmd === "/tozalash") return setHideStatic(env, true);
  if (cmd === "/tiklash") return setHideStatic(env, false);
  if (cmd === "/narx") {
    const items = await getList(env), p = findP(items, a1), v = parsePrice(parts.slice(2).join(""));
    if (!p || v < 100) return say(env, "Format: /narx ID SOM (masalan /narx 5 150000)");
    p.som = v; await saveList(env, items);
    return say(env, "✅ #" + p.id + " narxi: " + money(v), MENU);
  }
  if (cmd === "/ochir") {
    const items = await getList(env), left = items.filter((x) => x.id !== Number(a1));
    if (left.length === items.length) return say(env, "Bunday ID yo'q.");
    await saveList(env, left);
    return say(env, "🗑 O'chirildi #" + a1, MENU);
  }
  if (cmd === "/yashir") {
    const items = await getList(env), p = findP(items, a1);
    if (!p) return say(env, "Bunday ID yo'q.");
    p.hidden = !p.hidden; await saveList(env, items);
    return say(env, (p.hidden ? "🚫 Yashirildi" : "👁 Ko'rsatildi") + ": #" + p.id, MENU);
  }
  if (cmd === "/ustama" || cmd === "/kurs" || cmd === "/dollar") {
    const s = await getSettings(env), v = Number(a1);
    if (!v) return say(env, "Format: " + cmd + " RAQAM");
    if (cmd === "/ustama") s.markup = v;
    if (cmd === "/kurs") s.rate = v;
    if (cmd === "/dollar") s.usd = v;
    await saveSettings(env, s);
    return say(env, "✅ Saqlandi.", MENU);
  }
  if (cmd === "/cargo") {
    const s = await getSettings(env), x = Number(a1), y = Number(a2);
    if (!x || !y) return say(env, "Format: /cargo AVTO AVIA (dollar/kg), masalan /cargo 6 9");
    s.cargoAuto = x; s.cargoAvia = y; await saveSettings(env, s);
    return say(env, "✅ Cargo: avto $" + x + ", avia $" + y, MENU);
  }
  if (cmd === "/promo") {
    const s = await getSettings(env), code = (a1 || "").toUpperCase(), pct = Number(a2);
    if (!code || !pct) return say(env, "Format: /promo KOD 10");
    s.promos[code] = pct; await saveSettings(env, s);
    return say(env, "✅ Promo: " + code + " — " + pct + "%", MENU);
  }
  if (cmd === "/promo_ochir") {
    const s = await getSettings(env), code = (a1 || "").toUpperCase();
    delete s.promos[code]; await saveSettings(env, s);
    return say(env, "🗑 Promo o'chirildi: " + code, MENU);
  }
  return showMenu(env);
}

// ---------- KOMPYUTERGA YUBORISH (Telegram → kompyuterdagi ilova) ----------
// Rasmlar KV ga metadata bilan yoziladi (o'qish shart emas). Bir papka = bir tovar.
const pcKey = (sid, f, tail) => "pcb:" + sid + ":" + String(f).padStart(3, "0") + ":" + (/^n/.test(String(tail)) ? tail : String(tail).padStart(12, "0"));
async function pcList(env, sid) {
  const out = [];
  let cursor;
  do {
    const ls = await env.PRODUCTS.list({ prefix: "pcb:" + sid + ":", cursor: cursor });
    ls.keys.forEach((k) => out.push({ name: k.name, meta: k.metadata || {} }));
    cursor = ls.list_complete ? undefined : ls.cursor;
  } while (cursor);
  return out.sort((a, b) => (a.name < b.name ? -1 : 1));
}
async function pcStore(env, st, msg, m) {
  const f = st.f || 1, rec = { f: m.f, t: m.t };
  if (msg.caption) rec.x = clean(msg.caption, 300);
  await env.PRODUCTS.put(pcKey(st.sid, f, msg.message_id), "1", { metadata: rec, expirationTtl: 259200 });
  const gid = msg.media_group_id || "m" + msg.message_id;
  if (st.g === gid) return null;
  await setState(env, Object.assign({}, st, { g: gid }));
  return say(env, "📥 " + f + "-papka: rasmlar qabul qilinmoqda... Hammasini tashlab bo'lgach «📤 Kompyuterga yuborish» ni bosing.");
}
async function pcOpen(env, cq, next) {
  const st = await getState(env);
  let sid = st && st.a === "pcbox" ? st.sid : await env.PRODUCTS.get("pcsid");
  if (!sid) { sid = randomId(8); await env.PRODUCTS.put("pcsid", sid, { expirationTtl: 259200 }); }
  const items = await pcList(env, sid), last = items.length ? Number(items[items.length - 1].name.split(":")[2]) : 1;
  const cur = st && st.a === "pcbox" ? st.f || 1 : last;
  const f = next ? Math.max(cur, last) + 1 : cur;
  await setState(env, { a: "pcbox", sid: sid, f: f, g: null });
  const imgs = items.filter((x) => x.meta.t !== "n"), folders = new Set(imgs.map((x) => x.name.split(":")[2]));
  return ui(env, cq,
    "💻 <b>Kompyuterga yuborish</b>\n\nRasmlarni shu chatga tashlang: bir tovarning hamma rasmi bitta papkaga tushadi. Rasm tagiga yoki alohida xabar qilib nom, narx, rang, og'irlik yozsangiz, izoh ham papka bilan birga boradi.\n\n📁 Hozirgi papka: <b>№" + f + "</b>\n📦 Saqlangan: " + folders.size + " ta papka, " + imgs.length + " ta rasm (hisob 1 daqiqagacha kechikishi mumkin)\n\nKeyingi tovarga o'tish uchun «➕ Keyingi tovar» ni bosing.",
    { inline_keyboard: [[btn("➕ Keyingi tovar (yangi papka)", "pcn")], [btn("📤 Kompyuterga yuborish", "pcs")], [btn("⬅️ Menyu", "menu")]] });
}
async function pcConfirm(env, cq) {
  const st = await getState(env), items = st && st.a === "pcbox" ? await pcList(env, st.sid) : [];
  const imgs = items.filter((x) => x.meta.t !== "n" && x.meta.f), folders = new Set(imgs.map((x) => x.name.split(":")[2]));
  if (!imgs.length) return ui(env, cq, "Hali rasm yuborilmagan. Avval rasmlarni shu chatga tashlang.", { inline_keyboard: [[btn("⬅️ Orqaga qaytish", "pcm")]] });
  return ui(env, cq, "📤 <b>Kompyuterga yuborish</b>\n\n📁 " + folders.size + " ta papka (tovar)\n🖼 " + imgs.length + " ta rasm\n\nYuborishni tasdiqlaysizmi? Kompyuterdagi ilova ochiq bo'lsa, o'zi qabul qiladi.",
    { inline_keyboard: [[btn("✅ Ha, kompyuterga yuborish", "pcy")], [btn("⬅️ Orqaga qaytish", "pcm")]] });
}
async function pcSend(env, cq) {
  const st = await getState(env);
  if (!st || st.a !== "pcbox") return showMenu(env, cq);
  const by = {};
  (await pcList(env, st.sid)).forEach((x) => {
    const f = x.name.split(":")[2], o = (by[f] = by[f] || { files: [], notes: [] });
    if (x.meta.t === "n") o.notes.push(x.meta.x);
    else if (x.meta.f) { o.files.push({ f: x.meta.f, t: x.meta.t }); if (x.meta.x) o.notes.push(x.meta.x); }
  });
  const folders = Object.keys(by).sort().map((f) => by[f]).filter((x) => x.files.length);
  if (!folders.length) return ui(env, cq, "Hali rasm yuborilmagan.", { inline_keyboard: [[btn("⬅️ Orqaga qaytish", "pcm")]] });
  await kvPut(env, "pcq:" + Date.now().toString(36), JSON.stringify({ t: Date.now(), folders: folders }), { expirationTtl: 86400 * 14 });
  await env.PRODUCTS.delete("pcsid");
  await setState(env, null);
  const n = folders.reduce((a, x) => a + x.files.length, 0);
  return ui(env, cq, "✅ <b>Yuborildi</b>\n📁 " + folders.length + " ta papka, 🖼 " + n + " ta rasm.\nKompyuterdagi ilova ochiq bo'lsa, bir necha soniyada oladi va shu yerga xabar beradi. Ochiq bo'lmasa, 14 kungacha saqlanadi.", { inline_keyboard: [[btn("⬅️ Menyu", "menu")]] });
}

// ---------- tugmalar ----------
async function handleCallback(env, cq) {
  const data = cq.data || "", q = data.split(":"), id = Number(q[1]), k = q[0];
  if (data === "menu") { await setState(env, null); return showMenu(env, cq); }
  if (data === "addmenu") {
    const rows = chunk(CATEGORIES.map((c) => btn(c[1], "cat:" + c[0])), 2);
    rows.push([btn("⬅️ Menyu", "menu")]);
    return ui(env, cq, "➕ <b>Yangi tovar</b>\nQaysi kategoriyada?", { inline_keyboard: rows });
  }
  if (k === "cat") {
    if (!CATEGORIES.some((c) => c[0] === q[1])) return showMenu(env, cq);
    const items = await getList(env), nid = items.reduce((m, p) => Math.max(m, p.id), 0) + 1;
    items.push({ id: nid, n: "Yangi tovar", som: 0, y: 0, kg: 0.5, c: q[1], olcham: [], colors: [], rang: [], av: false, b: BG[nid % BG.length], s: 0, hidden: true, draft: true, media: [] });
    await saveList(env, items);
    return wizGo(env, nid, 1, cq);
  }
  if (data === "pcm" || data === "pcn") return pcOpen(env, cq, data === "pcn");
  if (data === "pcs") return pcConfirm(env, cq);
  if (data === "pcy") return pcSend(env, cq);
  if (data === "hideold") return setHideStatic(env, true);
  if (data === "showold") return setHideStatic(env, false);
  if (data === "prods") return showProducts(env, cq, 0);
  if (k === "pl") return showProducts(env, cq, id);
  if (data === "find") { await setState(env, { a: "find" }); return ui(env, cq, "🔍 Tovar nomini (yoki ID) yozing:", { inline_keyboard: [[btn("⬅️ Tovarlar", "prods")]] }); }
  if (data === "help") return ui(env, cq, HELP, MENU);
  if (data === "ords") return showOrders(env, cq);
  if (data === "ordsn") return showOrders(env, cq, "yangi", 0);
  if (k === "ol") return showOrders(env, cq, q[1], q[2]);
  if (k === "oo" || k === "oc") return orderCard(env, cq, q[1], q[2], q[3]);
  if (k === "om") return orderCard(env, cq, q[1], q[2], q[3], true);
  if (k === "ph") return sendOrderPhotos(env, q[1]);
  if (data === "nop") return null;
  if (data === "ua") return showAccounts(env, cq);
  if (data === "ut") return showAccTypes(env, cq);
  if (k === "ub") return showAccList(env, cq, q[1], q[2]);
  if (k === "uc") return showAccProfile(env, cq, q[1], q[2]);
  if (k === "ud") return showAccOrder(env, cq, q[1], q[2], q[3]);
  if (data === "stats") return showStats(env, cq);
  if (data === "promos") return showPromos(env);
  if (data === "settings") return showSettings(env);

  if (k === "wc") {
    const items = await getList(env), p = findP(items, id);
    if (p && p.draft) await saveList(env, items.filter((x) => x.id !== id));
    await setWiz(env, null); await setState(env, null);
    return say(env, "❌ Bekor qilindi.", MENU);
  }
  if (k === "p") return showCard(env, id, -1, cq);
  if (k === "cv") return showCard(env, id, Number(q[2]), cq);
  if (k === "al") {
    const p = findP(await getList(env), id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    return sendAlbum(env, q[2] === "g" ? p.media : gal(p, Number(q[2])));
  }

  // oddiy tahrir
  if (k === "en") return askName(env, cq, id);
  if (k === "ep") return askPrice(env, cq, id);
  if (k === "ek") return askKg(env, cq, id);
  if (k === "es") return sizeEditor(env, cq, id, null);
  if (k === "ec") return colorEditor(env, cq, id);
  if (k === "esold") { await setState(env, { a: "sold", id: id }); return ui(env, cq, "🔥 Sotilgan sonini yozing (masalan 1200):", { inline_keyboard: [[btn("⬅️ Tovar", "p:" + id)]] }); }
  if (k === "wkx") { await setState(env, { a: "kg", id: id }); return ui(env, cq, "⚖️ Og'irlikni kg da yozing (masalan 0.35):", await cancelKb(env, id)); }
  if (k === "wk" || k === "av" || k === "ppc" || k === "ca" || k === "ea" || k === "pv" || k === "pdup") {
    const items = await getList(env), p = findP(items, id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    if (k === "wk") { p.kg = parseKg(q[2]) || p.kg; await saveList(env, items); return after(env, id, 3, cq); }
    if (k === "av") { p.av = q[2] === "1"; await saveList(env, items); return after(env, id, 6, cq); }
    if (k === "ppc") {
      p.som = Math.max(100, Math.round((p.som * (1 + Number(q[2]) / 100)) / 100) * 100);
      await saveList(env, items);
      return askPrice(env, cq, id);
    }
    if (k === "ca") { p.c = q[2]; await saveList(env, items); return showCard(env, id, -1, cq); }
    if (k === "ea") { p.av = !p.av; await saveList(env, items); return showCard(env, id, -1, cq); }
    if (k === "pv") { p.hidden = !p.hidden; await saveList(env, items); return showCard(env, id, -1, cq); }
    if (k === "pdup") {
      const nid = items.reduce((m, x) => Math.max(m, x.id), 0) + 1, c = JSON.parse(JSON.stringify(p));
      c.id = nid; c.n = clean(p.n + " (nusxa)", 80); c.hidden = true; c.s = 0;
      items.push(c); await saveList(env, items);
      await say(env, "📑 Nusxa yaratildi (yashirin). Nomini va narxini o'zgartiring, keyin '👁 Saytda ko'rsat' ni bosing.");
      return showCard(env, nid, -1, null);
    }
  }
  if (k === "ecat") {
    const rows = chunk(CATEGORIES.map((c) => btn(c[1], "ca:" + id + ":" + c[0])), 2);
    rows.push([btn("⬅️ Tovar", "p:" + id)]);
    return ui(env, cq, "📂 <b>Kategoriyani tanlang:</b>", { inline_keyboard: rows });
  }

  // o'lcham
  if (k === "zs") return sizeEditor(env, cq, id, q[2]);
  if (k === "zt") {
    const items = await getList(env), p = findP(items, id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    const set = q[2], opts = SZ[set].concat(p.olcham.filter((x) => SZ[set].indexOf(x) < 0)), x = opts[Number(q[3])];
    if (x) {
      const at = p.olcham.indexOf(x);
      if (at >= 0) p.olcham.splice(at, 1); else p.olcham.push(x);
      const order = [].concat(SZ.L, SZ.N, SZ.K);
      p.olcham.sort((a, b) => { const ia = order.indexOf(a), ib = order.indexOf(b); return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || (a > b ? 1 : -1); });
      await saveList(env, items);
    }
    return sizeEditor(env, cq, id, set);
  }
  if (k === "zx") { await setState(env, { a: "szadd", id: id }); return ui(env, cq, "✍️ O'lchamlarni yozing (vergul bilan), masalan: 46, 47 yoki 128 sm, 134 sm", await cancelKb(env, id)); }
  if (k === "zc" || k === "zd") {
    if (k === "zc") { const items = await getList(env), p = findP(items, id); if (p) { p.olcham = []; await saveList(env, items); } }
    return after(env, id, 4, cq);
  }

  // rang
  if (k === "ct") {
    const items = await getList(env), p = findP(items, id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    const n = colorOpts(p)[Number(q[2])];
    if (n) {
      const at = p.colors.findIndex((c) => c.n === n);
      if (at >= 0) {
        if (p.colors[at].media.length && q[3] !== "y") {
          return ui(env, null, "⚠️ «" + h(n) + "» rangida " + p.colors[at].media.length + " ta rasm/video bor. Rangni olib tashlasangiz ular ham o'chadi.", { inline_keyboard: [[btn("✅ Ha, olib tashla", "ct:" + id + ":" + q[2] + ":y"), btn("❌ Yo'q", "ec:" + id)]] });
        }
        p.colors.splice(at, 1);
      } else p.colors.push({ n: n, media: [] });
      await saveList(env, items);
    }
    return colorEditor(env, q[3] === "y" ? null : cq, id);
  }
  if (k === "cx") { await setState(env, { a: "coladd", id: id }); return ui(env, cq, "✍️ Rang nomini yozing (bir nechta bo'lsa vergul bilan), masalan: Zumrad, Olov", await cancelKb(env, id)); }
  if (k === "cc" || k === "cd") {
    if (k === "cc") { const items = await getList(env), p = findP(items, id); if (p) { p.colors = []; await saveList(env, items); } }
    return after(env, id, 5, cq);
  }
  if (k === "cn") { await setState(env, { a: "cname", id: id, ci: Number(q[2]) }); return ui(env, cq, "✏️ Rangning yangi nomini yozing:", { inline_keyboard: [[btn("⬅️ Orqaga", "mt:" + id + ":" + q[2])]] }); }

  // media
  if (k === "mm") return mediaChooser(env, cq, id);
  if (k === "mt") return mediaTarget(env, cq, id, q[2]);
  if (k === "am" || k === "rm") {
    await flushUploads(env);
    const items = await getList(env), p = findP(items, id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    const isG = q[2] === "g", ci = isG ? "g" : Number(q[2]), arr = isG ? p.media : (p.colors[ci] || {}).media;
    if (!arr) return say(env, "Rang topilmadi.", MENU);
    if (k === "rm") { arr.length = 0; await saveList(env, items); }
    const st = { a: "addmedia", id: id, ci: ci, seq: [ci], pos: 0, wiz: false };
    await setState(env, st);
    return askMedia(env, cq, st);
  }
  if (k === "mdn") {
    const st = await getState(env);
    if (!st || st.a !== "addmedia") return showMenu(env, cq);
    await flushUploads(env);
    if (st.wiz && st.pos + 1 < st.seq.length) {
      st.pos++; st.ci = st.seq[st.pos]; st.g = null;
      await setState(env, st);
      return askMedia(env, cq, st);
    }
    await setState(env, null);
    if (st.wiz) return wizFinish(env, st.id, cq);
    return mediaTarget(env, null, st.id, String(st.ci));
  }
  if (k === "ml" || k === "mc" || k === "mcy") {
    await flushUploads(env);
    const items = await getList(env), p = findP(items, id);
    if (!p) return say(env, "Tovar topilmadi.", MENU);
    const arr = q[2] === "g" ? p.media : (p.colors[Number(q[2])] || {}).media;
    if (!arr) return say(env, "Topilmadi.", MENU);
    if (k === "mc") return ui(env, cq, "🧹 Hamma " + arr.length + " ta rasm/video o'chirilsinmi?", { inline_keyboard: [[btn("✅ Ha", "mcy:" + id + ":" + q[2]), btn("❌ Yo'q", "mt:" + id + ":" + q[2])]] });
    if (k === "ml") arr.pop(); else arr.length = 0;
    await saveList(env, items);
    return mediaTarget(env, cq, id, q[2]);
  }

  // o'chirish
  if (k === "pd") return ui(env, cq, "#" + id + " tovarni o'chirasizmi?", { inline_keyboard: [[btn("✅ Ha, o'chir", "pdy:" + id), btn("❌ Yo'q", "p:" + id)]] });
  if (k === "pdy") {
    await saveList(env, (await getList(env)).filter((x) => x.id !== id));
    return say(env, "🗑 O'chirildi #" + id, MENU);
  }
  if (k === "mk") {
    const s = await getSettings(env);
    s.markup = Number(q[1]); await saveSettings(env, s);
    return say(env, "✅ Ustama: " + s.markup + "%", MENU);
  }
  if (k === "pdel") {
    const s = await getSettings(env), code = data.slice(5);
    delete s.promos[code]; await saveSettings(env, s);
    return say(env, "🗑 Promo o'chirildi: " + code, MENU);
  }
  if (k === "tk") {
    const oid = q[1], o = (await getOrders(env)).find((x) => String(x.id) === oid);
    if (!o) return say(env, "Buyurtma topilmadi.", MENU);
    await setState(env, { a: "trk", oid: oid });
    return say(env, "📦 #" + oid + " uchun trek kodni yozing" + (o.trk ? " (hozirgi: " + o.trk + ")" : "") + ":", { inline_keyboard: [[btn("❌ Bekor", "tkx")]] });
  }
  if (data === "tkx") { await setState(env, null); return say(env, "Bekor qilindi.", MENU); }
  if (k === "ch") {
    const key = q[1], c = await ensureChat(env, key);
    if (!c) return say(env, "Chat topilmadi.", MENU);
    await setState(env, { a: "chat", key: key });
    const hist = (c.m || []).slice(-5).map((x) => (x.f === "a" ? "Siz: " : "Mijoz: ") + x.t).join("\n");
    return say(env, "💬 " + chatTitle(c) + (hist ? "\n\n" + hist : "") + "\n\nEndi yozganingiz mijozga boradi. Chiqish: /stop", { inline_keyboard: [[btn("🚪 Chatdan chiqish", "chx")]] });
  }
  if (data === "chx") { await setState(env, null); return say(env, "Chatdan chiqdingiz.", MENU); }
  if (k === "os") {
    const oid = q[1], st = q[2];
    const orders = await getOrders(env), o = orders.find((x) => String(x.id) === oid);
    if (!o) return say(env, "Buyurtma topilmadi.", MENU);
    o.status = st; await saveOrders(env, orders);
    await notifyCustomer(env, o, "📦 Buyurtma #" + oid + " holati: " + (STATUSES[st] || st));
    if (st === "topshirildi") { try { await vReviewAsk(env, o); } catch (e) { /* sharh so'rovi ixtiyoriy */ } }
    if (cq.message) return orderCard(env, cq, oid, q[3], q[4]);
    return say(env, "#" + oid + " holati: " + (STATUSES[st] || st), MENU);
  }
  return showMenu(env, cq);
}

// ---------- AKKAUNTLAR (admin bot) ----------
// accidx: barcha akkauntlar indeksi. Login paytida yangilanadi, admin uni bitta KV o'qishda oladi.
const ACC_MAX = 3000;
const dt = (t) => (t ? new Date(Number(t) + 5 * 3600e3).toISOString().slice(0, 16).replace("T", " ") : "—");
const getAcc = async (env) => (await env.PRODUCTS.get("accidx", "json")) || [];
async function upsertAcc(env, r) {
  Object.keys(r).forEach((k) => { if (r[k] === undefined || r[k] === null) delete r[k]; });
  const list = await getAcc(env), now = Date.now();
  const i = list.findIndex((x) => x.k === r.k);
  if (i >= 0) list[i] = Object.assign({}, list[i], r, { last: now });
  else list.push(Object.assign({ created: now, last: now }, r));
  list.sort((a, b) => (b.last || 0) - (a.last || 0));
  try { await kvPut(env, "accidx", JSON.stringify(list.slice(0, ACC_MAX))); } catch (e) { /* ro'yxat yangilanmasa ham kirish davom etadi */ }
}
// Eski akkauntlarni bir marta yig'ish: buyurtmalardan + g: yozuvlaridan (bitta ro'yxat o'qish)
async function syncAccounts(env) {
  const map = new Map((await getAcc(env)).map((r) => [r.k, r]));
  (await getOrders(env)).forEach((o) => {
    if (o.tg && !map.has("t" + o.tg)) map.set("t" + o.tg, { k: "t" + o.tg, p: "t", id: o.tg, name: o.name, phone: o.phone, created: o.t, last: o.t });
    if (o.g && !map.has("g" + o.g)) map.set("g" + o.g, { k: "g" + o.g, p: "g", id: o.g, name: o.name, phone: o.phone, created: o.t, last: o.t });
  });
  let cursor;
  do {
    const ls = await env.PRODUCTS.list({ prefix: "g:", cursor: cursor });
    for (const key of ls.keys) {
      const sub = key.name.slice(2);
      if (map.has("g" + sub)) continue;
      const acc = await env.PRODUCTS.get(key.name, "json");
      if (acc) map.set("g" + sub, { k: "g" + sub, p: "g", id: sub, name: acc.name, email: acc.email, phone: acc.phone, created: 0, last: 0 });
    }
    cursor = ls.list_complete ? undefined : ls.cursor;
  } while (cursor);
  const out = [...map.values()].sort((a, b) => (b.last || 0) - (a.last || 0));
  await env.PRODUCTS.put("accidx", JSON.stringify(out.slice(0, ACC_MAX)));
}
const accName = (r) => (r.p === "t" && r.un ? "@" + r.un : r.name || "Mijoz");
const accLabel = (r) => accName(r) + (r.p === "g" ? (r.email ? " · " + r.email : "") : (r.phone ? " · " + r.phone : ""));
const PROV = (p) => (p === "g" ? "🔵 Google" : "✈️ Telegram");

// 1-ekran: faqat jami
async function showAccounts(env, cq) {
  let all = await getAcc(env);
  if (!all.length) { await syncAccounts(env); all = await getAcc(env); }
  return ui(env, cq, "👥 <b>Akkauntlar</b>\nJami: " + all.length + " ta", {
    inline_keyboard: [[btn("📋 Ko'rish", "ut")], [btn("⬅️ Menyu", "menu")]],
  });
}
// 2-ekran: faqat Telegram / Google
async function showAccTypes(env, cq) {
  return ui(env, cq, "👥 <b>Akkaunt turi</b>\nQaysi usul bilan kirganlarni ko'rish?", {
    inline_keyboard: [[btn("🔵 Google", "ub:g:0"), btn("✈️ Telegram", "ub:t:0")], [btn("⬅️ Orqaga", "ua")]],
  });
}
// 3-ekran: shu turdagi akkauntlar, ketma-ket, sahifalangan
async function showAccList(env, cq, f, page) {
  const all = (await getAcc(env)).filter((r) => r.p === f);
  const per = 10, pages = Math.max(1, Math.ceil(all.length / per));
  page = Math.min(Math.max(0, Number(page) || 0), pages - 1);
  const rows = all.slice(page * per, page * per + per).map((r) => [btn(accLabel(r).slice(0, 56), "uc:" + r.k + ":0")]);
  if (pages > 1) rows.push([btn(page > 0 ? "◀️" : "·", page > 0 ? "ub:" + f + ":" + (page - 1) : "nop"), btn((page + 1) + "/" + pages, "nop"), btn(page < pages - 1 ? "▶️" : "·", page < pages - 1 ? "ub:" + f + ":" + (page + 1) : "nop")]);
  rows.push([btn("⬅️ Orqaga", "ut")]);
  return ui(env, cq, "<b>" + PROV(f) + "</b> · " + all.length + " ta" + (all.length ? "\nAkkauntni bosing:" : "\n\nBu turda akkaunt yo'q."), { inline_keyboard: rows });
}
// 4-ekran: bitta akkaunt — ma'lumotlari va buyurtmalari (ixcham tugmalar)
async function showAccProfile(env, cq, key, page) {
  const r = (await getAcc(env)).find((x) => x.k === key);
  if (!r) return ui(env, cq, "Akkaunt topilmadi.", { inline_keyboard: [[btn("⬅️ Orqaga", "ut")]] });
  const mine = (await getOrders(env))
    .filter((o) => (r.p === "t" ? String(o.tg) === String(r.id) : String(o.g) === String(r.id)))
    .sort((a, b) => (b.t || 0) - (a.t || 0));
  const total = mine.reduce((a, o) => a + (o.total || 0), 0);
  const per = 8, pages = Math.max(1, Math.ceil(mine.length / per));
  page = Math.min(Math.max(0, Number(page) || 0), pages - 1);
  const rows = mine.slice(page * per, page * per + per).map((o) => [btn(stEmoji(o.status) + " #" + o.id + " · " + money(o.total).replace(" so'm", ""), "ud:" + o.id + ":" + key + ":" + page)]);
  if (pages > 1) rows.push([btn(page > 0 ? "◀️" : "·", page > 0 ? "uc:" + key + ":" + (page - 1) : "nop"), btn((page + 1) + "/" + pages, "nop"), btn(page < pages - 1 ? "▶️" : "·", page < pages - 1 ? "uc:" + key + ":" + (page + 1) : "nop")]);
  rows.push([btn("⬅️ Orqaga", "ub:" + r.p + ":0")]);
  const lines = [PROV(r.p), "<b>" + h(accName(r)) + "</b>"];
  if (r.p === "t" && r.name) lines.push("👤 " + h(r.name));
  lines.push("📞 " + h(r.phone || "—"));
  if (r.p === "g") lines.push("📧 " + h(r.email || "—"));
  lines.push("🕒 Oxirgi kirish: " + dt(r.last), "📅 Ro'yxatdan: " + dt(r.created), "", "📦 Buyurtmalar: " + mine.length + " ta · " + money(total));
  lines.push(mine.length ? "\nBuyurtmani bosing:" : "\nBuyurtma yo'q.");
  return ui(env, cq, lines.join("\n"), { inline_keyboard: rows });
}
// 5-ekran: bitta buyurtmaning hamma ma'lumoti va rasmi
async function showAccOrder(env, cq, oid, key, page) {
  const o = (await getOrders(env)).find((x) => String(x.id) === String(oid));
  if (!o) return ui(env, cq, "Buyurtma topilmadi.", { inline_keyboard: [[btn("⬅️ Orqaga", "uc:" + key + ":0")]] });
  const rows = statusRows(o.id, o.status || "yangi");
  if (o.ck || (o.ph && o.ph.length)) rows.push([btn("🧾 Chek va rasmlar", "ph:" + o.id)]);
  rows.push([btn("⬅️ Orqaga", "uc:" + key + ":" + (page || 0))]);
  return ui(env, cq, orderHtml(o), { inline_keyboard: rows });
}

// ---------- webhook ----------
async function handleWebhook(request, env) {
  if (request.headers.get("X-Telegram-Bot-Api-Secret-Token") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
  const update = await request.json();
  if (vIsMine(update)) return vHandleUpdate(request, env, update);
  if (update.callback_query) {
    const cq = update.callback_query;
    await tg(env, "answerCallbackQuery", { callback_query_id: cq.id });
    if (String(cq.from.id) !== String(env.CHAT_ID)) return new Response("ok");
    try { await handleCallback(env, cq); } catch (e) { await say(env, "⚠️ Xatolik: " + String(e && e.message || e).slice(0, 200), MENU); }
    return new Response("ok");
  }
  const msg = update.message;
  if (!msg || String(msg.chat.id) !== String(env.CHAT_ID)) return new Response("ok");
  try {
    const m = getMedia(msg);
    if (m) await queueMedia(env, msg, m);
    else if (msg.text && msg.reply_to_message) {
      const ck = await env.PRODUCTS.get("cm:" + msg.reply_to_message.message_id);
      if (ck) await adminReply(env, ck, msg.text); else await handleText(env, msg.text);
    }
    else if (msg.text) await handleText(env, msg.text);
  } catch (e) { await say(env, "⚠️ Xatolik: " + String(e && e.message || e).slice(0, 200), MENU); }
  return new Response("ok");
}

// ---------- sayt uchun media (kesh + Range + ixtiyoriy kichraytirish) ----------
// Kichraytirish faqat Worker sozlamalarida IMG_RESIZE = 1 bo'lsa va Cloudflare'da Image transformations yoqilgan bo'lsa ishlaydi
const IMG_W = { 240: 1, 360: 1, 480: 1, 720: 1, 900: 1, 1200: 1 };
async function serveMedia(request, env, ctx, fileId) {
  try { fileId = decodeURIComponent(fileId); } catch (e) { return new Response("not found", { status: 404 }); }
  if (!/^[A-Za-z0-9_.\-]{5,220}$/.test(fileId)) return new Response("not found", { status: 404 });
  const wq = Number(new URL(request.url).searchParams.get("w") || 0), w = env.IMG_RESIZE === "1" && IMG_W[wq] ? wq : 0;
  const cache = caches.default, key = new Request("https://sarbon-cache.local/m/" + fileId + (w ? "_w" + w : ""));
  let buf = null, type = "";
  const hit = await cache.match(key);
  if (hit) { buf = await hit.arrayBuffer(); type = hit.headers.get("Content-Type") || ""; }
  if (!buf) {
    let path = await env.PRODUCTS.get("fp:" + fileId);
    if (!path) {
      const info = await tg(env, "getFile", { file_id: fileId });
      if (!info.ok) return new Response("not found", { status: 404 });
      path = info.result.file_path;
      await env.PRODUCTS.put("fp:" + fileId, path, { expirationTtl: 3000 });
    }
    const ext = (path.split(".").pop() || "").toLowerCase();
    const init = { cf: { cacheEverything: true, cacheTtlByStatus: { "200-299": 86400, "400-599": 0 } } };
    const resize = w && /^(jpe?g|png|webp)$/.test(ext);
    if (resize) init.cf.image = { width: w, quality: 80, fit: "scale-down", format: "webp" };
    const up = await fetch("https://api.telegram.org/file/bot" + env.BOT_TOKEN + "/" + path, init);
    if (!up.ok) return new Response("not found", { status: 404 });
    buf = await up.arrayBuffer();
    const ct = up.headers.get("Content-Type") || "";
    type = resize && /^image\//.test(ct) ? ct : MIME[ext] || "application/octet-stream";
    if (ctx && ctx.waitUntil) ctx.waitUntil(cache.put(key, new Response(buf, { headers: { "Content-Type": type, "Cache-Control": "public, max-age=86400" } })));
  }
  const total = buf.byteLength;
  const headers = new Headers({ "Content-Type": type || "application/octet-stream", "Cache-Control": "public, max-age=86400, immutable", "Accept-Ranges": "bytes", "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*" });
  const range = request.headers.get("Range"), mm = range ? /bytes=(\d*)-(\d*)/.exec(range) : null;
  if (mm && (mm[1] || mm[2])) {
    let start, end;
    if (mm[1]) { start = Number(mm[1]); end = mm[2] ? Math.min(Number(mm[2]), total - 1) : total - 1; }
    else { start = Math.max(0, total - Number(mm[2])); end = total - 1; }
    if (start > end || start >= total) { headers.set("Content-Range", "bytes */" + total); return new Response(null, { status: 416, headers: headers }); }
    headers.set("Content-Range", "bytes " + start + "-" + end + "/" + total);
    headers.set("Content-Length", String(end - start + 1));
    return new Response(buf.slice(start, end + 1), { status: 206, headers: headers });
  }
  headers.set("Content-Length", String(total));
  return new Response(buf, { status: 200, headers: headers });
}
const pubMedia = (a) => a.map((m) => ({ u: "/m/" + m.f, t: m.t }));
const pubProduct = (p, s) => {
  const price = s ? priceOf(p, s) : 0;
  const fi = p.media.concat(...p.colors.map((c) => c.media)).find((x) => x.t === "i");
  return {
    id: p.id, n: p.n, y: s ? price : p.y || 0, som: s ? price : p.som > 0 ? p.som : 0, dl: (p.y || 0) <= 25 ? 1 : 0, kg: p.kg, c: p.c, olcham: p.olcham, av: p.av, b: p.b, s: p.s, d: p.d || undefined,
    img: fi ? "/m/" + fi.f : "", media: pubMedia(p.media), rang: p.colors.map((c) => ({ n: c.n, media: pubMedia(c.media) })),
  };
};

// ---------- buyurtma ----------
const hasChekData = (c) => typeof c === "string" && c.startsWith("data:image") && c.length < 4000000;
async function sendExtras(env, body, oid) {
  const out = { ph: [], ck: "" };
  try {
    const products = await getListPub(env);
    const picks = (Array.isArray(body.items) ? body.items : []).filter((it) => it && it.pid).slice(0, 3);
    const shots = [];
    for (const it of picks) {
      const p = findP(products, it.pid);
      if (!p) continue;
      const c = p.colors.find((x) => x.n === it.col);
      const m = (c ? c.media : []).concat(p.media).find((x) => x.t === "i");
      if (!m) continue;
      shots.push({ f: m.f, cap: clean(p.n, 100) + (it.col ? " (" + clean(it.col, 30) + ")" : "") + " x" + Math.max(1, Math.min(99, Number(it.q) || 1)) });
    }
    out.ph = shots.map((x) => x.f);
    // Telegram'ga 3 ta alohida emas, bitta so'rov bilan yuboriladi (limitga kam tegadi)
    if (shots.length === 1) await tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: shots[0].f, caption: shots[0].cap });
    else if (shots.length > 1) await tg(env, "sendMediaGroup", { chat_id: env.CHAT_ID, media: shots.map((x) => ({ type: "photo", media: x.f, caption: x.cap })) });
    if (hasChekData(body.chek)) {
      const bin = atob(body.chek.split(",")[1]), bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const form = new FormData();
      form.append("chat_id", String(env.CHAT_ID));
      form.append("caption", "🧾 Chek #" + oid);
      form.append("photo", new Blob([bytes], { type: "image/jpeg" }), "chek.jpg");
      let r = null;
      for (let i = 0; i < 2; i++) {
        r = await fetch("https://api.telegram.org/bot" + env.BOT_TOKEN + "/sendPhoto", { method: "POST", body: form }).then((x) => x.json()).catch(() => null);
        if (r && r.ok) break;
        if (r && r.error_code === 429) await sleep(Math.min((r.parameters && r.parameters.retry_after) || 1, 4) * 1000 + 200); else break;
      }
      const arr = r && r.result && r.result.photo;
      if (arr && arr.length) out.ck = arr[arr.length - 1].file_id;
    }
  } catch (e) { /* buyurtma saqlangan */ }
  return out;
}
async function handleOrder(env, body, origin) {
  const name = clean(body.name, 60).trim(), phone = clean(body.phone, 20).trim();
  const items = Array.isArray(body.items) ? body.items.filter((it) => it && typeof it === "object").slice(0, 30) : [];
  if (name.length < 2 || !/^\+?\d{9,15}$/.test(phone.replace(/[\s-]/g, "")) || items.length === 0) return json({ ok: false, error: "invalid" }, 400, origin);
  const sessKey = String(body.session || "").replace(/[^a-z0-9]/g, "");
  const sess = sessKey ? await getSession(env, sessKey) : null;
  const ownerC = sess ? ownerOf(sess) : "";
  const oid = Date.now().toString(36).toUpperCase() + Math.floor(Math.random() * 100);
  // shaxsiy kupon: faqat egasi, bir marta ishlatiladi. Ikki buyurtmada ishlatilmasligi uchun DARHOL band qilinadi.
  const couponCode = String(body.coupon || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  let cpList = null, cpItem = null;
  if (couponCode) {
    cpList = ownerC ? await getCoupons(env, ownerC) : [];
    cpItem = cpList.find((c) => c.code === couponCode && !c.used) || null;
    if (!cpItem) return json({ ok: false, error: "coupon" }, 400, origin);
    cpItem.used = true; cpItem.usedAt = Date.now(); cpItem.oid = oid;
    try { await putCoupons(env, ownerC, cpList); } catch (e) { return json({ ok: false, error: "server" }, 500, origin); }
  }
  const undoCoupon = async () => {
    if (!cpItem) return;
    try { cpItem.used = false; delete cpItem.usedAt; delete cpItem.oid; await putCoupons(env, ownerC, cpList); } catch (e) { /* qo'lda tiklanadi */ }
  };
  const lines = items.map((it, i) => {
    const extra = [it.sz, it.col].filter(Boolean).join(", ");
    return (i + 1) + ". " + clean(it.n, 120) + (extra ? " (" + clean(extra, 40) + ")" : "") + " x" + Math.max(1, Math.min(99, Number(it.q) || 1)) + " [" + (it.m === "avia" ? "avia" : "avto") + "]";
  });
  let sub = num(body.subtotal), disc = num(body.discount), cg = num(body.cargo), tot = num(body.total);
  const warns = [];
  // Narx va chegirma serverda qayta hisoblanadi: saytdan kelgan summaga ishonilmaydi
  try {
    const [prods, st] = await Promise.all([getListPub(env), getSettingsPub(env)]);
    let srv = 0, srvCg = 0, miss = 0;
    items.forEach((it) => {
      const p = findP(prods, it.pid);
      if (!p) { miss++; return; }
      const q = Math.max(1, Math.min(99, Number(it.q) || 1));
      srv += priceOf(p, st) * q;
      srvCg += cargoOf(p, st, it.m) * q;
    });
    if (miss) {
      warns.push("⚠️ Tovar serverda topilmadi, narxlar tekshirilmadi");
    } else {
      if (Math.abs(srv - sub) > Math.max(3000, srv * 0.02)) { warns.push("⚠️ NARX MOS EMAS! Saytdan: " + money(sub) + ", serverda: " + money(srv) + " (server narxi olindi)"); sub = srv; }
      if (Math.abs(srvCg - cg) > Math.max(3000, srvCg * 0.05)) warns.push("⚠️ Cargo mos emas: saytdan " + money(cg) + ", serverda " + money(srvCg));
      // Ruxsat etilgan chegirma foizi: umumiy promo YOKI \"birinchi 10 buyurtma\" (kattasi) + shaxsiy kupon
      const words = String(body.promo || "").toUpperCase().split(/[^A-Z0-9]+/).filter(Boolean);
      let prevCnt = -1; // sessiya bo'lmasa tekshirib bo'lmaydi
      if (ownerC) { try { prevCnt = ((await env.PRODUCTS.get("oi:" + ownerC, "json")) || []).length; } catch (e) { prevCnt = -1; } }
      let pctGen = 0;
      Object.keys(st.promos || {}).forEach((k) => {
        const kk = String(k).toUpperCase();
        if (kk === "SARBON10" && prevCnt >= FIRST_ORDERS) return; // SARBON10 faqat birinchi buyurtmalarga
        if (kk && words.indexOf(kk) >= 0) pctGen = Math.max(pctGen, (Number(st.promos[k]) || 0) / 100);
      });
      let pctFirst = 0.1; // sessiya bo'lmasa tekshirib bo'lmaydi: eski qoida (10%) saqlanadi
      if (ownerC) {
        try { const prevIds = (await env.PRODUCTS.get("oi:" + ownerC, "json")) || []; pctFirst = prevIds.length < FIRST_ORDERS ? 0.1 : 0; } catch (e) { pctFirst = 0.1; }
      }
      const pctCp = cpItem ? (Number(cpItem.pct) || 0) / 100 : 0;
      const maxDisc = Math.round((sub * (Math.max(pctGen, pctFirst) + pctCp)) / 1000) * 1000;
      if (disc > maxDisc + 1000) {
        warns.push("⚠️ Chegirma ruxsatdan katta: saytdan " + money(disc) + ", ruxsat " + money(maxDisc) + " (server hisobi olindi)");
        disc = maxDisc;
      }
      if (Math.abs(tot - (sub - disc)) > 1000) warns.push("⚠️ Jami summa serverda qayta hisoblandi: saytdan " + money(tot) + ", serverda " + money(sub - disc));
      tot = sub - disc;
    }
  } catch (e) { /* tekshiruv ixtiyoriy */ }
  // Bir xil chek rasmini ikkinchi marta ishlatishni aniqlaydi
  const hasChek = hasChekData(body.chek);
  if (hasChek) {
    try {
      const dig = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(body.chek));
      const hex = Array.from(new Uint8Array(dig)).slice(0, 12).map((b) => b.toString(16).padStart(2, "0")).join("");
      const prev = await env.PRODUCTS.get("ck:" + hex);
      if (prev && prev !== oid) warns.push("⚠️ BU CHEK AVVAL #" + prev + " BUYURTMADA ISHLATILGAN!");
      else if (!prev) await kvPut(env, "ck:" + hex, oid, { expirationTtl: 60 * 60 * 24 * 180 });
    } catch (e) { /* tekshiruv ixtiyoriy */ }
  }
  const text = [
    "🛒 Yangi buyurtma #" + oid, "", "👤 " + name, "📞 " + phone, "", ...lines, "",
    "💰 Tovarlar: " + money(sub),
    body.promo ? "🎟 Promo: " + clean(body.promo, 40) + " (−" + money(disc) + ")" : "",
    cpItem ? "🎁 Kupon: " + cpItem.code + " (" + cpItem.pct + "%, bir martalik)" : "",
    "🚚 Cargo (taxminiy): " + money(cg), "📍 Filial (UzPost): " + clean(body.uzp, 120),
    hasChek ? "🧾 Chek: ilova qilingan ✅" : "🧾 Chek: yo'q ⚠️", warns.join("\n"), "✅ Jami: " + money(tot),
  ].filter((l) => l !== "").join("\n");
  const ex = await sendExtras(env, body, oid);
  const order = { uzp: clean(body.uzp, 120), ph: ex.ph, ck: ex.ck, id: oid, name: name, phone: phone, summary: lines.join("\n"), total: tot, status: "yangi", t: Date.now(), tg: sess ? sess.tgId || null : null, g: sess ? sess.gid || null : null, pids: items.map((it) => Math.floor(Number(it.pid)) || 0) };
  let saved = false;
  // 1) alohida kalitga zaxira (muddatsiz): umumiy ro'yxatga yozilmasa yoki 200 tadan oshsa ham yo'qolmaydi
  try { await kvPut(env, "ob:" + oid, JSON.stringify(order)); saved = true; } catch (e) { /* zaxira yozilmasa ham davom etamiz */ }
  // 2) mijozning shaxsiy indeksi (Buyurtmalarim va chat eski buyurtmalar uchun ham ishlashi uchun)
  if (ownerC) {
    try { const ids = (await env.PRODUCTS.get("oi:" + ownerC, "json")) || []; ids.unshift(oid); await kvPut(env, "oi:" + ownerC, JSON.stringify(ids.slice(0, 300))); } catch (e) { /* indeks ixtiyoriy */ }
  }
  // 3) umumiy ro'yxatga qo'shish (admin bot shu yerdan ko'radi)
  try { const orders = await getOrders(env); orders.unshift(order); await saveOrders(env, orders); saved = true; } catch (e) { /* Telegram xabari baribir ketadi */ }
  let res = await say(env, text, { inline_keyboard: statusRows(oid, "yangi", "yangi:0") });
  if (!res.ok) { await sleep(1500); res = await say(env, text, { inline_keyboard: statusRows(oid, "yangi", "yangi:0") }); }
  // Buyurtma saqlangan bo'lsa, Telegram sekin bo'lsa ham mijozga "ok" qaytadi (takroriy buyurtma bo'lmasligi uchun)
  if (!res.ok && !saved) { await undoCoupon(); return json({ ok: false, error: "telegram" }, 502, origin); }
  return json({ ok: true, id: oid }, 200, origin);
}

// ---------- ZAXIRA NUSXA (har kuni Telegramga) ----------
async function backupToTelegram(env) {
  const now = new Date().toISOString();
  const data = {
    t: now,
    list: await env.PRODUCTS.get("list", "json"),
    settings: await env.PRODUCTS.get("settings", "json"),
    orders: await env.PRODUCTS.get("orders", "json"),
    accounts: await env.PRODUCTS.get("accidx", "json"),
  };
  const form = new FormData();
  form.append("chat_id", String(env.CHAT_ID));
  form.append("caption", "💾 Zaxira nusxa: tovarlar, sozlamalar, buyurtmalar, akkauntlar. Xavfsiz joyda saqlang, ichida mijozlar telefon raqamlari bor.");
  form.append("document", new Blob([JSON.stringify(data)], { type: "application/json" }), "sarbon-zaxira-" + now.slice(0, 10) + ".json");
  return fetch("https://api.telegram.org/bot" + env.BOT_TOKEN + "/sendDocument", { method: "POST", body: form }).then((r) => r.json()).catch(() => ({ ok: false }));
}

// ---------- MIJOZ BOTI ----------
const ctg = (env, method, body) =>
  fetch("https://api.telegram.org/bot" + (env.SHOP_BOT_TOKEN || env.CUSTOMER_BOT_TOKEN) + "/" + method, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then((r) => r.json());
const csay = (env, chatId, text, extra) => ctg(env, "sendMessage", Object.assign({ chat_id: chatId, text: text }, extra || {}));
const randomId = (n) => {
  const a = "abcdefghijklmnopqrstuvwxyz0123456789", b = new Uint8Array(n);
  let r = "";
  crypto.getRandomValues(b);
  for (let i = 0; i < n; i++) r += a[b[i] % a.length];
  return r;
};
async function handleCustomerWebhook(request, env) {
  if (request.headers.get("X-Telegram-Bot-Api-Secret-Token") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
  const u = await request.json(), msg = u.message;
  if (!msg || !msg.from) return new Response("ok");
  const chatId = msg.chat.id;
  if (msg.contact) {
    if (msg.contact.user_id !== msg.from.id) { await csay(env, chatId, "Iltimos, faqat o'zingizning raqamingizni yuboring."); return new Response("ok"); }
    const resetWait = await env.PRODUCTS.get("pwresetwait:" + msg.from.id, "json");
    if (resetWait && resetWait.expires > Date.now()) {
      const submitted = normPhone("+" + String(msg.contact.phone_number).replace(/\D/g, ""));
      await env.PRODUCTS.delete("pwresetwait:" + msg.from.id);
      if (!submitted || submitted !== resetWait.phone) {
        await csay(env, chatId, "❌ Telegram raqamingiz profil raqamiga mos kelmadi. Saytdagi telefon raqamni tekshiring.", { reply_markup: { remove_keyboard: true } });
        return new Response("ok");
      }
      const account = await pwAccount(env, resetWait.phone);
      if (!account || !(account.keys || []).some((k) => k === "t" + msg.from.id)) {
        await csay(env, chatId, "❌ Akkaunt tekshiruvidan o'tmadi. Saytdan qayta urinib ko'ring.", { reply_markup: { remove_keyboard: true } });
        return new Response("ok");
      }
      // 00000–99999 oralig'ida modulo bias'siz kriptografik random kod.
      let n; const limit = Math.floor(0x100000000 / 100000) * 100000;
      do { n = crypto.getRandomValues(new Uint32Array(1))[0]; } while (n >= limit);
      const code = String(n % 100000).padStart(5, "0");
      const sent = await csay(env, msg.from.id, "🔐 Sarbon parolni tiklash kodi: " + code + "\nKod 10 daqiqa amal qiladi. Uni hech kimga bermang.", { reply_markup: { remove_keyboard: true } });
      if (sent && sent.ok) await env.PRODUCTS.put("pwreset:" + resetWait.phone, JSON.stringify({ hash: await pwCodeHash(resetWait.phone, code, env), expires: Date.now() + 600000, sentAt: Date.now(), attempts: 0 }), { expirationTtl: 600 });
      return new Response("ok");
    }
    const waitId = await env.PRODUCTS.get("tgwait:" + msg.from.id);
    if (!waitId) { await csay(env, chatId, "Sessiya tugagan. Saytga qaytib, 'Telegram orqali kirish' ni qayta bosing."); return new Response("ok"); }
    const token = randomId(40);
    const name = clean(((msg.from.first_name || "") + " " + (msg.from.last_name || "")).trim(), 60) || "Mijoz";
    let phone = "+" + String(msg.contact.phone_number).replace(/\D/g, "");
    const tgKey = "t" + msg.from.id, tgGroup = await groupOf(env, tgKey), tgKeys = tgGroup ? memberKeys(tgGroup.m) : [tgKey];
    if (await phoneTakenByOther(env, phone, tgKeys, tgKeys[0])) { await csay(env, chatId, "Bu telefon raqami boshqa Sarbon akkauntiga biriktirilgan. O'sha akkauntga kiring va Profil → Kirish usullari orqali Telegramni ulang."); return new Response("ok"); }
    const tp = await env.PRODUCTS.get("tgp:" + msg.from.id, "json");
    const sdata = { tgId: msg.from.id, name: name, phone: phone };
    if (tp) { sdata.name = tp.name || name; sdata.f = tp.f; sdata.l = tp.l; sdata.phone = tp.phone || phone; }
    await upsertAcc(env, { k: "t" + msg.from.id, p: "t", id: msg.from.id, name: sdata.name, un: msg.from.username || "", phone: sdata.phone });
    await env.PRODUCTS.put("sess:" + token, JSON.stringify(sdata), { expirationTtl: 60 * 60 * 24 * 30 });
    await env.PRODUCTS.put("login:" + waitId, JSON.stringify({ token: token, name: sdata.name }), { expirationTtl: 300 });
    await env.PRODUCTS.delete("tgwait:" + msg.from.id);
    // Tezkor kirish: token tugma havolasida saytga to'g'ridan-to'g'ri uzatiladi (KV kechikishini kutmaydi)
    // Havolaga haqiqiy token emas, 5 daqiqalik bir martalik kod qo'yiladi (/login-exchange almashtiradi)
    const lc = randomId(24);
    await env.PRODUCTS.put("lc:" + lc, JSON.stringify({ token: token, name: sdata.name }), { expirationTtl: 300 });
    const back = (env.ALLOWED_ORIGIN || "https://sarbonuz.github.io") + "/sarbon/?lt=" + lc;
    await csay(env, chatId, "✅ Tasdiqlandi, " + name + ". Saytga qaytish uchun tugmani bosing.", {
      reply_markup: { inline_keyboard: [[{ text: "🛍 Saytga qaytish", url: back }]] },
    });
    await csay(env, chatId, "Menyu: pastdagi «🪪 Verifikatsiya» tugmasi orqali akkauntingizni tasdiqlashingiz mumkin.", { reply_markup: { keyboard: [[{ text: "🪪 Verifikatsiya" }]], resize_keyboard: true, is_persistent: true } });
    return new Response("ok");
  }
  if (msg.text && /^ha$/i.test(msg.text.trim())) {
    const pid = await env.PRODUCTS.get("lkp:" + msg.from.id);
    if (pid) {
      const rec = await env.PRODUCTS.get("lkt:" + pid, "json");
      await env.PRODUCTS.delete("lkp:" + msg.from.id);
      if (!rec || !(rec.k || rec.gid)) { await csay(env, chatId, "Havola eskirgan. Do'kondan qaytadan urinib ko'ring."); return new Response("ok"); }
      await env.PRODUCTS.delete("lkt:" + pid);
      const lr = await linkIdents(env, "t" + msg.from.id, rec.k || identKeyFromSub(String(rec.gid)));
      await csay(env, chatId, (lr.ok ? "✅ " : "⚠️ ") + lr.msg);
      return new Response("ok");
    }
  }
  if (msg.text && (await vCustomerCmd(env, msg))) return new Response("ok");
  if (msg.text && msg.text.startsWith("/start")) {
    const param = msg.text.split(" ")[1] || "";
    if (param.startsWith("s_")) {
      await env.PRODUCTS.put("tgwait:" + msg.from.id, param.slice(2), { expirationTtl: 600 });
      await csay(env, chatId, "Kirish uchun telefon raqamingizni yuboring. Pastdagi tugmani bosing:", {
        reply_markup: { keyboard: [[{ text: "📱 Telefon raqamimni yuborish", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true },
      });
    } else if (/^l_[a-f0-9]{24}$/.test(param)) {
      const rec = await env.PRODUCTS.get("lkt:" + param.slice(2), "json");
      if (!rec || !(rec.k || rec.gid)) await csay(env, chatId, "Havola eskirgan. Do'kondan qaytadan urinib ko'ring.");
      else {
        const rk = rec.k || identKeyFromSub(String(rec.gid)), gsub = rk[0] === "y" ? rk : rk.slice(1);
        const ga = (await env.PRODUCTS.get("g:" + gsub, "json")) || {};
        await env.PRODUCTS.put("lkp:" + msg.from.id, param.slice(2), { expirationTtl: 300 });
        await csay(env, chatId, "Google akkaunt: " + clean(ga.name || "", 60) + " " + clean(ga.email || "", 120) + "\nShu akkaunt ushbu Telegram akkauntga ulanadi. Tasdiqlash uchun HA deb yozing. O'zingiz boshlamagan bo'lsangiz, e'tibor bermang.");
      }
    } else if (/^p\d{1,7}$/.test(param)) {
      await sendProductCard(env, chatId, Number(param.slice(1)), new URL(request.url).origin);
    } else await csay(env, chatId, "Salom! 👋 Sarbon do'koniga xush kelibsiz.\nXarid qilish uchun pastdagi tugmani bosing.", { reply_markup: { inline_keyboard: [[{ text: "🛍 Do'konni ochish", web_app: { url: vSite(env) } }]] } });
  }
  return new Response("ok");
}
async function notifyCustomer(env, order, text) {
  const powner = order.tg ? "t" + order.tg : order.g ? "g" + order.g : "";
  if (powner) { try { await pushTo(env, powner, { t: "order", oid: String(order.id), title: "Sarbon", text: String(text).replace(/^📦\s*/, "").slice(0, 300), ts: Date.now() }); } catch (e) { /* push ixtiyoriy */ } }
  if (!order.tg) return;
  try { await csay(env, order.tg, text); } catch (e) { /* mijoz botni bloklagan bo'lishi mumkin */ }
}

// ---------- TREK KOD va ADMIN BILAN CHAT ----------
async function setTrack(env, oid, text) {
  const code = clean(text, 60).trim();
  if (code.length < 3) return say(env, "Trek kod juda qisqa. Tugmani qayta bosing.", MENU);
  const orders = await getOrders(env), o = orders.find((x) => String(x.id) === String(oid));
  if (!o) return say(env, "Buyurtma topilmadi.", MENU);
  o.trk = code; o.trkAt = Date.now();
  await saveOrders(env, orders);
  await notifyCustomer(env, o, "📦 Buyurtma #" + o.id + " trek kodi: " + code);
  return say(env, "✅ #" + o.id + " ga trek kod yozildi: " + code + "\nMijoz 'Buyurtmalarim' bo'limida ko'radi.", { inline_keyboard: [[btn("💬 Mijozga yozish", "ch:" + o.id), btn("⬅️ Menyu", "menu")]] });
}
// Bir akkaunt guruhidagi barcha kirish kalitlari (Telegram / Google / Yandex). Ma'lumot qaysi biri ostida saqlangan bo'lsa ham topiladi.
const ownersOf = (s) => {
  const a = [];
  if (s.tgId) a.push("t" + s.tgId);
  (s.gids || []).forEach((x) => { if (a.indexOf("g" + x) < 0) a.push("g" + x); });
  if (s.gid && a.indexOf("g" + s.gid) < 0) a.push("g" + s.gid);
  return a;
};
// Yangi yozuvlar uchun doim bir xil (qaysi usul bilan kirmasin) kalit
const ownerOf = (s) => ownersOf(s)[0] || "";
const OWS = (o) => (Array.isArray(o) ? o : [o]);
const SQLIN = (o) => OWS(o).map(() => "?").join(",");
const getChat = (env, key) => env.PRODUCTS.get("chat:" + key, { type: "json", cacheTtl: 30 });
const putChat = (env, key, c) => env.PRODUCTS.put("chat:" + key, JSON.stringify(c));
const chatTitle = (c) => (c.oid ? "Buyurtma #" + c.oid : "Umumiy savol") + " — " + (c.name || "Mijoz") + (c.phone ? " " + c.phone : "");
async function threadFor(env, sess, oid) {
  if (!sess) return null;
  const owner = ownerOf(sess);
  if (!owner) return null;
  if (oid && oid !== "gen") {
    let o = (await getOrdersMemo(env)).find((x) => String(x.id) === String(oid));
    if (!o) o = (await getOrders(env)).find((x) => String(x.id) === String(oid));
    if (!o) o = await env.PRODUCTS.get("ob:" + String(oid).replace(/[^A-Za-z0-9]/g, "").slice(0, 30), "json");
    if (!o || !((sess.tgId && o.tg === sess.tgId) || ownsG(sess, o))) return null;
    return { key: String(o.id), oid: String(o.id), owner: owner, order: o };
  }
  return { key: "gen-" + owner, oid: "", owner: owner, order: null };
}
async function ensureChat(env, key) {
  const c = await getChat(env, key);
  if (c) return c;
  const o = (await getOrders(env)).find((x) => String(x.id) === String(key));
  if (!o) return null;
  return { name: o.name, phone: o.phone, tg: o.tg || null, owner: o.tg ? "t" + o.tg : o.g ? "g" + o.g : "", oid: String(o.id), m: [] };
}
async function adminReply(env, key, text) {
  const c = await ensureChat(env, key);
  if (!c) return say(env, "Chat topilmadi.", MENU);
  const t = clean(text, 1000).trim();
  if (!t) return null;
  const now = Date.now();
  c.m = (c.m || []).concat([{ f: "a", t: t, ts: now }]).slice(-100);
  await putChat(env, key, c);
  if (c.owner) {
    const cu = (await env.PRODUCTS.get("cu:" + c.owner, "json")) || {};
    cu[key] = now;
    await env.PRODUCTS.put("cu:" + c.owner, JSON.stringify(cu));
    // darhol push: matn bevosita xabarning ichida, KV kechikishini kutmaydi
    try { await pushTo(env, c.owner, { t: "chat", oid: c.oid || "gen", title: c.oid ? "Admin (#" + c.oid + ")" : "Admin", text: t.slice(0, 500), ts: now }); } catch (e) { /* push ishlamasa ham chat saqlangan */ }
  }
  if (c.tg) { try { await csay(env, c.tg, "💬 Admin" + (c.oid ? " (#" + c.oid + ")" : "") + ":\n" + t); } catch (e) { /* bot bloklangan */ } }
  return say(env, "✅ Yuborildi" + (c.oid ? " (#" + c.oid + ")" : ""), { inline_keyboard: [[btn("🚪 Chatdan chiqish", "chx")]] });
}
async function handleChatSend(env, body, origin) {
  const token = String(body.token || "").replace(/[^a-z0-9]/g, "");
  const sess = await getSession(env, token);
  const th = await threadFor(env, sess, String(body.oid || "gen"));
  if (!th) return json({ ok: false, error: "auth" }, 401, origin);
  const text = clean(body.text, 1000).trim();
  if (!text) return json({ ok: false, error: "empty" }, 400, origin);
  const c = (await getChat(env, th.key)) || { name: sess.name || (th.order && th.order.name) || "Mijoz", phone: sess.phone || (th.order && th.order.phone) || "", tg: sess.tgId || null, owner: th.owner, oid: th.oid, m: [] };
  const now = Date.now(), lastC = c.m.slice().reverse().find((x) => x.f === "c");
  if (lastC && now - lastC.ts < 1200) return json({ ok: false, error: "slow" }, 429, origin);
  c.name = sess.name || c.name; c.phone = sess.phone || c.phone; c.owner = c.owner || th.owner;
  if (sess.tgId) c.tg = sess.tgId;
  c.m = c.m.concat([{ f: "c", t: text, ts: now }]).slice(-100);
  await putChat(env, th.key, c);
  const r = await say(env, "💬 " + chatTitle(c) + "\n\n" + text, { inline_keyboard: [[btn("↩️ Javob berish", "ch:" + th.key)].concat(c.oid ? [btn("📦 Trek kod", "tk:" + c.oid)] : [])] });
  if (r && r.ok && r.result) await env.PRODUCTS.put("cm:" + r.result.message_id, th.key, { expirationTtl: 60 * 60 * 24 * 30 });
  return json({ ok: true, ts: now }, 200, origin);
}
// Profil (ism, familya, telefon) akkauntga bog'langan: boshqa qurilma/ilovada yangilangan ism darhol hamma sessiyada ko'rinadi
// ---------- AKKAUNT USULLARI (Telegram / Google / Yandex bitta akkauntga ulanadi) ----------
// Kalit: t<id> | g<sub> | y<id>. Guruh: grp:<id> = {m:{t,g,y}}, acct:<kalit> = guruh id
const identKeyFromSub = (sub) => (String(sub)[0] === "y" ? String(sub) : "g" + sub);
const slotOf = (k) => ({ kind: k[0], val: k.slice(1) });
const memberKeys = (m) => ["t", "g", "y"].filter((x) => m[x]).map((x) => x + m[x]);
const ownsG = (sess, o) => !!(sess.gids && o && o.g && sess.gids.indexOf(String(o.g)) >= 0);
async function groupOf(env, key) {
  const gid = await env.PRODUCTS.get("acct:" + key);
  if (gid) { const g = await env.PRODUCTS.get("grp:" + gid, "json"); if (g && g.m) return { id: gid, m: g.m }; }
  // eski (bir juftlik) ulanishlar
  let t = null, sub = null;
  if (key[0] === "t") { t = key.slice(1); const s = await env.PRODUCTS.get("lk:t:" + t); if (s) sub = s; }
  else { sub = key[0] === "y" ? key : key.slice(1); const tv = await env.PRODUCTS.get("lk:g:" + sub); if (tv) t = tv; }
  if (t && sub) { const m = { t: String(t) }; if (String(sub)[0] === "y") m.y = String(sub).slice(1); else m.g = String(sub); return { id: null, m: m }; }
  return null;
}
async function purgeLegacy(env, key) {
  try {
    if (key[0] === "t") { const s = await env.PRODUCTS.get("lk:t:" + key.slice(1)); await env.PRODUCTS.delete("lk:t:" + key.slice(1)); if (s) await env.PRODUCTS.delete("lk:g:" + s); }
    else { const sub = key[0] === "y" ? key : key.slice(1); const t = await env.PRODUCTS.get("lk:g:" + sub); await env.PRODUCTS.delete("lk:g:" + sub); if (t) await env.PRODUCTS.delete("lk:t:" + t); }
  } catch (e) { /* eski kalit bo'lmasa ham davom etadi */ }
}
async function linkIdents(env, a, b) {
  const ga = await groupOf(env, a), gb = await groupOf(env, b);
  if (ga && gb) {
    if (JSON.stringify(memberKeys(ga.m).sort()) === JSON.stringify(memberKeys(gb.m).sort())) return { ok: true, msg: "Bu usullar allaqachon ulangan." };
    return { ok: false, msg: "Bu akkaunt boshqa akkauntga allaqachon ulangan. Avval u yerda uzing." };
  }
  const base = ga || gb || { id: null, m: {} };
  const m = Object.assign({}, base.m);
  for (const s of [slotOf(a), slotOf(b)]) {
    if (m[s.kind] && String(m[s.kind]) !== s.val) return { ok: false, msg: "Bu turdagi akkaunt allaqachon ulangan. Avval uni uzing." };
    m[s.kind] = s.val;
  }
  const id = base.id || hexId(12);
  await env.PRODUCTS.put("grp:" + id, JSON.stringify({ m: m }));
  for (const k of memberKeys(m)) await env.PRODUCTS.put("acct:" + k, id);
  return { ok: true, msg: "Ulandi. Endi qaysi usul bilan kirsangiz ham bir xil akkaunt ochiladi. Do'konga qayting." };
}
async function unlinkMethod(env, sess, kind) {
  const grp = sess.ck ? await groupOf(env, sess.ck) : null;
  if (!grp) return { ok: false, error: "last" };
  const m = Object.assign({}, grp.m);
  if (memberKeys(m).length < 2) return { ok: false, error: "last" };
  if (!m[kind]) return { ok: false, error: "none" };
  const removedKey = kind + m[kind];
  delete m[kind];
  await env.PRODUCTS.delete("acct:" + removedKey);
  await purgeLegacy(env, removedKey);
  const left = memberKeys(m);
  if (left.length < 2) {
    for (const k of left) { await env.PRODUCTS.delete("acct:" + k); await purgeLegacy(env, k); }
    if (grp.id) await env.PRODUCTS.delete("grp:" + grp.id);
  } else {
    await env.PRODUCTS.put("grp:" + grp.id, JSON.stringify({ m: m }));
  }
  return { ok: true, self: removedKey === sess.ck };
}
async function handleUnlink(env, body, origin) {
  const token = String(body.token || "").replace(/[^a-z0-9]/g, "");
  const sess = await getSession(env, token);
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const kind = body.kind === "t" ? "t" : body.kind === "y" ? "y" : body.kind === "g" ? "g" : "";
  if (!kind) return json({ ok: false, error: "kind" }, 400, origin);
  const r = await unlinkMethod(env, sess, kind);
  if (!r.ok) return json(r, 200, origin);
  if (r.self) await env.PRODUCTS.delete("sess:" + token);
  return json({ ok: true, loggedOut: !!r.self }, 200, origin);
}
// Sessiyani saqlashda hisoblangan maydonlar tushirib qoldiriladi
const rawSession = (s) => {
  const r = Object.assign({}, s), o = s.o || {};
  delete r.o; delete r.m; delete r.gids; delete r.ck; delete r.cur;
  if (o.t === undefined) delete r.tgId; else r.tgId = o.t;
  if (o.g === undefined) delete r.gid; else r.gid = o.g;
  return r;
};
async function getSession(env, token) {
  if (!token) return null;
  const s = await env.PRODUCTS.get("sess:" + token, "json");
  if (!s) return null;
  s.o = { t: s.tgId, g: s.gid };
  s.cur = s.tgId ? "t" : s.gid ? (String(s.gid)[0] === "y" ? "y" : "g") : "";
  s.ck = s.tgId ? "t" + s.tgId : s.gid ? identKeyFromSub(String(s.gid)) : "";
  s.m = { t: !!s.tgId, g: s.cur === "g", y: s.cur === "y" };
  s.gids = s.gid ? [String(s.gid)] : [];
  try {
    const grp = s.ck ? await groupOf(env, s.ck) : null;
    if (grp) {
      const m = grp.m, subs = [];
      s.m = { t: !!m.t, g: !!m.g, y: !!m.y };
      if (m.t) s.tgId = Number(m.t);
      if (m.g) subs.push(String(m.g));
      if (m.y) subs.push("y" + m.y);
      s.gids = subs;
      if (!s.gid && subs.length) s.gid = subs[0];
    }
  } catch (e) { /* ulanish o'qilmasa oddiy sessiya */ }
  try {
    const acc = s.cur === "t" ? await env.PRODUCTS.get("tgp:" + s.o.t, "json") : s.o.g ? await env.PRODUCTS.get("g:" + s.o.g, "json") : null;
    if (acc && acc.name) { s.name = acc.name; s.f = acc.f; s.l = acc.l; if (acc.phone) s.phone = acc.phone; }
  } catch (e) { /* akkaunt o'qilmasa sessiyadagi ma'lumot qoladi */ }
  return s;
}


// ---------- GOOGLE BILAN KIRISH ----------
const GOOGLE_CLIENT_ID = "241259146600-hjd3c7cq0m4op3rtg0emh9tpv8cn19l9.apps.googleusercontent.com";
const normPhone = (v) => {
  let d = String(v || "").replace(/\D/g, "");
  if (d.length === 9) d = "998" + d;
  return d.length >= 11 && d.length <= 15 ? "+" + d : "";
};

// ---------- TELEFON + PAROL AKKAUNTI ----------
// Telefon raqami login identifikatori; SMS yuborilmaydi. Parol PBKDF2 bilan xeshlanadi.
const pwHex = (u) => Array.from(new Uint8Array(u)).map((b) => b.toString(16).padStart(2, "0")).join("");
const pwUnhex = (s) => Uint8Array.from(String(s || "").match(/.{2}/g) || [], (x) => parseInt(x, 16));
async function pwDigest(password, salt) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(String(password)), "PBKDF2", false, ["deriveBits"]);
  return pwHex(await crypto.subtle.deriveBits({ name: "PBKDF2", salt: salt, iterations: 120000, hash: "SHA-256" }, key, 256));
}
async function pwCodeHash(phone, code, env) {
  const b = new TextEncoder().encode(String(env.WEBHOOK_SECRET || "") + ":" + phone + ":" + code);
  return pwHex(await crypto.subtle.digest("SHA-256", b));
}
const pwSame = (a, b) => {
  a = String(a || ""); b = String(b || "");
  if (a.length !== b.length) return false;
  let d = 0; for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
};
const pwValid = (v) => typeof v === "string" && v.length >= 8 && v.length <= 128;
const pwOwnerMatches = (rec, sess) => (rec && Array.isArray(rec.keys) && ownersOf(sess).some((k) => rec.keys.includes(k)));
async function pwAccount(env, phone) {
  const owner = await env.PRODUCTS.get("phoneidx:" + phone);
  if (!owner) return null;
  const rec = await env.PRODUCTS.get("pwacct:" + phone, "json");
  return rec && rec.owner === owner ? rec : null;
}
async function phoneTakenByOther(env, phone, keys, owner) {
  const idx = await env.PRODUCTS.get("phoneidx:" + phone);
  if (idx && idx !== owner && !(keys || []).includes(idx)) return true;
  const own = new Set(keys || []);
  return (await getAcc(env)).some((a) => normPhone(a.phone) === phone && !own.has(a.k));
}
async function pwSetForSession(env, sess, currentPassword, newPassword) {
  const phone = normPhone(sess.phone), owner = ownerOf(sess), keys = ownersOf(sess);
  if (!phone || !owner || !keys.length) return { ok: false, error: "phone_or_identity" };
  if (!pwValid(newPassword)) return { ok: false, error: "weak" };
  if (await phoneTakenByOther(env, phone, keys, owner)) return { ok: false, error: "taken" };
  let rec = await pwAccount(env, phone);
  if (rec && !pwOwnerMatches(rec, sess)) return { ok: false, error: "taken" };
  if (rec) {
    if (!currentPassword || !pwSame(await pwDigest(currentPassword, pwUnhex(rec.salt)), rec.hash)) return { ok: false, error: "current" };
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  rec = { owner: owner, keys: keys, name: sess.name || "Mijoz", phone: phone, salt: pwHex(salt), hash: await pwDigest(newPassword, salt), updated: Date.now(), created: rec && rec.created || Date.now() };
  await env.PRODUCTS.put("pwacct:" + phone, JSON.stringify(rec));
  await env.PRODUCTS.put("phoneidx:" + phone, owner);
  return { ok: true };
}
async function handlePasswordLogin(env, body, origin) {
  const phone = normPhone(body.phone), password = String(body.password || "");
  if (!phone || password.length > 128) return json({ ok: false, error: "credentials" }, 400, origin);
  const rec = await pwAccount(env, phone);
  if (!rec || !pwValid(password) || !pwSame(await pwDigest(password, pwUnhex(rec.salt)), rec.hash)) return json({ ok: false, error: "credentials" }, 401, origin);
  const keys = Array.isArray(rec.keys) ? rec.keys : [];
  const tk = keys.find((k) => k[0] === "t"), gk = keys.find((k) => k[0] === "g" || k[0] === "y");
  if (!tk && !gk) return json({ ok: false, error: "relink" }, 403, origin);
  const data = { tgId: tk ? tk.slice(1) : undefined, gid: gk ? (gk[0] === "y" ? gk : gk.slice(1)) : undefined, phone: phone, name: rec.name || "Mijoz" };
  const token = await makeSession(env, data);
  rec.lastLogin = Date.now();
  await env.PRODUCTS.put("pwacct:" + phone, JSON.stringify(rec));
  return json({ ok: true, token: token, name: data.name }, 200, origin);
}
async function handlePasswordStatus(env, body, origin) {
  const token = String(body.token || "").replace(/[^a-z0-9]/g, ""), sess = await getSession(env, token);
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const phone = normPhone(sess.phone), rec = phone ? await pwAccount(env, phone) : null;
  return json({ ok: true, hasPassword: !!(rec && pwOwnerMatches(rec, sess)), phone: phone || "" }, 200, origin);
}
async function handlePasswordSet(env, body, origin) {
  const token = String(body.token || "").replace(/[^a-z0-9]/g, ""), sess = await getSession(env, token);
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const a = String(body.newPassword || ""), b = String(body.confirmPassword || "");
  if (a !== b) return json({ ok: false, error: "mismatch" }, 400, origin);
  const r = await pwSetForSession(env, sess, String(body.currentPassword || ""), a);
  return json(r, r.ok ? 200 : (r.error === "taken" ? 409 : 400), origin);
}
async function telegramForPwAccount(env, rec) {
  for (const k of (rec.keys || [])) {
    if (k[0] === "t" && /^t\d+$/.test(k)) return k.slice(1);
    try { const g = await groupOf(env, k); if (g && g.m && g.m.t) return String(g.m.t); } catch (e) {}
  }
  return "";
}
async function handlePasswordResetRequest(env, body, origin) {
  const phone = normPhone(body.phone);
  // Javob akkaunt mavjudligini oshkor qilmaydi.
  const generic = { ok: true, message: "Agar akkaunt mavjud bo'lsa, Telegram orqali telefon tasdiqlash so'rovi yuboriladi." };
  if (!phone) return json(generic, 200, origin);
  const rec = await pwAccount(env, phone);
  if (!rec) return json(generic, 200, origin);
  const tgId = await telegramForPwAccount(env, rec);
  if (!tgId) return json(generic, 200, origin);
  const lock = await env.PRODUCTS.get("pwresetwait:" + tgId, "json");
  const prior = await env.PRODUCTS.get("pwreset:" + phone, "json");
  if ((lock && lock.expires > Date.now()) || (prior && Date.now() - (prior.sentAt || 0) < 60000)) return json(generic, 200, origin);
  await env.PRODUCTS.put("pwresetwait:" + tgId, JSON.stringify({ phone, expires: Date.now() + 300000 }), { expirationTtl: 300 });
  const sent = await csay(env, tgId, "🔐 Parolni tiklash uchun telefon raqamingizni tasdiqlang. Pastdagi tugma orqali aynan o'zingizning Telegram raqamingizni yuboring.", {
    reply_markup: { keyboard: [[{ text: "📱 Telefon raqamimni tasdiqlash", request_contact: true }]], resize_keyboard: true, one_time_keyboard: true }
  });
  if (!sent || !sent.ok) await env.PRODUCTS.delete("pwresetwait:" + tgId);
  return json(generic, 200, origin);
}
async function handlePasswordResetConfirm(env, body, origin) {
  const phone = normPhone(body.phone), code = String(body.code || "").replace(/\D/g, ""), a = String(body.newPassword || ""), b = String(body.confirmPassword || "");
  if (!phone || !/^\d{5}$/.test(code)) return json({ ok: false, error: "code" }, 400, origin);
  if (a !== b) return json({ ok: false, error: "mismatch" }, 400, origin);
  if (!pwValid(a)) return json({ ok: false, error: "weak" }, 400, origin);
  const rec = await pwAccount(env, phone), reset = await env.PRODUCTS.get("pwreset:" + phone, "json");
  if (!rec || !reset || reset.expires < Date.now() || reset.attempts >= 5) return json({ ok: false, error: "expired" }, 400, origin);
  if (!pwSame(await pwCodeHash(phone, code, env), reset.hash)) {
    reset.attempts = (reset.attempts || 0) + 1;
    await env.PRODUCTS.put("pwreset:" + phone, JSON.stringify(reset), { expirationTtl: Math.max(1, Math.ceil((reset.expires - Date.now()) / 1000)) });
    return json({ ok: false, error: "code" }, 400, origin);
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  rec.salt = pwHex(salt); rec.hash = await pwDigest(a, salt); rec.updated = Date.now();
  await env.PRODUCTS.put("pwacct:" + phone, JSON.stringify(rec));
  await env.PRODUCTS.delete("pwreset:" + phone);
  return json({ ok: true }, 200, origin);
}
async function makeSession(env, data) {
  const token = randomId(40);
  await env.PRODUCTS.put("sess:" + token, JSON.stringify(data), { expirationTtl: 60 * 60 * 24 * 30 });
  return token;
}
// Google id_token ni tekshiradi (GSI tugmasi ham, tashqi brauzer oqimi ham shuni ishlatadi)
async function googleTokenInfo(env, cred) {
  const r = await fetch("https://oauth2.googleapis.com/tokeninfo?id_token=" + encodeURIComponent(cred));
  if (!r.ok) return null;
  const t = await r.json();
  const issOk = t.iss === "accounts.google.com" || t.iss === "https://accounts.google.com";
  if (t.aud !== GOOGLE_CLIENT_ID || !issOk || !t.sub || Number(t.exp) * 1000 < Date.now() || String(t.email_verified) !== "true") return null;
  return t;
}
// Tekshirilgan Google akkaunt uchun: {token,name} yoki telefon kerak bo'lsa {needPhone,ptoken,name}
async function googleAccount(env, t) {
  const email = clean(t.email, 120);
  const name = clean(t.name || email.split("@")[0] || "Mijoz", 60);
  let acc = await env.PRODUCTS.get("g:" + t.sub, "json");
  if (!acc || !acc.phone) {
    // Telegramga ulangan bo'lsa, raqam qayta so'ralmaydi
    const lgrp = await groupOf(env, identKeyFromSub(String(t.sub)));
    const ltg = lgrp && lgrp.m.t;
    if (ltg) {
      const tp = await env.PRODUCTS.get("tgp:" + ltg, "json");
      if (tp && tp.phone) { acc = { name: tp.name || name, email: email, phone: tp.phone, f: tp.f, l: tp.l }; await env.PRODUCTS.put("g:" + t.sub, JSON.stringify(acc)); }
    }
  }
  if (acc && acc.phone) {
    await upsertAcc(env, { k: "g" + t.sub, p: "g", id: t.sub, name: acc.name || name, email: email, phone: acc.phone });
    const token = await makeSession(env, { gid: t.sub, name: acc.name || name, f: acc.f, l: acc.l, phone: acc.phone, email: email });
    return { token: token, name: acc.name || name };
  }
  const ptoken = randomId(32);
  await env.PRODUCTS.put("gpend:" + ptoken, JSON.stringify({ sub: t.sub, name: name, email: email }), { expirationTtl: 600 });
  return { needPhone: true, ptoken: ptoken, name: name };
}
async function handleGoogleLogin(env, body, origin) {
  const cred = typeof body.credential === "string" ? body.credential : "";
  if (cred.length < 100 || cred.length > 4000) return json({ ok: false, error: "credential" }, 400, origin);
  const t = await googleTokenInfo(env, cred);
  if (!t) return json({ ok: false, error: "invalid" }, 401, origin);
  return json(Object.assign({ ok: true }, await googleAccount(env, t)), 200, origin);
}
// Telegram mini-ilovada Google oynasi ishlamaydi: kirish tashqi brauzerda bo'ladi, natija login:<id> orqali ilovaga qaytadi
const gEsc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const gPage = (ok, text) => new Response(
  '<!doctype html><html lang="uz"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sarbon</title>' +
  '<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;font:17px/1.5 system-ui,sans-serif;background:#f4f5fb;color:#1B1D45;text-align:center;padding:24px}@media(prefers-color-scheme:dark){body{background:#0B0D22;color:#eef0ff}}h1{font-size:46px;margin:0 0 8px}p{margin:6px 0}</style></head><body><div>' +
  '<h1>' + (ok ? "✅" : "⚠️") + '</h1><p><b>' + (ok ? "Kirish tayyor" : "Kirish bo'lmadi") + '</b></p><p>' + gEsc(text) + '</p></div></body></html>',
  { status: ok ? 200 : 400, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } }
);
async function handleGoogleStart(env, url) {
  const id = String(url.searchParams.get("id") || "");
  if (!/^[a-f0-9]{24}$/.test(id)) return gPage(false, "Havola noto'g'ri. Do'konga qaytib, qaytadan urinib ko'ring.");
  const nonce = randomId(24);
  await env.PRODUCTS.put("gn:" + id, nonce, { expirationTtl: 600 });
  const q = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID, redirect_uri: url.origin + "/google-cb", response_type: "id_token", response_mode: "form_post",
    scope: "openid email profile", state: id, nonce: nonce, prompt: "select_account",
  });
  return new Response(null, { status: 302, headers: { Location: "https://accounts.google.com/o/oauth2/v2/auth?" + q.toString(), "Cache-Control": "no-store" } });
}
const hexId = (n) => { const b = new Uint8Array(n); crypto.getRandomValues(b); return Array.from(b).map((x) => x.toString(16).padStart(2, "0")).join(""); };
// Telegram (tasdiqlangan id) + Google (tasdiqlangan sub) ni bir-biriga ulaydi
async function linkPair(env, tgId, sub) { return linkIdents(env, "t" + tgId, identKeyFromSub(String(sub))); }
async function handleLinkStart(env, body, origin) {
  const sess = await getSession(env, String(body.token || "").replace(/[^a-z0-9]/g, ""));
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const kind = body.kind === "t" ? "t" : body.kind === "y" ? "y" : body.kind === "g" ? "g" : "";
  if (!kind || !sess.ck) return json({ ok: false, error: "kind" }, 400, origin);
  if (sess.m && sess.m[kind]) return json({ ok: false, error: "already" }, 200, origin);
  const id = hexId(12);
  await env.PRODUCTS.put((kind === "t" ? "lkt:" : "lkg:") + id, JSON.stringify({ k: sess.ck }), { expirationTtl: 600 });
  return json({ ok: true, id: id }, 200, origin);
}
const YANDEX_ID = "125bf46ec63d44e0abd4e2392709932d", YANDEX_SECRET = "6511fc1e835b41f583da67e116dab4ad";
async function handleYandexStart(env, url) {
  const id = String(url.searchParams.get("id") || "");
  if (!/^[a-f0-9]{24}$/.test(id)) return gPage(false, "Havola noto'g'ri. Do'konga qaytib, qaytadan urinib ko'ring.");
  if (!(env.YANDEX_CLIENT_ID || YANDEX_ID) || !(env.YANDEX_CLIENT_SECRET || YANDEX_SECRET)) return gPage(false, "Yandex ID hali sozlanmagan.");
  await env.PRODUCTS.put("yn:" + id, "1", { expirationTtl: 600 });
  const q = new URLSearchParams({ response_type: "code", client_id: (env.YANDEX_CLIENT_ID || YANDEX_ID), redirect_uri: url.origin + "/yandex-cb", state: id });
  return new Response(null, { status: 302, headers: { Location: "https://oauth.yandex.com/authorize?" + q.toString(), "Cache-Control": "no-store" } });
}
async function handleYandexCb(env, url) {
  const state = String(url.searchParams.get("state") || ""), code = String(url.searchParams.get("code") || "");
  if (!/^[a-f0-9]{24}$/.test(state)) return gPage(false, "Havola noto'g'ri.");
  if (!code) return gPage(false, "Yandex kirishni rad etdi yoki bekor qilindi. Do'konga qaytib, qayta urinib ko'ring.");
  if (!(await env.PRODUCTS.get("yn:" + state))) return gPage(false, "Vaqt tugagan. Do'konga qaytib, qaytadan urinib ko'ring.");
  await env.PRODUCTS.delete("yn:" + state);
  let info = null;
  try {
    const tr = await fetch("https://oauth.yandex.com/token", {
      method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ grant_type: "authorization_code", code: code, client_id: (env.YANDEX_CLIENT_ID || YANDEX_ID), client_secret: (env.YANDEX_CLIENT_SECRET || YANDEX_SECRET) }).toString(),
    });
    const tj = await tr.json();
    if (tj && tj.access_token) {
      const ir = await fetch("https://login.yandex.ru/info?format=json", { headers: { Authorization: "OAuth " + tj.access_token } });
      if (ir.ok) info = await ir.json();
    }
  } catch (e) { info = null; }
  const yid = info && info.id ? String(info.id).replace(/\D/g, "") : "";
  if (!yid) return gPage(false, "Yandex javobi tasdiqlanmadi. Qaytadan urinib ko'ring.");
  const t = { sub: "y" + yid, email: info.default_email || "", name: info.real_name || info.display_name || info.login || "Mijoz" };
  const lkr = await env.PRODUCTS.get("lkg:" + state, "json");
  if (lkr && (lkr.k || lkr.tgId)) {
    await env.PRODUCTS.delete("lkg:" + state);
    const lr = await linkIdents(env, lkr.k || "t" + lkr.tgId, identKeyFromSub(String(t.sub)));
    return gPage(lr.ok, lr.msg);
  }
  const x = await googleAccount(env, t);
  await env.PRODUCTS.put("login:" + state, JSON.stringify(x), { expirationTtl: 300 });
  return gPage(true, "Endi Telegramga qayting. Do'kon avtomatik kiradi.");
}
async function handleGoogleCb(request, env) {
  let fd = null;
  try { fd = await request.formData(); } catch (e) { fd = null; }
  const state = String((fd && fd.get("state")) || ""), idt = String((fd && fd.get("id_token")) || "");
  if (!/^[a-f0-9]{24}$/.test(state)) return gPage(false, "Havola noto'g'ri.");
  if (!fd || !fd.get("id_token")) return gPage(false, "Google kirishni rad etdi yoki bekor qilindi. Do'konga qaytib, qayta urinib ko'ring.");
  const nonce = await env.PRODUCTS.get("gn:" + state);
  if (!nonce || idt.length < 100 || idt.length > 4000) return gPage(false, "Vaqt tugagan. Do'konga qaytib, qaytadan urinib ko'ring.");
  const t = await googleTokenInfo(env, idt);
  if (!t || t.nonce !== nonce) return gPage(false, "Google javobi tasdiqlanmadi. Qaytadan urinib ko'ring.");
  await env.PRODUCTS.delete("gn:" + state);
  const lkr = await env.PRODUCTS.get("lkg:" + state, "json");
  if (lkr && (lkr.k || lkr.tgId)) {
    await env.PRODUCTS.delete("lkg:" + state);
    const lr = await linkIdents(env, lkr.k || "t" + lkr.tgId, identKeyFromSub(String(t.sub)));
    return gPage(lr.ok, lr.msg);
  }
  const x = await googleAccount(env, t);
  await env.PRODUCTS.put("login:" + state, JSON.stringify(x), { expirationTtl: 300 });
  return gPage(true, "Endi Telegramga qayting. Do'kon avtomatik kiradi.");
}
async function handleGooglePhone(env, body, origin) {
  const key = "gpend:" + String(body.ptoken || "").replace(/[^a-z0-9]/g, "");
  const pend = await env.PRODUCTS.get(key, "json");
  if (!pend) return json({ ok: false, error: "expired" }, 410, origin);
  const phone = normPhone(body.phone);
  if (!phone) return json({ ok: false, error: "phone" }, 400, origin);
  const gkey = "g" + pend.sub, gg = await groupOf(env, gkey), gkeys = gg ? memberKeys(gg.m) : [gkey];
  if (await phoneTakenByOther(env, phone, gkeys, gkeys.find((k) => k[0] === "t") || gkey)) return json({ ok: false, error: "taken" }, 409, origin);
  await env.PRODUCTS.put("g:" + pend.sub, JSON.stringify({ name: pend.name, email: pend.email, phone: phone }));
  await upsertAcc(env, { k: "g" + pend.sub, p: "g", id: pend.sub, name: pend.name, email: pend.email, phone: phone });
  await env.PRODUCTS.delete(key);
  const token = await makeSession(env, { gid: pend.sub, name: pend.name, phone: phone, email: pend.email });
  return json({ ok: true, token: token, name: pend.name }, 200, origin);
}


// ---------- PROFIL (ism, familya, telefon) ----------

// ---------- TELEGRAM MINI APP LOGIN ----------
async function tgHmac(keyBytes, msg) {
  const k = await crypto.subtle.importKey("raw", keyBytes, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC", k, typeof msg === "string" ? new TextEncoder().encode(msg) : msg));
}
async function verifyInitData(botToken, initData) {
  const params = new URLSearchParams(initData);
  const hash = params.get("hash") || "";
  params.delete("hash");
  if (!/^[a-f0-9]{64}$/.test(hash)) return null;
  const dcs = Array.from(params.entries()).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).map((e) => e[0] + "=" + e[1]).join("\n");
  const secret = await tgHmac(new TextEncoder().encode("WebAppData"), botToken);
  const calc = Array.from(await tgHmac(secret, dcs)).map((b) => b.toString(16).padStart(2, "0")).join("");
  let diff = 0;
  for (let i = 0; i < 64; i++) diff |= calc.charCodeAt(i) ^ hash.charCodeAt(i);
  if (diff !== 0) return null;
  const age = Date.now() / 1000 - Number(params.get("auth_date") || 0);
  if (!(age >= -60 && age < 60 * 60 * 24)) return null;
  try { return JSON.parse(params.get("user") || "null"); } catch (e) { return null; }
}
async function handleTgLogin(env, body, origin) {
  const initData = typeof body.initData === "string" ? body.initData : "";
  if (initData.length < 20 || initData.length > 4000) return json({ ok: false, error: "initData" }, 400, origin);
  const bt = env.SHOP_BOT_TOKEN || env.CUSTOMER_BOT_TOKEN;
  if (!bt) return json({ ok: false, error: "config" }, 503, origin);
  const u = await verifyInitData(bt, initData);
  if (!u || !u.id) return json({ ok: false, error: "invalid" }, 401, origin);
  const tname = clean(((u.first_name || "") + " " + (u.last_name || "")).trim(), 60) || "Mijoz";
  const sdata = { tgId: u.id, name: tname, phone: "" };
  const tp = await env.PRODUCTS.get("tgp:" + u.id, "json");
  if (tp) { sdata.name = tp.name || tname; sdata.f = tp.f; sdata.l = tp.l; sdata.phone = tp.phone || ""; }
  await upsertAcc(env, { k: "t" + u.id, p: "t", id: u.id, name: sdata.name, un: u.username || "", phone: sdata.phone || undefined });
  const token = await makeSession(env, sdata);
  return json({ ok: true, token: token, name: sdata.name, tg: u.id }, 200, origin);
}
async function handleProfile(env, body, origin) {
  const token = String(body.token || "").replace(/[^a-z0-9]/g, "");
  const sess = await getSession(env, token);
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const first = clean(body.first, 30).trim(), last = clean(body.last, 30).trim();
  const phone = normPhone(body.phone);
  if (first.length < 2) return json({ ok: false, error: "name" }, 400, origin);
  if (!phone) return json({ ok: false, error: "phone" }, 400, origin);
  const owner = ownerOf(sess), oldPhone = normPhone(sess.phone);
  const ownKeys = ownersOf(sess);
  if (await phoneTakenByOther(env, phone, ownKeys, owner)) return json({ ok: false, error: "taken" }, 409, origin);
  const oldPw = oldPhone ? await pwAccount(env, oldPhone) : null;
  if (oldPw && !pwOwnerMatches(oldPw, sess)) return json({ ok: false, error: "taken" }, 409, origin);
  const name = clean((first + " " + last).trim(), 60);
  sess.name = name; sess.f = first; sess.l = last; sess.phone = phone;
  if (oldPw && oldPhone !== phone) {
    await env.PRODUCTS.delete("pwacct:" + oldPhone); await env.PRODUCTS.delete("phoneidx:" + oldPhone);
    oldPw.phone = phone; oldPw.owner = owner; oldPw.keys = ownersOf(sess); oldPw.name = name; oldPw.updated = Date.now();
    await env.PRODUCTS.put("pwacct:" + phone, JSON.stringify(oldPw)); await env.PRODUCTS.put("phoneidx:" + phone, owner);
  } else if (oldPw) {
    oldPw.name = name; oldPw.keys = ownersOf(sess); await env.PRODUCTS.put("pwacct:" + phone, JSON.stringify(oldPw));
  }
  await env.PRODUCTS.put("sess:" + token, JSON.stringify(rawSession(sess)), { expirationTtl: 60 * 60 * 24 * 30 });
  // Bir guruhga ulangan barcha identifikatorlarda telefon va ismni bir xil yangilash.
  for (const key of ownersOf(sess)) {
    if (key[0] === "t") {
      const id = key.slice(1), tp = (await env.PRODUCTS.get("tgp:" + id, "json")) || {};
      await env.PRODUCTS.put("tgp:" + id, JSON.stringify(Object.assign(tp, { name: name, f: first, l: last, phone: phone })));
      await upsertAcc(env, { k: key, p: "t", id: id, name: name, phone: phone });
    } else {
      const id = key[0] === "y" ? key : key.slice(1), acc = (await env.PRODUCTS.get("g:" + id, "json")) || {};
      await env.PRODUCTS.put("g:" + id, JSON.stringify(Object.assign(acc, { name: name, f: first, l: last, phone: phone, email: acc.email || sess.email || "" })));
      await upsertAcc(env, { k: key, p: key[0] === "y" ? "y" : "g", id: id, name: name, email: acc.email || sess.email || "", phone: phone });
    }
  }
  return json({ ok: true, name: name, first: first, last: last, phone: phone }, 200, origin);
}

// ---- UzPost filiallari (uz.post xaritasi API'si, CORS uchun proxy) ----
const UZP_REGIONS = ["Toshkent sh.", "Toshkent v.", "Samarqand", "Buxoro", "Navoiy", "Qashqadaryo", "Surxondaryo", "Jizzax", "Sirdaryo", "Farg'ona", "Andijon", "Namangan", "Xorazm", "Qoraqalpog'iston"];
const UZP_PREFIX = { 14: 2, 20: 3, 21: 4, 18: 5, 19: 6, 13: 7, 12: 8, 15: 9, 17: 10, 16: 11, 22: 12, 23: 13, 24: 13 };
const UZP_CENTERS = [[41.31, 69.28], [41.0, 69.9], [39.65, 66.96], [39.77, 64.42], [40.1, 65.4], [38.85, 65.8], [37.5, 67.3], [40.1, 67.8], [40.5, 68.8], [40.4, 71.8], [40.78, 72.34], [41.0, 71.67], [41.55, 60.63], [43.0, 59.0]];
function uzpRegion(idx, lat, lng) {
  const p = Math.floor(idx / 10000);
  if (p === 10 || p === 11) {
    const city = lat > 41.19 && lat < 41.43 && lng > 69.1 && lng < 69.42;
    return city ? 0 : 1;
  }
  if (UZP_PREFIX[p] !== undefined) return UZP_PREFIX[p];
  let best = 0, bd = 1e9;
  UZP_CENTERS.forEach((c, i) => { const d = (c[0] - lat) * (c[0] - lat) + (c[1] - lng) * (c[1] - lng); if (d < bd) { bd = d; best = i; } });
  return best;
}
async function uzpostOffices(env, origin) {
  const cache = caches.default;
  const key = new Request("https://sarbon-cache.local/uzpost-offices-v1");
  let body = null;
  const hit = await cache.match(key);
  if (hit) body = await hit.text();
  if (!body) {
    const up = await fetch("https://new.pochta.uz/api/v1/maps/new/post/offices/", {
      headers: { "Origin": "https://uz.post", "Referer": "https://uz.post/", "Accept": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36" }
    });
    if (!up.ok) return json({ ok: false, error: "uzpost " + up.status }, 502, origin);
    const d = await up.json();
    const items = [];
    (d.result || []).forEach((o) => {
      const lat = parseFloat(o.lat), lng = parseFloat(o.lng), idx = parseInt(o.index, 10);
      if (!(lat > 36 && lat < 46 && lng > 55 && lng < 75) || !idx) return;
      items.push([o.id, idx, Math.round(lat * 1e5) / 1e5, Math.round(lng * 1e5) / 1e5, uzpRegion(idx, lat, lng)]);
    });
    body = JSON.stringify({ ok: true, n: items.length, regions: UZP_REGIONS, items: items });
    await cache.put(key, new Response(body, { headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=3600" } }));
  }
  return new Response(body, { status: 200, headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": origin, "Cache-Control": "public, max-age=3600" } });
}

// ---------- TAKLIF (referal) VA SHAXSIY KUPONLAR ----------
// KV: ref:<KOD> -> owner | refown:<owner> -> { code, invited: n } | cp:<owner> -> [{code,pct,why,t,used,usedAt,oid}]
//     refby:<owner> -> kim taklif qilgan (bir marta) | refph:<telefon> -> 1 (bitta raqam bir marta)
const REF_PCT = 5; // taklif kuponi (ikkala tomonga)
const REVIEW_PCT = 10; // sharh uchun kupon (bir buyurtmaga bir marta)
const rndCode = (n) => {
  const a = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", b = new Uint8Array(n);
  let r = "";
  crypto.getRandomValues(b);
  for (let i = 0; i < n; i++) r += a[b[i] % a.length];
  return r;
};
const getCoupons = async (env, owner) => (await env.PRODUCTS.get("cp:" + owner, "json")) || [];
const putCoupons = (env, owner, l) => env.PRODUCTS.put("cp:" + owner, JSON.stringify(l.slice(0, 100)));
async function addCoupon(env, owner, why, pct) {
  const l = await getCoupons(env), code = "SB" + rndCode(6);
  l.unshift({ code: code, pct: pct || REF_PCT, why: why, t: Date.now(), used: false });
  await putCoupons(env, owner, l);
  return code;
}
async function ensureRef(env, owner) {
  let r = await env.PRODUCTS.get("refown:" + owner, "json");
  if (r && r.code) return r;
  let code = "";
  for (let i = 0; i < 5; i++) {
    const c = rndCode(6);
    if (!(await env.PRODUCTS.get("ref:" + c))) { code = c; break; }
  }
  if (!code) code = rndCode(8);
  r = { code: code, invited: 0 };
  await env.PRODUCTS.put("ref:" + code, owner);
  await env.PRODUCTS.put("refown:" + owner, JSON.stringify(r));
  return r;
}
async function handleRefInfo(env, token, origin) {
  const sess = await getSession(env, String(token || "").replace(/[^a-z0-9]/g, ""));
  const owner = sess ? ownerOf(sess) : "";
  if (!owner) return json({ ok: false }, 401, origin);
  const r = await ensureRef(env, owner), cps = await getCoupons(env, owner);
  const base = env.ALLOWED_ORIGIN || "https://sarbonuz.github.io";
  return json({ ok: true, code: r.code, link: base + "/sarbon/?ref=" + r.code, invited: r.invited || 0, coupons: cps.map((c) => ({ code: c.code, pct: c.pct, why: c.why, used: !!c.used })) }, 200, origin);
}
async function handleRefClaim(env, body, origin) {
  const sess = await getSession(env, String(body.token || "").replace(/[^a-z0-9]/g, ""));
  const owner = sess ? ownerOf(sess) : "";
  if (!owner) return json({ ok: false, error: "auth" }, 401, origin);
  const code = String(body.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12);
  const inviter = code ? await env.PRODUCTS.get("ref:" + code) : null;
  if (!inviter) return json({ ok: false, error: "bad" }, 200, origin);
  if (inviter === owner) return json({ ok: false, error: "own" }, 200, origin);
  const ph = normPhone(sess.phone);
  // Google bilan kirganda raqam tasdiqlanmaydi, shuning uchun kupon faqat O'zbekiston raqamiga beriladi
  if (sess.cur !== "t" && sess.gid && !(ph && ph.startsWith("+998"))) return json({ ok: false, error: "phone" }, 200, origin);
  if ((await env.PRODUCTS.get("refby:" + owner)) || (ph && (await env.PRODUCTS.get("refph:" + ph)))) return json({ ok: false, error: "used" }, 200, origin);
  // faqat yangi mijoz (hali buyurtma bermagan) taklif orqali kupon oladi
  const hasOrder = (await getOrders(env)).some((o) => (sess.tgId && o.tg === sess.tgId) || ownsG(sess, o)) || (((await env.PRODUCTS.get("oi:" + owner, "json")) || []).length > 0);
  if (hasOrder) return json({ ok: false, error: "notnew" }, 200, origin);
  await env.PRODUCTS.put("refby:" + owner, inviter);
  if (ph) await env.PRODUCTS.put("refph:" + ph, "1");
  const mine = await addCoupon(env, owner, "welcome");
  const ir = await ensureRef(env, inviter);
  if ((ir.invited || 0) < 10) await addCoupon(env, inviter, "invite"); // bitta odam cheksiz kupon yig'masligi uchun
  ir.invited = (ir.invited || 0) + 1;
  await env.PRODUCTS.put("refown:" + inviter, JSON.stringify(ir));
  try { await say(env, "🎁 Taklif: " + (sess.name || "Mijoz") + " havola orqali keldi. Ikkala tomonga ham " + REF_PCT + "% kupon berildi."); } catch (e) { /* xabar yuborilmasa ham kupon berilgan */ }
  return json({ ok: true, coupon: mine, pct: REF_PCT }, 200, origin);
}

// ---------- WEB PUSH (iOS 16.4+ / Android / desktop) ----------
// Kerak: Secret VAPID_PUBLIC va VAPID_PRIVATE. Kalitlarni /push-keygen?key=WEBHOOK_SECRET beradi.
// KV: ps:<owner> -> [{ e: endpoint, p: p256dh, a: auth, t: vaqt }]
const b64u = (buf) => {
  const u = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
const unb64u = (str) => {
  let t = String(str || "").replace(/-/g, "+").replace(/_/g, "/");
  while (t.length % 4) t += "=";
  const b = atob(t), u = new Uint8Array(b.length);
  for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i);
  return u;
};
const catBytes = (...a) => {
  const o = new Uint8Array(a.reduce((n, x) => n + x.length, 0));
  let k = 0;
  a.forEach((x) => { o.set(x, k); k += x.length; });
  return o;
};
const PUSH_HOSTS = /(^|\.)(web\.push\.apple\.com|push\.apple\.com|fcm\.googleapis\.com|updates\.push\.services\.mozilla\.com|notify\.windows\.com)$/;
async function hkdf(ikm, salt, info, len) {
  const k = await crypto.subtle.importKey("raw", ikm, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: "HKDF", hash: "SHA-256", salt: salt, info: info }, k, len * 8));
}
async function encryptPush(sub, payload) {
  const ua = unb64u(sub.p), auth = unb64u(sub.a), enc = new TextEncoder();
  const eph = await crypto.subtle.generateKey({ name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]);
  const asPub = new Uint8Array(await crypto.subtle.exportKey("raw", eph.publicKey));
  const uaKey = await crypto.subtle.importKey("raw", ua, { name: "ECDH", namedCurve: "P-256" }, false, []);
  const secret = new Uint8Array(await crypto.subtle.deriveBits({ name: "ECDH", public: uaKey }, eph.privateKey, 256));
  const ikm = await hkdf(secret, auth, catBytes(enc.encode("WebPush: info\u0000"), ua, asPub), 32);
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const cek = await hkdf(ikm, salt, enc.encode("Content-Encoding: aes128gcm\u0000"), 16);
  const nonce = await hkdf(ikm, salt, enc.encode("Content-Encoding: nonce\u0000"), 12);
  const aes = await crypto.subtle.importKey("raw", cek, "AES-GCM", false, ["encrypt"]);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aes, catBytes(enc.encode(payload), new Uint8Array([2]))));
  const hdr = new Uint8Array(21);
  hdr.set(salt, 0);
  new DataView(hdr.buffer).setUint32(16, 4096);
  hdr[20] = 65;
  return catBytes(hdr, asPub, ct);
}
async function vapidJwt(env, aud) {
  const pub = unb64u(env.VAPID_PUBLIC), enc = new TextEncoder();
  const key = await crypto.subtle.importKey("jwk", { kty: "EC", crv: "P-256", x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), d: env.VAPID_PRIVATE, ext: true }, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const head = b64u(enc.encode(JSON.stringify({ typ: "JWT", alg: "ES256" })));
  const claims = b64u(enc.encode(JSON.stringify({ aud: aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: env.VAPID_SUBJECT || "mailto:admin@sarbon.uz" })));
  const sig = await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(head + "." + claims));
  return head + "." + claims + "." + b64u(sig);
}
async function sendPush(env, sub, data) {
  const body = await encryptPush(sub, JSON.stringify(data));
  const r = await fetch(sub.e, {
    method: "POST",
    headers: { "Content-Encoding": "aes128gcm", "Content-Type": "application/octet-stream", TTL: "86400", Urgency: "high", Authorization: "vapid t=" + (await vapidJwt(env, new URL(sub.e).origin)) + ", k=" + env.VAPID_PUBLIC },
    body: body,
  });
  return r.status;
}
async function pushTo(env, owner, data) {
  if (!owner || !env.VAPID_PUBLIC || !env.VAPID_PRIVATE) return;
  const list = (await env.PRODUCTS.get("ps:" + owner, "json")) || [];
  if (!list.length) return;
  const dead = [];
  await Promise.all(list.map(async (sub) => {
    try {
      const st = await sendPush(env, sub, data);
      if (st === 404 || st === 410) dead.push(sub.e);
    } catch (e) { /* bitta qurilma ishlamasa, qolganlariga yuboriladi */ }
  }));
  if (dead.length) await env.PRODUCTS.put("ps:" + owner, JSON.stringify(list.filter((x) => dead.indexOf(x.e) < 0)));
}
async function handlePushSub(env, body, origin) {
  const sess = await getSession(env, String(body.token || "").replace(/[^a-z0-9]/g, ""));
  const owner = sess ? ownerOf(sess) : "";
  if (!owner) return json({ ok: false, error: "auth" }, 401, origin);
  const sub = body.sub || {}, keys = sub.keys || {};
  let host = "";
  try { const u = new URL(String(sub.endpoint || "")); if (u.protocol === "https:") host = u.hostname; } catch (e) { /* noto'g'ri */ }
  if (!host || !PUSH_HOSTS.test(host) || !keys.p256dh || !keys.auth) return json({ ok: false, error: "sub" }, 400, origin);
  const list = ((await env.PRODUCTS.get("ps:" + owner, "json")) || []).filter((x) => x.e !== sub.endpoint);
  list.unshift({ e: String(sub.endpoint), p: String(keys.p256dh), a: String(keys.auth), t: Date.now() });
  await env.PRODUCTS.put("ps:" + owner, JSON.stringify(list.slice(0, 5)));
  return json({ ok: true }, 200, origin);
}
// ---------- END WEB PUSH ----------

// =====================================================================
// ---------- VERIFIKATSIYA / BADGE / SHARH / ADMIN BOT (qo'shimcha modul) ----------
// Kerakli sozlamalar: D1 binding "DB", secrets: ADMIN_BOT_TOKEN, ADMIN_IDS, PASSPORT_HMAC_KEY, DOC_KEY
// =====================================================================
const ADMIN_HTML = "<!doctype html><html lang=\"uz\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"robots\" content=\"noindex\"><title>Sarbon Admin</title>\n<style>\n*{box-sizing:border-box}body{margin:0;font:14px system-ui,sans-serif;background:#0f1115;color:#e8e8ea}\nheader{padding:12px 14px;background:#171a21;position:sticky;top:0;z-index:2;display:flex;gap:6px;flex-wrap:wrap;align-items:center}\nheader b{margin-right:8px}button{font:inherit;border:0;border-radius:8px;padding:7px 11px;background:#2a2f3a;color:#fff;cursor:pointer}\nbutton.on{background:#3b82f6}button.ok{background:#16a34a}button.no{background:#dc2626}button.wr{background:#d97706}\nmain{padding:14px;max-width:1000px;margin:auto}table{width:100%;border-collapse:collapse;margin-top:8px}\ntd,th{padding:7px;border-bottom:1px solid #262b36;text-align:left;vertical-align:top;word-break:break-word}th{color:#8b93a5;font-weight:500}\n.card{background:#171a21;border-radius:12px;padding:14px;margin-top:10px}.mut{color:#8b93a5}\ninput,textarea{font:inherit;background:#0f1115;color:#fff;border:1px solid #2a2f3a;border-radius:8px;padding:7px;width:100%}\nimg.pp{max-width:100%;border-radius:10px;margin-top:10px;background:#000}.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}\n.tg{display:inline-block;padding:2px 8px;border-radius:99px;background:#2a2f3a;font-size:12px}\n</style></head><body>\n<header><b>\ud83d\udd10 Sarbon Admin</b><span id=\"nav\"></span> <a href=\"/admin/import\" style=\"margin-left:12px;color:#8fb4ff;font-weight:600\">\ud83d\udce5 Mahsulot import</a> <a href=\"/admin/products\" style=\"margin-left:12px;color:#8fb4ff;font-weight:600\">🛍 Tovarlar</a></header><main id=\"m\"><p class=\"mut\">Yuklanmoqda...</p></main>\n<script>\nvar TOK=sessionStorage.getItem(\"adm\"),M=document.getElementById(\"m\"),TABS=[[\"pending\",\"Verifikatsiya so'rovlari\"],[\"decided\",\"Tasdiqlangan/rad etilgan\"],[\"dups\",\"Takroriy pasport\"],[\"users\",\"Foydalanuvchilar\"],[\"tglinked\",\"Telegram akkauntlar\"],[\"orders\",\"Buyurtmalar\"],[\"reviews\",\"Sharhlar\"],[\"badges\",\"Badge sozlamalari\"],[\"audit\",\"Admin tarixi\"]];\nfunction E(s){var d=document.createElement(\"div\");d.textContent=s==null?\"\":String(s);return d.innerHTML}\nfunction D(t){return t?new Date(Number(t)+5*36e5).toISOString().slice(0,16).replace(\"T\",\" \"):\"\u2014\"}\nfunction api(p,b){var o={headers:{\"X-Admin\":TOK}};if(b){o.method=\"POST\";o.headers[\"Content-Type\"]=\"application/json\";o.body=JSON.stringify(b)}\n return fetch(p,o).then(function(r){if(r.status===401){sessionStorage.removeItem(\"adm\");M.innerHTML='<p>Sessiya tugagan. Admin botda /panel yuboring.</p>';throw 0}return r})}\nfunction nav(cur){document.getElementById(\"nav\").innerHTML=TABS.map(function(t){return '<button class=\"'+(t[0]===cur?\"on\":\"\")+'\" onclick=\"tab(\\''+t[0]+'\\')\">'+t[1]+'</button>'}).join(\"\")}\nfunction table(cols,rows,fn){return '<table><tr>'+cols.map(function(c){return '<th>'+c+'</th>'}).join(\"\")+'</tr>'+rows.map(fn).join(\"\")+'</table>'+(rows.length?'':'<p class=\"mut\">Bo\\'sh</p>')}\nfunction tab(t){nav(t);M.innerHTML='<p class=\"mut\">Yuklanmoqda...</p>';\n if(t===\"badges\")return badges();\n api(\"/admin/api/list?t=\"+t).then(function(r){return r.json()}).then(function(d){var R=d.rows||[],h=\"\";\n  if(t===\"pending\")h=table([\"ID\",\"Foydalanuvchi\",\"Holat\",\"Vaqt\",\"\"],R,function(r){return '<tr><td>#'+r.id+'</td><td>'+E(r.name)+'<br><span class=\"mut\">'+E(r.owner)+'</span></td><td>'+E(r.status)+'</td><td>'+D(r.created_at)+'</td><td><button onclick=\"openV('+r.id+')\">Ochish</button></td></tr>'});\n  if(t===\"decided\")h=table([\"ID\",\"Foydalanuvchi\",\"Holat\",\"Qaror\",\"Sabab\"],R,function(r){return '<tr><td>#'+r.id+'</td><td>'+E(r.name)+'<br><span class=\"mut\">'+E(r.owner)+'</span></td><td>'+E(r.status)+'</td><td>'+D(r.decided_at)+'<br><span class=\"mut\">admin '+E(r.decided_by)+'</span></td><td>'+E(r.reject_reason)+'</td></tr>'});\n  if(t===\"dups\")h=table([\"#\",\"Uringan akkaunt\",\"Pasport egasi\",\"Vaqt\"],R,function(r){return '<tr><td>'+r.id+'</td><td>'+E(r.owner)+'</td><td>'+E(r.existing_owner)+'</td><td>'+D(r.created_at)+'</td></tr>'});\n  if(t===\"users\"||t===\"tglinked\")h=table([\"Ism\",\"Tur\",\"Telegram ID\",\"Telefon\",\"Buyurtma\",\"Verifikatsiya\"],R,function(r){return '<tr><td>'+E(r.name)+'</td><td>'+E(r.p)+'</td><td>'+E(r.tg)+'</td><td>'+E(r.phone)+'</td><td>'+r.orders+'</td><td>'+(r.verified?\"\u2705\":\"\u2014\")+'</td></tr>'});\n  if(t===\"orders\")h=table([\"ID\",\"Mijoz\",\"Summa\",\"Holat\",\"Vaqt\"],R,function(r){return '<tr><td>'+E(r.id)+'</td><td>'+E(r.name)+'<br><span class=\"mut\">'+E(r.phone)+'</span></td><td>'+E(r.total)+'</td><td>'+E(r.status)+'</td><td>'+D(r.t)+'</td></tr>'});\n  if(t===\"reviews\")h=table([\"Mijoz\",\"Baho\",\"Sharh\",\"Javob\",\"\"],R,function(r){return '<tr><td>'+E(r.name)+'<br><span class=\"mut\">#'+E(r.oid)+'</span></td><td>'+r.rating+'\u2605</td><td>'+E(r.text)+'</td><td>'+E(r.reply)+'</td><td><button onclick=\"rep('+r.id+')\">Javob</button> <button class=\"no\" onclick=\"del('+r.id+')\">O\\'chirish</button></td></tr>'});\n  if(t===\"audit\")h=table([\"Vaqt\",\"Kim\",\"Amal\",\"Obyekt\",\"Izoh\"],R,function(r){return '<tr><td>'+D(r.created_at)+'</td><td>'+E(r.actor)+'</td><td>'+E(r.action)+'</td><td>'+E(r.target)+'</td><td>'+E(r.detail)+'</td></tr>'});\n  M.innerHTML=h}).catch(function(){})}\nfunction openV(id){nav(\"\");M.innerHTML='<p class=\"mut\">Yuklanmoqda...</p>';\n api(\"/admin/api/v?id=\"+id).then(function(r){return r.json()}).then(function(d){if(!d.ok){M.innerHTML=\"Topilmadi\";return}var v=d.v,fin=v.status===\"approved\"||v.status===\"rejected\";\n  M.innerHTML='<div class=\"card\"><h3>So\\'rov #'+v.id+' <span class=\"tg\">'+E(v.status)+'</span></h3><p>Foydalanuvchi: <b>'+E(v.name)+'</b> ('+E(v.owner)+')<br>Telegram ID: '+E(v.tg_id||\"\u2014\")+'<br>Yuborilgan: '+D(v.created_at)+'<br>Hisobga olingan buyurtmalar: '+d.orders+'</p>'\n  +'<p>Pasport raqami: <b style=\"font-size:18px;letter-spacing:1px\">'+E(d.number||\"(o\\'chirilgan)\")+'</b></p><div id=\"im\"></div>'\n  +(fin?'<p class=\"mut\">Qaror: '+E(v.status)+' \u00b7 '+D(v.decided_at)+(v.reject_reason?' \u00b7 '+E(v.reject_reason):'')+'</p>':'<textarea id=\"rs\" rows=\"2\" placeholder=\"Sabab / izoh (rad etish yoki qo\\'shimcha ma\\'lumot uchun)\"></textarea><div class=\"row\"><button class=\"ok\" onclick=\"dec('+v.id+',\\'approve\\')\">\u2705 Tasdiqlash</button><button class=\"no\" onclick=\"dec('+v.id+',\\'reject\\')\">\u274c Rad etish</button><button class=\"wr\" onclick=\"dec('+v.id+',\\'need_info\\')\">\ud83d\udcdd Qo\\'shimcha ma\\'lumot</button></div>')\n  +'<div class=\"row\"><button onclick=\"purge('+v.id+')\">\ud83d\uddd1 Hujjatni o\\'chirish</button><button onclick=\"tab(\\'pending\\')\">\u2190 Orqaga</button></div></div>';\n  if(d.hasFile)fetch(\"/admin/api/file?id=\"+id,{headers:{\"X-Admin\":TOK}}).then(function(r){return r.blob()}).then(function(b){var i=new Image();i.className=\"pp\";i.src=URL.createObjectURL(b);document.getElementById(\"im\").appendChild(i)})}).catch(function(){})}\nfunction dec(id,a){var rs=(document.getElementById(\"rs\")||{}).value||\"\";if(a!==\"approve\"&&a!==\"reject\"&&!rs.trim()){alert(\"Izoh yozing\");return}if(!confirm(\"Tasdiqlaysizmi?\"))return;\n api(\"/admin/api/decide\",{id:id,action:a,reason:rs}).then(function(r){return r.json()}).then(function(d){alert(d.ok?\"Bajarildi\":({duplicate:\"Pasport boshqa akkauntga bog'langan! So'rov rad etildi.\",decided:\"Allaqachon hal qilingan\",notviewed:\"Avval hujjatni oching\"}[d.error]||\"Xatolik\"));openV(id)})}\nfunction purge(id){if(confirm(\"Pasport rasmi va raqami butunlay o'chiriladi. Davom etasizmi?\"))api(\"/admin/api/purge\",{id:id}).then(function(){openV(id)})}\nfunction rep(id){var t=prompt(\"Do'kon egasi javobi:\");if(t!==null)api(\"/admin/api/review-reply\",{id:id,text:t}).then(function(){tab(\"reviews\")})}\nfunction del(id){if(confirm(\"Sharh o'chirilsinmi?\"))api(\"/admin/api/review-del\",{id:id}).then(function(){tab(\"reviews\")})}\nfunction badges(){api(\"/admin/api/badges\",{}).then(function(r){return r.json()}).then(function(d){var T=d.cfg.tiers;\n M.innerHTML='<div class=\"card\"><p class=\"mut\">Badge buyurtmalar soniga qarab beriladi (bekor qilingan va yangi/tasdiqlanmagan buyurtmalar hisoblanmaydi). Chegaralar o\\'sib borishi kerak.</p>'+T.map(function(t,i){return '<div class=\"row\"><input id=\"k'+i+'\" value=\"'+E(t.k)+'\" style=\"width:90px\"><input id=\"n'+i+'\" value=\"'+E(t.name)+'\" style=\"width:120px\"><input id=\"m'+i+'\" type=\"number\" min=\"1\" value=\"'+t.min+'\" style=\"width:90px\"><input id=\"c'+i+'\" type=\"color\" value=\"'+E(t.color)+'\" style=\"width:60px\"></div>'}).join(\"\")+'<div class=\"row\"><button class=\"ok\" onclick=\"saveB('+T.length+')\">Saqlash</button></div></div>'})}\nfunction saveB(n){var t=[];for(var i=0;i<n;i++)t.push({k:document.getElementById(\"k\"+i).value,name:document.getElementById(\"n\"+i).value,min:document.getElementById(\"m\"+i).value,color:document.getElementById(\"c\"+i).value});\n api(\"/admin/api/badges\",{tiers:t}).then(function(r){return r.json()}).then(function(d){alert(d.ok?\"Saqlandi\":\"Noto'g'ri qiymat (chegaralar o'sib borishi kerak)\")})}\n(function(){var q=new URLSearchParams(location.search),c=q.get(\"c\"),v=q.get(\"v\");\n function go(){nav(\"pending\");if(v&&v!==\"0\")openV(Number(v));else tab(\"pending\")}\n if(c){history.replaceState(null,\"\",\"/admin\");fetch(\"/admin/exchange\",{method:\"POST\",headers:{\"Content-Type\":\"application/json\"},body:JSON.stringify({code:c})}).then(function(r){return r.json()}).then(function(d){if(!d.ok){M.innerHTML=\"<p>Havola eskirgan yoki ishlatilgan. Admin botda /panel yuboring.</p>\";return}TOK=d.token;sessionStorage.setItem(\"adm\",TOK);go()})}\n else if(TOK)go();else M.innerHTML=\"<p>Kirish uchun admin Telegram botda /panel yuboring.</p>\"})();\n</script></body></html>\n";
const V_STATUS = { none: "Verifikatsiyadan o'tmagan", pending: "⏳ Tekshirilmoqda", approved: "✅ Tasdiqlangan", rejected: "❌ Rad etilgan", need_info: "📝 Qo'shimcha ma'lumot talab qilinadi" };
const DEFAULT_BADGES = { tiers: [
  { k: "green", name: "Subscriber", min: 1, color: "#84cc16" },
  { k: "gold", name: "Gold", min: 5, color: "#f59e0b" },
  { k: "plat", name: "Platinum", min: 10, color: "#93c5fd" },
  { k: "sky", name: "Diamond", min: 20, color: "#6366f1" },
  { k: "elite", name: "Elite", min: 35, color: "#a855f7" },
  { k: "red", name: "Legend", min: 50, color: "#f97316" },
] };
const vAdminTok = (env) => env.ADMIN_BOT_TOKEN || env.BOT_TOKEN; // alohida admin bot berilmasa mavjud admin botingiz ishlatiladi
const vReady = (env) => !!(env.DB && env.DOC_KEY && env.PASSPORT_HMAC_KEY && vAdminTok(env));
const vb64 = (u8) => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const vunb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
async function vKey(env) { return crypto.subtle.importKey("raw", await crypto.subtle.digest("SHA-256", new TextEncoder().encode(env.DOC_KEY)), "AES-GCM", false, ["encrypt", "decrypt"]); }
async function vEnc(env, u8) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, await vKey(env), u8));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return vb64(out);
}
async function vDec(env, s) { const u = vunb64(s); return new Uint8Array(await crypto.subtle.decrypt({ name: "AES-GCM", iv: u.slice(0, 12) }, await vKey(env), u.slice(12))); }
async function vHmac(env, s) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(env.PASSPORT_HMAC_KEY), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return [...new Uint8Array(await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(s)))].map((b) => b.toString(16).padStart(2, "0")).join("");
}
const vAdminIds = (env) => String(env.ADMIN_IDS || env.CHAT_ID || "").split(/[,\s]+/).filter(Boolean);
const vIsAdmin = (env, id) => vAdminIds(env).indexOf(String(id)) >= 0;
const vtg = (env, method, body) => fetch("https://api.telegram.org/bot" + vAdminTok(env) + "/" + method, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then((r) => r.json()).catch(() => ({ ok: false }));
const vSite = (env) => (env.ALLOWED_ORIGIN || "https://sarbonuz.github.io") + "/sarbon/";
async function vAudit(env, actor, action, target, detail) {
  try { await env.DB.prepare("INSERT INTO audit_log(actor,action,target,detail,created_at) VALUES(?,?,?,?,?)").bind(String(actor), action, String(target || ""), String(detail || "").slice(0, 300), Date.now()).run(); } catch (e) { /* audit xatosi asosiy ishni to'xtatmasin */ }
}
// Saqlangan eski o'zbekcha nomlar (standart nomlar) yangi inglizcha nomlarga almashtiriladi; admin qo'lda yozgan nomlar o'zgarmaydi
const OLD_BN = { green: "Yashil", blue: "Ko'k", sky: "Havorang", elite: "Elite", red: "Qizil" }, NEW_BN = { green: "Rookie", blue: "Pro", sky: "Diamond", elite: "Elite", red: "Legend" };
const vBadgeCfg = async (env) => {
  const c = await env.PRODUCTS.get("badgecfg", "json");
  if (!c || !Array.isArray(c.tiers) || !c.tiers.some((t) => t.k === "gold")) return DEFAULT_BADGES;
  return c;
};
const vMask = (n) => { const p = String(n || "Mijoz").trim().split(/\s+/); return p[0] + (p[1] ? " " + p[1][0] + "." : ""); };
const vOwnerTg = (owner) => (String(owner).charAt(0) === "t" ? String(owner).slice(1) : "");

// Foydalanuvchiga Mijoz botida xabar (+ push). Yuborilmasa ham qaror saqlangan bo'ladi.
async function vNotifyUser(env, owner, text) {
  const tgId = vOwnerTg(owner);
  if (tgId) { try { await csay(env, tgId, text, { reply_markup: { inline_keyboard: [[{ text: "🪪 Verifikatsiya sahifasi", url: vSite(env) + "?verify=1" }]] } }); } catch (e) { /* bot bloklangan bo'lishi mumkin */ } }
  try { await pushTo(env, owner, { t: "verify", title: "Sarbon", text: text.slice(0, 200), ts: Date.now() }); } catch (e) { /* push ixtiyoriy */ }
}
async function vNotifyAdmins(env, text, kb) {
  for (const id of vAdminIds(env)) { try { await vtg(env, "sendMessage", Object.assign({ chat_id: id, text: text }, kb ? { reply_markup: kb } : {})); } catch (e) { /* bitta admin xatosi boshqalarga halaqit bermasin */ } }
}
async function vOrdersOf(env, owner) {
  const all = await getOrdersMemo(env);
  const set = new Set(OWS(owner));
  return all.filter((o) => (o.tg && set.has("t" + o.tg)) || (o.g && set.has("g" + o.g)));
}
const vCountable = (o) => o.status && o.status !== "bekor" && o.status !== "yangi"; // faqat tasdiqlangan va bekor qilinmagan buyurtmalar
async function vBadgeFor(env, owner, cfg, orders) {
  const row = await env.DB.prepare("SELECT 1 AS x FROM verified_users WHERE owner IN (" + SQLIN(owner) + ")").bind(...OWS(owner)).first();
  const n = (orders || (await vOrdersOf(env, owner))).filter(vCountable).length;
  const unlocked = cfg.tiers.filter((t) => n >= t.min);
  let pref = null;
  for (const o1 of OWS(owner)) { pref = await env.PRODUCTS.get("bpref:" + o1); if (pref) break; }
  let tier = unlocked.find((t) => t.k === pref) || unlocked[unlocked.length - 1] || null;
  return { verified: !!row, orders: n, tier: tier, unlocked: unlocked.map((t) => t.k) };
}

// ---------- SO'ROV YUBORISH ----------
function vImgOk(u8, mime) {
  if (mime === "image/jpeg") return u8[0] === 0xff && u8[1] === 0xd8 && u8[2] === 0xff;
  if (mime === "image/png") return u8[0] === 0x89 && u8[1] === 0x50 && u8[2] === 0x4e && u8[3] === 0x47;
  return u8[0] === 0x52 && u8[1] === 0x49 && u8[8] === 0x57 && u8[9] === 0x45; // webp
}
async function vSubmit(env, body, origin) {
  if (!vReady(env)) return json({ ok: false, error: "config" }, 503, origin);
  const sess = await getSession(env, String(body.token || "").replace(/[^a-z0-9]/g, ""));
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const owner = ownerOf(sess), owners = ownersOf(sess);
  if (!owner) return json({ ok: false, error: "auth" }, 401, origin);
  const num = String(body.number || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (num.length < 7 || num.length > 12) return json({ ok: false, error: "number" }, 400, origin);
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(body.image || ""));
  if (!m) return json({ ok: false, error: "image" }, 400, origin);
  let bytes;
  try { bytes = vunb64(m[2]); } catch (e) { return json({ ok: false, error: "image" }, 400, origin); }
  if (bytes.length < 5000 || bytes.length > 900000 || !vImgOk(bytes, m[1])) return json({ ok: false, error: "image" }, 400, origin);
  const db = env.DB;
  const cur = await db.prepare("SELECT id,status FROM verifications WHERE owner IN (" + SQLIN(owners) + ") ORDER BY id DESC LIMIT 1").bind(...owners).first();
  if (cur && cur.status === "approved") return json({ ok: false, error: "already" }, 409, origin);
  if (cur && cur.status === "pending") return json({ ok: false, error: "pending" }, 409, origin);
  const cnt = await db.prepare("SELECT COUNT(*) AS c FROM verifications WHERE owner IN (" + SQLIN(owners) + ") AND created_at>?").bind(...owners, Date.now() - 864e5).first();
  if (cnt && cnt.c >= 3) return json({ ok: false, error: "limit" }, 429, origin);
  const hash = await vHmac(env, num);
  const claim = await db.prepare("SELECT owner FROM passport_claims WHERE passport_hash=?").bind(hash).first();
  if (claim && owners.indexOf(claim.owner) < 0) {
    await db.prepare("INSERT INTO dup_attempts(passport_hash,owner,existing_owner,created_at) VALUES(?,?,?,?)").bind(hash, owner, claim.owner, Date.now()).run();
    await vAudit(env, owner, "dup_blocked", "", "mavjud egasi: " + claim.owner);
    await vNotifyAdmins(env, "⚠️ Takroriy pasport urinishi\nUrinayotgan akkaunt: " + owner + "\nPasport allaqachon bog'langan akkaunt: " + claim.owner + "\nVaqt: " + dt(Date.now()));
    return json({ ok: false, error: "used" }, 409, origin);
  }
  const now = Date.now();
  const numEnc = await vEnc(env, new TextEncoder().encode(num));
  const imgEnc = await vEnc(env, bytes);
  const ins = await db.prepare("INSERT INTO verifications(owner,tg_id,name,status,passport_hash,num_enc,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)")
    .bind(owner, vOwnerTg(owner) || null, clean(sess.name || "Mijoz", 60), "pending", hash, numEnc, now, now).run();
  const vid = ins.meta.last_row_id;
  await db.prepare("INSERT INTO verification_files(vid,mime,data) VALUES(?,?,?)").bind(vid, m[1], imgEnc).run();
  await vAudit(env, owner, "submit", vid, "");
  // Telegram xabari yuborilmasa ham so'rov bazada saqlangan bo'ladi
  try {
    await vNotifyAdmins(env, "🪪 Yangi verifikatsiya so'rovi\n\nSo'rov ID: #" + vid + "\nFoydalanuvchi ID: " + owner + "\nFoydalanuvchi: " + clean(sess.name || "Mijoz", 60) + "\nTelegram ID: " + (vOwnerTg(owner) || "—") + "\nVaqt: " + dt(now) + "\nHolat: " + V_STATUS.pending, {
      inline_keyboard: [[btn("🔍 Pasportni tekshirish", "vv:p:" + vid)], [btn("✅ Tasdiqlash", "vv:a:" + vid), btn("❌ Rad etish", "vv:r:" + vid)], [btn("👤 Profilni ko'rish", "vv:u:" + vid)]],
    });
  } catch (e) { /* ixtiyoriy */ }
  await vNotifyUser(env, owner, "🪪 Verifikatsiya so'rovingiz #" + vid + " qabul qilindi. Admin tekshirmoqda, natijani shu yerda yuboramiz.");
  return json({ ok: true, id: vid, status: "pending" }, 200, origin);
}

// ---------- QAROR (bot ham, veb-admin ham shu funksiyani ishlatadi) ----------
async function vDecide(env, id, action, actor, reason) {
  const db = env.DB;
  const v = await db.prepare("SELECT * FROM verifications WHERE id=?").bind(id).first();
  if (!v) return { ok: false, error: "notfound" };
  if (v.status === "approved" || v.status === "rejected") return { ok: false, error: "decided", status: v.status };
  const now = Date.now(), rs = clean(reason || "", 300);
  if (action === "approve") {
    if (!v.viewed_by) return { ok: false, error: "notviewed" }; // admin avval pasportni ko'rishi shart
    try {
      // Bitta tranzaksiya: UNIQUE buzilsa hammasi bekor bo'ladi (bir vaqtdagi so'rovlarda ham takror bog'lanmaydi)
      await db.batch([
        db.prepare("INSERT INTO passport_claims(passport_hash,owner,vid,created_at) VALUES(?,?,?,?)").bind(v.passport_hash, v.owner, v.id, now),
        db.prepare("UPDATE verifications SET status='approved',decided_by=?,decided_at=?,updated_at=?,reject_reason=NULL WHERE id=? AND status IN ('pending','need_info')").bind(String(actor), now, now, v.id),
        db.prepare("INSERT OR REPLACE INTO verified_users(owner,vid,verified_at) VALUES(?,?,?)").bind(v.owner, v.id, now),
        db.prepare("INSERT INTO audit_log(actor,action,target,detail,created_at) VALUES(?,?,?,?,?)").bind(String(actor), "approve", String(v.id), v.owner, now),
      ]);
    } catch (e) {
      const other = await db.prepare("SELECT owner FROM passport_claims WHERE passport_hash=?").bind(v.passport_hash).first();
      const mine = await db.prepare("SELECT 1 AS x FROM passport_claims WHERE owner=?").bind(v.owner).first();
      if (other || mine) {
        await db.batch([
          db.prepare("INSERT INTO dup_attempts(passport_hash,owner,existing_owner,created_at) VALUES(?,?,?,?)").bind(v.passport_hash, v.owner, other ? other.owner : v.owner, now),
          db.prepare("UPDATE verifications SET status='rejected',decided_by=?,decided_at=?,updated_at=?,reject_reason=? WHERE id=?").bind(String(actor), now, now, "Pasport boshqa akkauntga bog'langan", v.id),
        ]);
        await vAudit(env, actor, "approve_blocked_dup", v.id, v.owner);
        await vNotifyUser(env, v.owner, "❌ Verifikatsiya rad etildi: bu hujjat bilan tasdiqlash mumkin emas.");
        return { ok: false, error: "duplicate" };
      }
      throw e;
    }
    await vNotifyUser(env, v.owner, "✅ Tabriklaymiz! Verifikatsiyangiz tasdiqlandi. Profilingizda rasmiy belgi paydo bo'ldi.");
    return { ok: true, status: "approved" };
  }
  const st = action === "need_info" ? "need_info" : "rejected";
  const r = await db.prepare("UPDATE verifications SET status=?,decided_by=?,decided_at=?,updated_at=?,reject_reason=? WHERE id=? AND status IN ('pending','need_info')")
    .bind(st, String(actor), st === "rejected" ? now : null, now, rs || null, v.id).run();
  if (!r.meta.changes) return { ok: false, error: "decided" };
  await vAudit(env, actor, st, v.id, rs);
  await vNotifyUser(env, v.owner, st === "rejected" ? "❌ Verifikatsiya rad etildi." + (rs ? "\nSabab: " + rs : "") + "\nQayta yuborishingiz mumkin." : "📝 Verifikatsiya uchun qo'shimcha ma'lumot kerak." + (rs ? "\n" + rs : "") + "\nSaytda hujjatni qayta yuboring.");
  return { ok: true, status: st };
}

// ---------- ADMIN BOT (alohida bot) ----------
async function vAdminLink(env, request, adminId, vid) {
  const code = randomId(32);
  await env.PRODUCTS.put("adm:c:" + code, JSON.stringify({ tg: String(adminId) }), { expirationTtl: 600 });
  return new URL(request.url).origin + "/admin?c=" + code + (vid ? "&v=" + vid : "");
}
async function handleVerifyWebhook(request, env) {
  if (request.headers.get("X-Telegram-Bot-Api-Secret-Token") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
  return vHandleUpdate(request, env, await request.json());
}
// Mavjud admin botning webhooki shu yerga "vv:" tugmalari va /panel, /pending buyruqlarini uzatadi
const vIsMine = (u) => !!((u.callback_query && String(u.callback_query.data || "").startsWith("vv:")) || (u.message && /^\/(panel|pending|verif)/.test(String(u.message.text || ""))));
async function vHandleUpdate(request, env, u) {
  if (!vReady(env)) return new Response("ok");
  const cq = u.callback_query, msg = u.message;
  if (cq) {
    const from = cq.from, ans = (t) => vtg(env, "answerCallbackQuery", { callback_query_id: cq.id, text: t, show_alert: true });
    if (!vIsAdmin(env, from.id)) { await vAudit(env, from.id, "admin_denied", cq.data, ""); await ans("Ruxsat yo'q"); return new Response("ok"); }
    const q = String(cq.data || "").split(":"), id = Number(q[2]);
    if (q[0] !== "vv" || !id) { await ans("?"); return new Response("ok"); }
    if (q[1] === "p") {
      await vtg(env, "answerCallbackQuery", { callback_query_id: cq.id });
      const link = await vAdminLink(env, request, from.id, id);
      await vtg(env, "sendMessage", { chat_id: from.id, text: "🔐 Xavfsiz sahifa (10 daqiqa, bir marta ishlaydi). Pasport faqat shu yerda ko'rinadi:", reply_markup: { inline_keyboard: [[{ text: "🔍 Pasportni ochish", url: link }]] } });
    } else if (q[1] === "u") {
      const v = await env.DB.prepare("SELECT * FROM verifications WHERE id=?").bind(id).first();
      if (!v) return (await ans("Topilmadi"), new Response("ok"));
      const b = await vBadgeFor(env, v.owner, await vBadgeCfg(env), null);
      await vtg(env, "answerCallbackQuery", { callback_query_id: cq.id });
      await vtg(env, "sendMessage", { chat_id: from.id, text: "👤 Profil\nID: " + v.owner + "\nIsm: " + v.name + "\nTelegram ID: " + (v.tg_id || "—") + "\nBuyurtmalar (hisobga olingan): " + b.orders + "\nBadge: " + (b.tier ? b.tier.name : "—") + "\nRasmiy verifikatsiya: " + (b.verified ? "bor" : "yo'q") + "\nSo'rov holati: " + V_STATUS[v.status] });
    } else if (q[1] === "a" || q[1] === "r") {
      const r = await vDecide(env, id, q[1] === "a" ? "approve" : "reject", from.id, q[1] === "r" ? "Admin rad etdi" : "");
      const t = r.ok ? (r.status === "approved" ? "✅ Tasdiqlandi" : "❌ Rad etildi") : r.error === "notviewed" ? "Avval «Pasportni tekshirish» orqali hujjatni ko'ring." : r.error === "decided" ? "Bu so'rov allaqachon hal qilingan." : r.error === "duplicate" ? "⚠️ Pasport boshqa akkauntga bog'langan. So'rov rad etildi." : "Xatolik";
      await ans(t);
      if (r.ok || r.error === "decided" || r.error === "duplicate") await vtg(env, "editMessageReplyMarkup", { chat_id: cq.message.chat.id, message_id: cq.message.message_id, reply_markup: { inline_keyboard: [[btn(r.ok ? t : "Hal qilingan", "vv:n:" + id)]] } });
    } else if (q[1] === "d") {
      await env.DB.prepare("DELETE FROM reviews WHERE id=?").bind(id).run();
      try { await env.PRODUCTS.delete("rc:" + id); } catch (e) { /* izohlar */ }
      await vAudit(env, from.id, "review_del", id, "telegram");
      await ans("🗑 Sharh o'chirildi");
      await vtg(env, "editMessageReplyMarkup", { chat_id: cq.message.chat.id, message_id: cq.message.message_id, reply_markup: { inline_keyboard: [[btn("🗑 O'chirilgan", "vv:n:" + id)]] } });
    } else await ans("—");
    return new Response("ok");
  }
  if (msg && msg.from && msg.text) {
    if (!vIsAdmin(env, msg.from.id)) { await vtg(env, "sendMessage", { chat_id: msg.chat.id, text: "Bu bot faqat administratorlar uchun." }); return new Response("ok"); }
    if (/^\/(start|panel)/.test(msg.text)) {
      const link = await vAdminLink(env, request, msg.from.id, 0);
      await vtg(env, "sendMessage", { chat_id: msg.chat.id, text: "Admin panel (10 daqiqalik bir martalik havola):", reply_markup: { inline_keyboard: [[{ text: "🔐 Panelni ochish", url: link }]] } });
    }
    if (/^\/pending/.test(msg.text)) {
      const rs = await env.DB.prepare("SELECT id,name,created_at FROM verifications WHERE status='pending' ORDER BY id LIMIT 20").all();
      const rows = (rs.results || []).map((r) => [btn("#" + r.id + " " + r.name + " · " + dt(r.created_at), "vv:p:" + r.id)]);
      await vtg(env, "sendMessage", Object.assign({ chat_id: msg.chat.id, text: rows.length ? "Kutilayotgan so'rovlar:" : "Kutilayotgan so'rov yo'q." }, rows.length ? { reply_markup: { inline_keyboard: rows } } : {}));
    }
  }
  return new Response("ok");
}

// ---------- MIJOZ BOTI: /verify buyrug'i (mavjud login funksiyasiga tegmaydi) ----------
async function vCustomerCmd(env, msg) {
  const t = String(msg.text || "").trim().toLowerCase();
  if (!(t === "/verify" || t === "/menu" || t === "🪪 verifikatsiya")) return false;
  const owner = "t" + msg.from.id;
  let st = "none", why = "";
  if (env.DB) { const v = await env.DB.prepare("SELECT status,reject_reason FROM verifications WHERE owner=? ORDER BY id DESC LIMIT 1").bind(owner).first(); if (v) { st = v.status; why = v.reject_reason || ""; } }
  const linked = await env.PRODUCTS.get("tgp:" + msg.from.id);
  await csay(env, msg.chat.id, "🪪 Verifikatsiya holati: " + V_STATUS[st] + (why ? "\nSabab: " + why : "") + (linked ? "" : "\n\nAkkaunt hali saytga ulanmagan: saytda 'Telegram orqali kirish' ni bosing."), {
    reply_markup: { inline_keyboard: [[{ text: st === "approved" ? "👤 Profilga o'tish" : "🪪 Verifikatsiyadan o'tish", url: vSite(env) + "?verify=1" }]] },
  });
  return true;
}

// ---------- ADMIN VEB API ----------
async function vAdminAuth(request, env) {
  const tok = (request.headers.get("X-Admin") || "").replace(/[^a-z0-9]/g, "");
  if (!tok) return null;
  const s = await env.PRODUCTS.get("adm:s:" + tok, "json");
  return s && vIsAdmin(env, s.tg) ? s : null; // har so'rovda admin huquqi qayta tekshiriladi
}
const vRows = async (p) => (await p.all()).results || [];
async function vAdminApi(request, env, url) {
  const path = url.pathname, db = env.DB, a = await vAdminAuth(request, env);
  if (!a) return json({ ok: false, error: "auth" }, 401, "*");
  const O = "*", q = url.searchParams;
  if (path === "/admin/api/list") {
    const t = q.get("t");
    if (t === "pending") return json({ ok: true, rows: await vRows(db.prepare("SELECT id,owner,name,tg_id,status,created_at FROM verifications WHERE status IN ('pending','need_info') ORDER BY id DESC LIMIT 100")) }, 200, O);
    if (t === "decided") return json({ ok: true, rows: await vRows(db.prepare("SELECT id,owner,name,status,decided_by,decided_at,reject_reason FROM verifications WHERE status IN ('approved','rejected') ORDER BY decided_at DESC LIMIT 100")) }, 200, O);
    if (t === "dups") return json({ ok: true, rows: await vRows(db.prepare("SELECT id,owner,existing_owner,created_at FROM dup_attempts ORDER BY id DESC LIMIT 100")) }, 200, O);
    if (t === "audit") return json({ ok: true, rows: await vRows(db.prepare("SELECT id,actor,action,target,detail,created_at FROM audit_log ORDER BY id DESC LIMIT 150")) }, 200, O);
    if (t === "users" || t === "tglinked") {
      const acc = await getAcc(env), ver = new Set((await vRows(db.prepare("SELECT owner FROM verified_users"))).map((r) => r.owner));
      const orders = await getOrdersMemo(env), cnt = {};
      orders.forEach((o) => { const k = o.tg ? "t" + o.tg : o.g ? "g" + o.g : ""; if (k && vCountable(o)) cnt[k] = (cnt[k] || 0) + 1; });
      const rows = acc.filter((r) => t === "users" || r.p === "t").slice(0, 300).map((r) => ({ k: r.k, name: accName(r), p: r.p, tg: r.p === "t" ? r.id : "", phone: r.phone || "", orders: cnt[r.k] || 0, verified: ver.has(r.k) }));
      return json({ ok: true, rows: rows }, 200, O);
    }
    if (t === "orders") return json({ ok: true, rows: (await getOrdersMemo(env)).slice(0, 100).map((o) => ({ id: o.id, name: o.name, phone: o.phone, total: o.total, status: o.status, t: o.t, owner: o.tg ? "t" + o.tg : o.g ? "g" + o.g : "" })) }, 200, O);
    if (t === "reviews") return json({ ok: true, rows: await vRows(db.prepare("SELECT id,name,rating,text,oid,reply,created_at FROM reviews ORDER BY id DESC LIMIT 100")) }, 200, O);
    return json({ ok: false, error: "type" }, 400, O);
  }
  if (path === "/admin/api/v") {
    const v = await db.prepare("SELECT id,owner,tg_id,name,status,created_at,updated_at,decided_by,decided_at,reject_reason,viewed_by,num_enc,purged_at FROM verifications WHERE id=?").bind(Number(q.get("id"))).first();
    if (!v) return json({ ok: false, error: "notfound" }, 404, O);
    let number = "";
    if (v.num_enc) { try { number = new TextDecoder().decode(await vDec(env, v.num_enc)); } catch (e) { number = ""; } }
    delete v.num_enc;
    const f = await db.prepare("SELECT 1 AS x FROM verification_files WHERE vid=?").bind(v.id).first();
    await db.prepare("UPDATE verifications SET viewed_by=?,viewed_at=? WHERE id=?").bind(a.tg, Date.now(), v.id).run();
    await vAudit(env, a.tg, "view_passport", v.id, "");
    const b = await vBadgeFor(env, v.owner, await vBadgeCfg(env), null);
    return json({ ok: true, v: v, number: number, hasFile: !!f, orders: b.orders }, 200, O);
  }
  if (path === "/admin/api/file") {
    const id = Number(q.get("id")), f = await db.prepare("SELECT mime,data FROM verification_files WHERE vid=?").bind(id).first();
    if (!f) return new Response("yo'q", { status: 404 });
    await vAudit(env, a.tg, "open_file", id, "");
    return new Response(await vDec(env, f.data), { headers: { "Content-Type": f.mime, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
  }
  if (request.method !== "POST") return json({ ok: false }, 405, O);
  const b = (await readJson(request, 20000)) || {};
  if (path === "/admin/api/decide") {
    const act = ["approve", "reject", "need_info"].indexOf(b.action) >= 0 ? b.action : "";
    if (!act) return json({ ok: false, error: "action" }, 400, O);
    return json(await vDecide(env, Number(b.id), act, a.tg, b.reason), 200, O);
  }
  if (path === "/admin/api/purge") {
    const id = Number(b.id);
    await db.batch([db.prepare("DELETE FROM verification_files WHERE vid=?").bind(id), db.prepare("UPDATE verifications SET num_enc=NULL,purged_at=? WHERE id=?").bind(Date.now(), id)]);
    await vAudit(env, a.tg, "purge", id, "");
    return json({ ok: true }, 200, O);
  }
  if (path === "/admin/api/badges") {
    if (!b.tiers) return json({ ok: true, cfg: await vBadgeCfg(env) }, 200, O);
    const tiers = (Array.isArray(b.tiers) ? b.tiers : []).slice(0, 8).map((t) => ({ k: String(t.k || "").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 12), name: clean(t.name, 20), min: Math.max(1, Math.floor(Number(t.min) || 0)), color: /^#[0-9a-fA-F]{6}$/.test(t.color) ? t.color : "#888888" }));
    if (!tiers.length || tiers.some((t, i) => !t.k || !t.name || (i && t.min <= tiers[i - 1].min))) return json({ ok: false, error: "invalid" }, 400, O);
    await env.PRODUCTS.put("badgecfg", JSON.stringify({ tiers: tiers }));
    await vAudit(env, a.tg, "badge_cfg", "", tiers.map((t) => t.k + ":" + t.min).join(","));
    return json({ ok: true }, 200, O);
  }
  if (path === "/admin/api/review-reply") {
    await db.prepare("UPDATE reviews SET reply=?,reply_at=? WHERE id=?").bind(clean(b.text, 600) || null, Date.now(), Number(b.id)).run();
    await vAudit(env, a.tg, "review_reply", b.id, "");
    return json({ ok: true }, 200, O);
  }
  if (path === "/admin/api/review-del") {
    await db.prepare("DELETE FROM reviews WHERE id=?").bind(Number(b.id)).run();
    try { await env.PRODUCTS.delete("rc:" + Number(b.id)); } catch (e) { /* izohlar */ }
    await vAudit(env, a.tg, "review_del", b.id, "");
    return json({ ok: true }, 200, O);
  }
  return json({ ok: false, error: "route" }, 404, O);
}

// ---------- MIJOZ API: holat, badge, sharh ----------
async function vSess(env, token) { return getSession(env, String(token || "").replace(/[^a-z0-9]/g, "")); }
// Buyurtma "topshirildi" (mijozga berildi) bo'lganda xaridorga: tovarni baholash so'rovi (mavjud login bot + push)
async function vReviewAsk(env, o) {
  const owner = o.tg ? "t" + o.tg : o.g ? "g" + o.g : "";
  if (!owner || !env.DB) return;
  const pend = await vPending(env, owner);
  if (!pend.length) return;
  const text = "⭐ Buyurtma #" + o.id + " mijozga topshirildi, rahmat! Olgan tovaringizni baholang: yulduz, izoh va rasm qoldiring, buning uchun " + REVIEW_PCT + "% kupon sovg'a qilamiz 🎁";
  if (o.tg) { try { await csay(env, o.tg, text, { reply_markup: { inline_keyboard: [[{ text: "⭐ Tovarni baholash", url: vSite(env) + "?review=1" }]] } }); } catch (e) { /* bot bloklangan bo'lishi mumkin */ } }
  try { await pushTo(env, owner, { t: "review", title: "Sarbon", text: "Tovaringizni baholang va " + REVIEW_PCT + "% kupon oling 🎁", ts: Date.now() }); } catch (e) { /* push ixtiyoriy */ }
}
// Xaridor hali baholamagan, yetkazilgan tovarlar ro'yxati (yangi buyurtmalarda pid bor, eskilarida tovar nomi bo'yicha topiladi)
async function vPending(env, owner) {
  const orders = (await vOrdersOf(env, owner)).filter((o) => o.status === "topshirildi");
  if (!orders.length) return [];
  const done = new Set((await vRows(env.DB.prepare("SELECT pid FROM reviews WHERE owner IN (" + SQLIN(owner) + ")").bind(...OWS(owner)))).map((r) => r.pid));
  const prods = await getListPub(env), out = [], seen = new Set();
  for (const o of orders) {
    String(o.summary || "").split("\n").forEach((ln, i) => {
      const m = /^\d+\.\s+(.*?)(?:\s\([^)]*\))?\s+x\d+\s+\[/.exec(ln);
      if (!m) return;
      let pid = Array.isArray(o.pids) && o.pids[i] ? o.pids[i] : 0;
      if (!pid) { const p = prods.find((x) => x.n === m[1]); pid = p ? p.id : 0; }
      if (!pid || done.has(pid) || seen.has(pid)) return;
      seen.add(pid); out.push({ pid: pid, name: m[1], oid: String(o.id) });
    });
  }
  return out.slice(0, 10);
}
async function vFindOrder(env, owner, pid, pn) {
  const name = String(pn || "").toLowerCase().slice(0, 120);
  return (await vOrdersOf(env, owner)).find((o) => o.status === "topshirildi" && ((Array.isArray(o.pids) && o.pids.indexOf(pid) >= 0) || (name && String(o.summary || "").toLowerCase().indexOf(name) >= 0))) || null;
}
async function vBrief(env, cfg, orders, ver, owner) {
  const set = new Set(OWS(owner));
  const mine = orders.filter((o) => (o.tg && set.has("t" + o.tg)) || (o.g && set.has("g" + o.g)));
  const n = mine.filter(vCountable).length, un = cfg.tiers.filter((t) => n >= t.min);
  let pref = null;
  for (const o1 of OWS(owner)) { pref = await env.PRODUCTS.get("bpref:" + o1); if (pref) break; }
  const tier = un.find((t) => t.k === pref) || un[un.length - 1] || null;
  return { verified: OWS(owner).some((x) => ver.has(x)), tier: tier ? { k: tier.k, name: tier.name, color: tier.color } : null };
}
let _revOk = false;
const REV_COLS = { owner: "TEXT", oid: "TEXT", pid: "INTEGER", name: "TEXT", rating: "INTEGER", text: "TEXT", img: "TEXT", reply: "TEXT", reply_at: "INTEGER", created_at: "INTEGER" };
// sharhlar jadvalida yetishmayotgan ustunlarni o'zi qo'shadi; oxirida haqiqatan bor-yo'qligini tekshiradi
async function vEnsureReviews(env, force) {
  if ((_revOk && !force) || !env.DB) return;
  try {
    await env.DB.prepare("CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT, oid TEXT, pid INTEGER, name TEXT, rating INTEGER, text TEXT, img TEXT, reply TEXT, reply_at INTEGER, created_at INTEGER)").run();
  } catch (e) { /* jadval bor */ }
  const missing = async () => {
    const miss = [];
    for (const k of Object.keys(REV_COLS)) {
      try { await env.DB.prepare("SELECT " + k + " FROM reviews LIMIT 1").first(); } catch (e) { miss.push(k); }
    }
    return miss;
  };
  let miss = await missing();
  for (const k of miss) {
    try { await env.DB.prepare("ALTER TABLE reviews ADD COLUMN " + k + " " + REV_COLS[k]).run(); } catch (e) { /* pastda qayta tekshiramiz */ }
  }
  miss = miss.length ? await missing() : miss;
  if (miss.length) {
    // ustun qo'shib bo'lmadi: jadval bo'sh bo'lsa, qaytadan yaratamiz
    try {
      const c = await env.DB.prepare("SELECT COUNT(*) AS c FROM reviews").first();
      if (c && Number(c.c) === 0) {
        await env.DB.prepare("DROP TABLE reviews").run();
        await env.DB.prepare("CREATE TABLE reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT, oid TEXT, pid INTEGER, name TEXT, rating INTEGER, text TEXT, img TEXT, reply TEXT, reply_at INTEGER, created_at INTEGER)").run();
        miss = await missing();
      }
    } catch (e) { /* keyingi so'rovda qayta uriniladi */ }
  }
  _revOk = miss.length === 0;
}
async function vCustomerApi(request, env, url, origin) {
  const p = url.pathname;
  if (env.DB && (p === "/reviews" || p === "/review-img" || p.startsWith("/review/"))) await vEnsureReviews(env);
  if (request.method === "GET" && p === "/reviews") {
    if (!env.DB) return json({ ok: true, rows: [] }, 200, origin);
    const qpid = Math.floor(Number(url.searchParams.get("pid"))) || 0;
    const rows = await vRows(qpid ? env.DB.prepare("SELECT id,owner,oid,name,rating,text,(img IS NOT NULL) AS hasimg,reply,created_at FROM reviews WHERE pid=? ORDER BY id DESC LIMIT 50").bind(qpid) : env.DB.prepare("SELECT id,owner,oid,name,rating,text,(img IS NOT NULL) AS hasimg,reply,created_at FROM reviews ORDER BY id DESC LIMIT 50"));
    const agg = qpid ? await env.DB.prepare("SELECT COUNT(*) AS c, AVG(CASE WHEN rating>0 THEN rating END) AS a FROM reviews WHERE pid=?").bind(qpid).first() : null;
    const cfg = await vBadgeCfg(env), orders = await getOrdersMemo(env);
    const ver = new Set((await vRows(env.DB.prepare("SELECT owner FROM verified_users"))).map((r) => r.owner));
    const out = [], memo = {};
    const brief = async (owner) => memo[owner] || (memo[owner] = await vBrief(env, cfg, orders, ver, owner));
    for (const r of rows) {
      const bf = await brief(r.owner), raw = (await env.PRODUCTS.get("rc:" + r.id, "json")) || [], cms = [];
      for (const c of raw.slice(-30)) { const cb = await brief(c.o); cms.push({ n: c.n, t: c.t, ts: c.ts, verified: cb.verified, tier: cb.tier }); }
      out.push({ id: r.id, name: r.name, rating: r.rating, text: r.text, img: r.hasimg ? "/review-img?id=" + r.id : "", reply: r.reply || "", t: r.created_at, purchase: !!r.oid && r.oid !== "0" && String(r.oid).indexOf("nb:") !== 0, verified: bf.verified, tier: bf.tier, comments: cms });
    }
    return json({ ok: true, rows: out, count: agg ? agg.c : out.length, avg: agg && agg.c && agg.a ? Math.round(agg.a * 10) / 10 : 0 }, 200, origin, "public, max-age=20");
  }
  if (request.method === "GET" && p === "/review-img") {
    const r = await env.DB.prepare("SELECT img FROM reviews WHERE id=?").bind(Number(url.searchParams.get("id"))).first();
    const m = r && /^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(r.img || "");
    if (!m) return new Response("yo'q", { status: 404 });
    return new Response(vunb64(m[2]), { headers: { "Content-Type": m[1], "Cache-Control": "public, max-age=86400", "Access-Control-Allow-Origin": origin, "X-Content-Type-Options": "nosniff" } });
  }
  if (request.method !== "POST") return null;
  if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
  if (!env.DB) return json({ ok: false, error: "config" }, 503, origin);
  const body = await readJson(request, p === "/verify/submit" ? 1700000 : 600000);
  if (!body) return json({ ok: false, error: "json" }, 400, origin);
  if (p === "/verify/submit") return vSubmit(env, body, origin);
  const sess = await vSess(env, body.token);
  if (!sess) return json({ ok: false, error: "auth" }, 401, origin);
  const owner = ownerOf(sess), owners = ownersOf(sess);
  if (p === "/verify/status" || p === "/badge/me") {
    const v = await env.DB.prepare("SELECT id,status,reject_reason,created_at FROM verifications WHERE owner IN (" + SQLIN(owners) + ") ORDER BY id DESC LIMIT 1").bind(...owners).first();
    const cfg = await vBadgeCfg(env), b = await vBadgeFor(env, owners, cfg, null);
    return json({ ok: true, status: v ? v.status : "none", reason: v ? v.reject_reason || "" : "", id: v ? v.id : 0, verified: b.verified, orders: b.orders, tier: b.tier, tiers: cfg.tiers.map((t) => ({ k: t.k, name: t.name, min: t.min, color: t.color, unlocked: b.unlocked.indexOf(t.k) >= 0 })) }, 200, origin);
  }
  if (p === "/badge/choose") {
    const b = await vBadgeFor(env, owners, await vBadgeCfg(env), null), k = String(body.tier || "");
    if (k && b.unlocked.indexOf(k) < 0) return json({ ok: false, error: "locked" }, 403, origin); // faqat ochilgan dizaynni tanlash mumkin
    for (const o1 of owners) { if (o1 !== owner) await env.PRODUCTS.delete("bpref:" + o1); }
    await env.PRODUCTS.put("bpref:" + owner, k);
    return json({ ok: true }, 200, origin);
  }
  if (p === "/review/pending") return json({ ok: true, rows: await vPending(env, owners) }, 200, origin);
  if (p === "/review/eligible") {
    const pid = Math.floor(Number(body.pid)) || 0;
    if (!pid) return json({ ok: false, error: "pid" }, 400, origin);
    const done = await env.DB.prepare("SELECT 1 AS x FROM reviews WHERE owner IN (" + SQLIN(owners) + ") AND pid=?").bind(...owners, pid).first();
    const o = await vFindOrder(env, owners, pid, body.pn);
    if (done) return json({ ok: true, can: true, mine: true, bought: !!o, reason: "" }, 200, origin);
    return json({ ok: true, can: true, bought: !!o, reason: "" }, 200, origin); // hamma yoza oladi; sotib olganlarga belgi chiqadi
  }
  if (p === "/review/comment") {
    const rid = Math.floor(Number(body.rid)) || 0, text = clean(body.text, 400).trim();
    if (!rid || !text) return json({ ok: false, error: "text" }, 400, origin);
    const ex = await env.DB.prepare("SELECT 1 AS x FROM reviews WHERE id=?").bind(rid).first();
    if (!ex) return json({ ok: false, error: "nf" }, 404, origin);
    const key = "rc:" + rid, arr = (await env.PRODUCTS.get(key, "json")) || [];
    if (arr.length >= 60 || arr.filter((c) => c.o === owner).length >= 5) return json({ ok: false, error: "limit" }, 429, origin);
    const c = { o: owner, n: vMask(sess.name), t: text, ts: Date.now() };
    arr.push(c);
    await env.PRODUCTS.put(key, JSON.stringify(arr));
    const ver = new Set((await vRows(env.DB.prepare("SELECT owner FROM verified_users"))).map((r) => r.owner));
    const bf = await vBrief(env, await vBadgeCfg(env), await getOrdersMemo(env), ver, owners);
    return json({ ok: true, c: { n: c.n, t: c.t, ts: c.ts, verified: bf.verified, tier: bf.tier } }, 200, origin);
  }
  if (p === "/review/add") {
    const pid = Math.floor(Number(body.pid)) || 0, rating = Math.floor(Number(body.rating)) || 0;
    if (!pid) return json({ ok: false, error: "pid" }, 400, origin);
    if (!(rating >= 0 && rating <= 5)) return json({ ok: false, error: "rating" }, 400, origin);
    let o = null; try { o = await vFindOrder(env, owners, pid, body.pn); } catch (e) { o = null; } // sotib olgan bo'lsa belgi chiqadi, bo'lmasa ham yozish mumkin
    let img = null;
    if (body.image) {
      const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(body.image));
      if (!m || m[2].length > 420000) return json({ ok: false, error: "image" }, 400, origin);
      let u8; try { u8 = vunb64(m[2]); } catch (e) { return json({ ok: false, error: "image" }, 400, origin); }
      if (!vImgOk(u8, m[1])) return json({ ok: false, error: "image" }, 400, origin);
      img = body.image;
    }
    const txt = clean(body.text, 800).trim();
    // Shu tovarga oldin yozgan bo'lsa: xato bermaymiz, sharhini yangilaymiz
    let dupRow = null;
    try { dupRow = await env.DB.prepare("SELECT id FROM reviews WHERE owner=? AND pid=?").bind(owner, pid).first(); } catch (e0) {
      try { await vEnsureReviews(env, true); dupRow = await env.DB.prepare("SELECT id FROM reviews WHERE owner=? AND pid=?").bind(owner, pid).first(); } catch (e) { return json({ ok: false, error: "db", detail: String(e && e.message || e).slice(0, 200) }, 500, origin); } }
    if (dupRow) {
      try {
        if (img) await env.DB.prepare("UPDATE reviews SET name=?,rating=?,text=?,img=?,created_at=? WHERE id=?").bind(vMask(sess.name), rating, txt || "–", img, Date.now(), dupRow.id).run();
        else await env.DB.prepare("UPDATE reviews SET name=?,rating=?,text=?,created_at=? WHERE id=?").bind(vMask(sess.name), rating, txt || "–", Date.now(), dupRow.id).run();
      } catch (e) { return json({ ok: false, error: "db", detail: String(e && e.message || e).slice(0, 200) }, 500, origin); }
      return json({ ok: true, updated: true, coupon: null }, 200, origin);
    }
    // matn ixtiyoriy; jadval cheklovlariga qarab bir necha variant bilan saqlab ko'ramiz
    const oids = o ? [String(o.id)] : ["", "nb:" + pid, "0"], txts = txt ? [txt] : ["", "–"];
    let rid = 0, lastErr = null;
    outer: for (const oidv of oids) {
      for (const tv of txts) {
        try {
          const ins = await env.DB.prepare("INSERT INTO reviews(owner,oid,pid,name,rating,text,img,created_at) VALUES(?,?,?,?,?,?,?,?)").bind(owner, oidv, pid, vMask(sess.name), rating, tv, img, Date.now()).run();
          rid = Number(ins && ins.meta && ins.meta.last_row_id) || 0;
          lastErr = null; break outer;
        } catch (e) { lastErr = e; }
      }
    }
    if (lastErr) return json({ ok: false, error: "db", detail: String(lastErr && lastErr.message || lastErr).slice(0, 200) }, 500, origin);
    // sovg'a kupon: bir buyurtma uchun faqat bir marta (bitta buyurtmadagi ko'p tovar bilan kupon yig'ib bo'lmaydi)
    let coupon = null;
    if (o) try {
      const ck = "rvc:" + o.id;
      if (!(await env.PRODUCTS.get(ck))) {
        await env.PRODUCTS.put(ck, "1");
        const code = await addCoupon(env, owner, "review", REVIEW_PCT);
        coupon = { code: code, pct: REVIEW_PCT };
        if (o.tg) { try { await csay(env, o.tg, "🎁 Sharh uchun rahmat! Sovg'a kuponingiz: " + code + " (" + REVIEW_PCT + "%, bir martalik). Savatda avtomatik chiqadi."); } catch (e) { /* bot bloklangan bo'lishi mumkin */ } }
      }
    } catch (e) { /* kupon berilmasa ham sharh saqlangan */ }
    try { await vNotifyAdmins(env, "⭐ Yangi sharh: " + (rating ? rating + "/5" : "bahosiz") + " — " + vMask(sess.name) + " (tovar #" + pid + (o ? ", buyurtma #" + o.id : ", sotib olmagan") + ")" + (clean(body.text, 200) ? "\n\n" + clean(body.text, 200) : ""), rid ? { inline_keyboard: [[btn("🗑 O'chirish", "vv:d:" + rid)]] } : null); } catch (e) { /* admin xabari xato bersa ham sharh saqlangan */ }
    return json({ ok: true, coupon: coupon }, 200, origin);
  }
  return json({ ok: false, error: "route" }, 404, origin);
}


// ---------- MAHSULOTLARNI OMMAVIY IMPORT (Excel/CSV) ----------
const IMPORT_HTML = "<!doctype html><html lang=\"uz\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"robots\" content=\"noindex\"><title>Mahsulot import</title>\n<style>\n:root{--bg:#f4f5fb;--c:#fff;--t:#1B1D45;--m:#6b6f93;--p:#25308F;--ok:#1a8f4a;--er:#c62828;--wa:#b26a00}\n@media(prefers-color-scheme:dark){:root{--bg:#0B0D22;--c:#161938;--t:#eef0ff;--m:#9ba0cc;--p:#8f9bff}}\n*{box-sizing:border-box}body{margin:0;font:15px/1.45 system-ui,sans-serif;background:var(--bg);color:var(--t);padding:14px}\n.c{background:var(--c);border-radius:14px;padding:14px;margin:0 0 12px;box-shadow:0 2px 10px rgba(0,0,0,.06)}\nh1{font-size:19px;margin:0 0 10px}h2{font-size:16px;margin:0 0 8px}a{color:var(--p)}\nbutton,select,input[type=file]{font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--m);background:var(--c);color:var(--t);max-width:100%}\nbutton.p{background:var(--p);color:#fff;border:0;font-weight:600}button:disabled{opacity:.5}\n.m{color:var(--m);font-size:13px}.ok{color:var(--ok)}.er{color:var(--er)}.wa{color:var(--wa)}\n.w{overflow-x:auto}table{border-collapse:collapse;font-size:12.5px;min-width:100%}td,th{border-bottom:1px solid rgba(128,128,160,.25);padding:5px 7px;text-align:left;white-space:nowrap;max-width:200px;overflow:hidden;text-overflow:ellipsis}\n.bar{height:10px;background:rgba(128,128,160,.25);border-radius:6px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:var(--p);transition:width .3s}\n.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}\n</style></head><body>\n<div class=\"c\"><h1>📥 Mahsulotlarni Excel/CSV orqali yuklash</h1><a href=\"/admin\">← Admin panelga qaytish</a>\n<p class=\"m\">1) Shablonni yuklab oling va to'ldiring. 2) Faylni tanlang. 3) Tekshiruvdan keyin «Yuklash» ni bosing.<br>Narx so'mda. Rasmlar: to'g'ridan-to'g'ri rasm havolasi (https://...jpg), bir nechta bo'lsa <b>;</b> bilan ajrating (eng ko'pi 3 ta).<br>Kategoriyalar: <b>gadjet, kompyuter, bolalar, kiyim, uy, gozal, sport, avto</b>. Ombor 0 bo'lsa, tovar saytda yashiriladi.</p>\n<div class=\"row\"><button id=\"tpl\">⬇️ Shablon (CSV)</button><input type=\"file\" id=\"f\" accept=\".csv,.xlsx,.xls\"></div></div>\n<div class=\"c\" id=\"pv\" style=\"display:none\"><h2>Tekshiruv</h2><div id=\"sum\" class=\"m\"></div><div class=\"w\" id=\"tb\"></div>\n<div class=\"row\" style=\"margin-top:10px\"><label>Dublikat bo'lsa: <select id=\"mode\"><option value=\"skip\">O'tkazib yuborish</option><option value=\"update\">Yangilash</option></select></label><button class=\"p\" id=\"go\">Yuklash</button></div></div>\n<div class=\"c\" id=\"pg\" style=\"display:none\"><h2 id=\"pt\">Yuklanmoqda…</h2><div class=\"bar\"><i id=\"pb\"></i></div><div id=\"lg\" class=\"m\" style=\"margin-top:8px\"></div></div>\n<script src=\"https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js\"></script>\n<script>\nvar TOK=sessionStorage.getItem(\"adm\"),ROWS=[],CATS=[\"gadjet\",\"kompyuter\",\"bolalar\",\"kiyim\",\"uy\",\"gozal\",\"sport\",\"avto\"];\nvar COLS={name:[\"nom\",\"name\",\"nomi\",\"tovar\",\"mahsulot\"],cat:[\"kategoriya\",\"category\",\"kat\"],price:[\"narx\",\"price\",\"narxi\"],kg:[\"vazn\",\"vazn_kg\",\"kg\",\"weight\"],colors:[\"ranglar\",\"rang\",\"colors\",\"color\"],sizes:[\"olchamlar\",\"olcham\",\"o'lchamlar\",\"sizes\",\"size\"],stock:[\"ombor\",\"soni\",\"stock\",\"qty\",\"miqdor\"],desc:[\"tavsif\",\"description\",\"desc\",\"izoh\"],images:[\"rasmlar\",\"rasm\",\"images\",\"image\",\"foto\"]};\nfunction E(s){var d=document.createElement(\"div\");d.textContent=s==null?\"\":String(s);return d.innerHTML}\nfunction $(i){return document.getElementById(i)}\nif(!TOK){document.body.insertAdjacentHTML(\"afterbegin\",'<div class=\"c er\">Kirish topilmadi. Avval <a href=\"/admin\">admin panelga</a> bot havolasi orqali kiring, keyin shu sahifani panel ichidagi havola orqali oching.</div>')}\n$(\"tpl\").onclick=function(){var t=\"nom,kategoriya,narx,vazn_kg,ranglar,olchamlar,ombor,tavsif,rasmlar\\n\\\"Simsiz quloqchin A1\\\",gadjet,189000,0.2,\\\"Qora;Oq\\\",,25,\\\"Bluetooth 5.3, 24 soat batareya\\\",https://example.com/rasm1.jpg;https://example.com/rasm2.jpg\\n\\\"Bolalar futbolkasi\\\",kiyim,59000,0.15,\\\"Qizil;Ko'k\\\",\\\"S;M;L;XL\\\",100,\\\"Paxta 100%\\\",https://example.com/futbolka.jpg\\n\";\nvar b=new Blob([\"\\ufeff\"+t],{type:\"text/csv\"}),a=document.createElement(\"a\");a.href=URL.createObjectURL(b);a.download=\"sarbon-shablon.csv\";a.click()};\nfunction norm(h){return String(h||\"\").toLowerCase().replace(/[\\s]+/g,\"_\").replace(/[‘’`ʻʼ]/g,\"'\").trim()}\nfunction pick(o,names){for(var k in o){var n=norm(k);for(var i=0;i<names.length;i++){if(n===names[i].replace(/\\s/g,\"_\"))return o[k]}}return \"\"}\n$(\"f\").onchange=function(){var f=this.files[0];if(!f)return;var rd=new FileReader();rd.onload=function(){\n try{var wb=XLSX.read(rd.result,{type:\"array\",codepage:65001});var ws=wb.Sheets[wb.SheetNames[0]];var js=XLSX.utils.sheet_to_json(ws,{defval:\"\",raw:false});build(js)}catch(e){alert(\"Faylni o'qib bo'lmadi: \"+e.message)}};rd.readAsArrayBuffer(f)};\nfunction build(js){ROWS=[];var seen={},bad=0,dup=0;\n js.forEach(function(o,i){var r={line:i+2};for(var k in COLS)r[k]=String(pick(o,COLS[k])).trim();\n  if(!r.name&&!r.price&&!r.cat)return;\n  var er=[];if(r.name.length<2)er.push(\"nom yo'q\");\n  var pr=Number(r.price.replace(/[\\s,]/g,\"\"));if(!(pr>=1000))er.push(\"narx noto'g'ri\");\n  if(r.cat&&CATS.indexOf(r.cat.toLowerCase())<0&&!/^(gadjet|kompyuter|bolalar|kiyim|uy|go'zallik|gozal|sport|avto|uy-ro'zg'or)/i.test(r.cat))er.push(\"kategoriya noto'g'ri\");\n  var k2=r.name.toLowerCase().replace(/\\s+/g,\" \");if(seen[k2]){r.dup=1;dup++}seen[k2]=1;\n  r.er=er.join(\", \");if(er.length)bad++;ROWS.push(r)});\n $(\"pv\").style.display=\"\";$(\"sum\").innerHTML=\"Jami: <b>\"+ROWS.length+\"</b> qator. Xatoli: <b class=\\\"er\\\">\"+bad+\"</b>. Fayl ichida takror nom: <b class=\\\"wa\\\">\"+dup+\"</b>.\";\n var h=\"<table><tr><th>#</th><th>Nom</th><th>Kat.</th><th>Narx</th><th>Rang</th><th>O'lcham</th><th>Ombor</th><th>Rasm</th><th>Holat</th></tr>\";\n ROWS.slice(0,200).forEach(function(r){h+=\"<tr><td>\"+r.line+\"</td><td>\"+E(r.name)+\"</td><td>\"+E(r.cat)+\"</td><td>\"+E(r.price)+\"</td><td>\"+E(r.colors)+\"</td><td>\"+E(r.sizes)+\"</td><td>\"+E(r.stock)+\"</td><td>\"+(r.images?r.images.split(/[;|\\s]+/).filter(Boolean).length:0)+\"</td><td class=\\\"\"+(r.er?\"er\":r.dup?\"wa\":\"ok\")+\"\\\">\"+(r.er||(r.dup?\"takror\":\"OK\"))+\"</td></tr>\"});\n $(\"tb\").innerHTML=h+\"</table>\"+(ROWS.length>200?'<p class=\"m\">Faqat birinchi 200 qator ko\\'rsatildi, hammasi yuklanadi.</p>':\"\");\n $(\"go\").disabled=!ROWS.length}\nfunction api(b){return fetch(\"/admin/api/import\",{method:\"POST\",headers:{\"X-Admin\":TOK,\"Content-Type\":\"application/json\"},body:JSON.stringify(b)}).then(function(r){return r.json().then(function(j){j._s=r.status;return j})})}\n$(\"go\").onclick=function(){if(!TOK||!ROWS.length)return;var good=ROWS.filter(function(r){return!r.er});if(!good.length){alert(\"Yuklash uchun to'g'ri qator yo'q\");return}\n if(!confirm(good.length+\" ta qator yuklansinmi?\"))return;\n $(\"go\").disabled=true;$(\"pg\").style.display=\"\";var mode=$(\"mode\").value,i=0,N=6,c=0,u=0,s=0,e=0,lg=[];\n function step(){if(i>=good.length){$(\"pt\").textContent=\"Tayyor ✅\";$(\"pb\").style.width=\"100%\";\n   lg.unshift(\"<b>Yangi: \"+c+\" · Yangilandi: \"+u+\" · O'tkazildi: \"+s+\" · Xato: \"+e+\"</b>\");$(\"lg\").innerHTML=lg.join(\"<br>\");$(\"go\").disabled=false;return}\n  var ch=good.slice(i,i+N);$(\"pt\").textContent=\"Yuklanmoqda… \"+Math.min(i+N,good.length)+\" / \"+good.length;\n  api({rows:ch,mode:mode}).then(function(j){\n   if(j._s===401){$(\"pt\").textContent=\"Kirish tugagan\";lg.push('<span class=\"er\">Admin panelga qayta kiring: <a href=\"/admin\">/admin</a></span>');$(\"lg\").innerHTML=lg.join(\"<br>\");return}\n   if(!j.ok){e+=ch.length;lg.push('<span class=\"er\">Server xatosi: '+E(j.error||j._s)+\"</span>\")}\n   else{c+=j.created;u+=j.updated;s+=j.skipped;e+=j.errors;j.results.forEach(function(x){if(x.s!==\"yangi\"&&x.s!==\"yangilandi\"||x.m)lg.push('<span class=\"'+(x.s===\"xato\"?\"er\":\"wa\")+'\">Qator '+x.line+\": \"+E(x.s)+(x.m?\" — \"+E(x.m):\"\")+\"</span>\")})}\n   i+=N;$(\"pb\").style.width=Math.round(Math.min(i,good.length)/good.length*100)+\"%\";$(\"lg\").innerHTML=lg.slice(-40).join(\"<br>\");setTimeout(step,1100)}).catch(function(){e+=ch.length;lg.push('<span class=\"er\">Tarmoq xatosi (qator '+ch[0].line+\")</span>\");i+=N;setTimeout(step,1500)})}\n step()};\n</script></body></html>\n";
const impKey = (s) => String(s || "").toLowerCase().replace(/\s+/g, " ").trim();
const impList = (s, max, len) => Array.from(new Set(String(s || "").split(/[;,|]/).map((x) => clean(x, len).trim()).filter(Boolean))).slice(0, max);
function impCat(v) {
  const t = impKey(v).replace(/[‘’`ʻʼ]/g, "'");
  if (!t) return "";
  const f = CATEGORIES.find((c) => c[0] === t || impKey(c[1]).replace(/[‘’`ʻʼ]/g, "'") === t);
  if (f) return f[0];
  const alias = { "go'zallik": "gozal", "uy-ro'zg'or": "uy", "uy rozgor": "uy" };
  return alias[t] || "";
}
async function handleImport(request, env) {
  const a = await vAdminAuth(request, env);
  if (!a) return json({ ok: false, error: "auth" }, 401, "*");
  const body = await readJson(request, 400000);
  if (!body) return json({ ok: false, error: "json" }, 400, "*");
  const rows = (Array.isArray(body.rows) ? body.rows : []).slice(0, 8), mode = body.mode === "update" ? "update" : "skip";
  const items = await getList(env), byName = new Map(items.map((p) => [impKey(p.n), p]));
  let nid = items.reduce((m, p) => Math.max(m, p.id), 0) + 1, imgBudget = 14, changed = false;
  const res = []; let created = 0, updated = 0, skipped = 0, errors = 0;
  for (const r of rows) {
    const line = Number(r && r.line) || 0;
    try {
      const name = clean(r.name, 120).trim();
      if (name.length < 2) { res.push({ line: line, s: "xato", m: "Nom yo'q" }); errors++; continue; }
      const price = Math.round(Number(String(r.price || "").replace(/[\s,]/g, "")));
      if (!(price >= 1000 && price <= 500000000)) { res.push({ line: line, s: "xato", m: "Narx noto'g'ri" }); errors++; continue; }
      const old = byName.get(impKey(name));
      if (old && mode === "skip") { res.push({ line: line, s: "o'tkazildi", m: "Dublikat" }); skipped++; continue; }
      const cat = impCat(r.cat);
      if (r.cat && !cat) { res.push({ line: line, s: "xato", m: "Kategoriya noto'g'ri" }); errors++; continue; }
      if (!old && !cat) { res.push({ line: line, s: "xato", m: "Kategoriya yo'q" }); errors++; continue; }
      let kg = Number(String(r.kg || "").replace(",", "."));
      kg = kg > 0 && kg <= 50 ? kg : 0;
      const colors = impList(r.colors, 12, 30), sizes = impList(r.sizes, 20, 20), desc = clean(r.desc, 1500).trim();
      const stockRaw = String(r.stock == null ? "" : r.stock).replace(/\s/g, "");
      const stock = stockRaw !== "" && /^\d{1,6}$/.test(stockRaw) ? Number(stockRaw) : null;
      const urls = String(r.images || "").split(/[;|\s]+/).filter((u) => /^https:\/\/[^\s"'<>]{4,500}$/i.test(u)).slice(0, 3);
      const media = [], warn = [];
      for (const u of urls) {
        if (imgBudget <= 0) { warn.push("rasm limiti (keyingi yuklashda qayta yuboring)"); break; }
        imgBudget--;
        const sp = await tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: u, disable_notification: true });
        if (sp && sp.ok && sp.result && Array.isArray(sp.result.photo) && sp.result.photo.length) {
          media.push({ f: sp.result.photo[sp.result.photo.length - 1].file_id, t: "i" });
          try { await tg(env, "deleteMessage", { chat_id: env.CHAT_ID, message_id: sp.result.message_id }); } catch (e) { /* tozalash ixtiyoriy */ }
        } else warn.push("rasm yuklanmadi");
      }
      if (old) {
        old.som = price; if (cat) old.c = cat; if (kg) old.kg = kg;
        if (sizes.length) old.olcham = sizes;
        if (colors.length) old.colors = colors.map((n) => ({ n: n, media: ((old.colors || []).find((c) => c.n === n) || {}).media || [] }));
        if (desc) old.d = desc;
        if (stock !== null) { old.st = stock; old.hidden = stock === 0; }
        if (media.length) old.media = media;
        norm(old); changed = true; updated++;
        res.push({ line: line, s: "yangilandi", m: warn.join(", ") });
      } else {
        const id = nid++;
        const p = norm({ id: id, n: name, som: price, y: 0, kg: kg || 0.5, c: cat, olcham: sizes, colors: colors.map((n) => ({ n: n, media: [] })), rang: [], av: false, b: BG[id % BG.length], s: 0, hidden: stock === 0, draft: false, media: media, d: desc || undefined, st: stock === null ? undefined : stock });
        items.push(p); byName.set(impKey(name), p); changed = true; created++;
        res.push({ line: line, s: "yangi", m: warn.join(", ") });
      }
    } catch (e) { res.push({ line: line, s: "xato", m: "Ichki xato" }); errors++; }
  }
  if (changed) await saveList(env, items);
  try { if (env.DB) await vAudit(env, a.tg, "import", String(created + updated), "created=" + created + " updated=" + updated); } catch (e) { /* tarix ixtiyoriy */ }
  return json({ ok: true, results: res, created: created, updated: updated, skipped: skipped, errors: errors }, 200, "*");
}


// ---------- ADMIN API: Claude Code va admin "Tovarlar" sahifasi uchun ----------
const apiHash = async (s) => new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(s))));
async function apiAuth(request, env) {
  const h = request.headers.get("Authorization") || "", key = String(env.PRODUCT_API_KEY || "");
  if (key.length >= 24 && /^Bearer /i.test(h)) {
    const a = await apiHash(h.slice(7).trim()), b = await apiHash(key);
    let d = 0;
    for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
    if (d === 0) return { via: "key" };
  }
  const adm = await vAdminAuth(request, env);
  return adm ? { via: "admin", tg: adm.tg } : null;
}
const botName = (env) => memo("cbot", 600000, async () => { try { const me = await ctg(env, "getMe", {}); return me && me.ok ? me.result.username : ""; } catch (e) { return ""; } });
const apiView = (env, p, bot) => ({
  id: p.id, name: p.n, category: p.c, price: p.som > 0 ? p.som : null, kg: p.kg,
  colors: (p.colors || []).map((c) => ({ name: c.n, images: (c.media || []).filter((m) => m.t === "i").map((m) => m.f) })),
  sizes: p.olcham || [], stock: typeof p.st === "number" ? p.st : null, description: p.d || "",
  images: (p.media || []).filter((m) => m.t === "i").map((m) => m.f), hidden: !!p.hidden, draft: !!p.draft, sold: p.s || 0,
  link: vSite(env) + "?p=" + p.id, tgLink: bot ? "https://t.me/" + bot + "?start=p" + p.id : "",
});
async function tgPhotoFromUrl(env, u) {
  const sp = await tg(env, "sendPhoto", { chat_id: env.CHAT_ID, photo: u, disable_notification: true });
  if (sp && sp.ok && sp.result && Array.isArray(sp.result.photo) && sp.result.photo.length) {
    try { await tg(env, "deleteMessage", { chat_id: env.CHAT_ID, message_id: sp.result.message_id }); } catch (e) { /* tozalash ixtiyoriy */ }
    return sp.result.photo[sp.result.photo.length - 1].file_id;
  }
  return "";
}
async function apiImages(env, list, budget) {
  const media = [], warn = [];
  for (const s of (Array.isArray(list) ? list : []).slice(0, 12)) {
    const v = String(s || "").trim();
    if (/^https:\/\/[^\s"'<>]{4,500}$/i.test(v)) {
      if (budget.n <= 0) { warn.push("rasm limiti: qolganini keyingi so'rovda yuboring"); continue; }
      budget.n--;
      const f = await tgPhotoFromUrl(env, v);
      if (f) media.push({ f: f, t: "i" }); else warn.push("rasm yuklanmadi: " + v.slice(0, 60));
    } else if (/^[A-Za-z0-9_\-]{20,200}$/.test(v)) media.push({ f: v, t: "i" });
    else if (v) warn.push("noto'g'ri rasm: " + v.slice(0, 40));
  }
  return { media: media, warn: warn };
}
async function apiApply(env, p, r, isNew, budget) {
  const warn = [], has = (k) => r[k] !== undefined && r[k] !== null;
  const nm = has("name") ? r.name : r.n;
  if (nm !== undefined && nm !== null) { const v = clean(nm, 120).trim(); if (v.length < 2) return { err: "name: nom juda qisqa" }; p.n = v; } else if (isNew) return { err: "name: nom kerak" };
  const pr = has("price") ? r.price : r.som;
  if (pr !== undefined && pr !== null && pr !== "") { const v = Math.round(Number(String(pr).replace(/[\s,]/g, ""))); if (!(v >= 1000 && v <= 500000000)) return { err: "price: so'mda 1000 dan 500000000 gacha" }; p.som = v; } else if (isNew) return { err: "price: narx kerak" };
  const ct = has("category") ? r.category : r.c;
  if (ct !== undefined && ct !== null) { const v = impCat(ct); if (!v) return { err: "category: gadjet, kompyuter, bolalar, kiyim, uy, gozal, sport, avto" }; p.c = v; } else if (isNew) return { err: "category kerak" };
  if (has("kg")) { const v = Number(String(r.kg).replace(",", ".")); if (!(v > 0 && v <= 50)) return { err: "kg: 0 dan 50 gacha" }; p.kg = v; }
  const sz = has("sizes") ? r.sizes : r.olcham;
  if (sz !== undefined && sz !== null) p.olcham = (Array.isArray(sz) ? sz : String(sz).split(/[;,|]/)).map((x) => clean(x, 20).trim()).filter(Boolean).slice(0, 20);
  const ds = has("description") ? r.description : r.d;
  if (ds !== undefined && ds !== null) { const v = clean(ds, 3000).trim(); if (v) p.d = v; else delete p.d; }
  const sk = r.stock !== undefined ? r.stock : r.st;
  let stockSet = false;
  if (sk !== undefined) {
    if (sk === null || sk === "") delete p.st;
    else { const v = Number(sk); if (!(Number.isInteger(v) && v >= 0 && v <= 999999)) return { err: "stock: butun son 0 dan" }; p.st = v; stockSet = true; }
  }
  if (r.colors !== undefined && r.colors !== null) {
    const arr = (Array.isArray(r.colors) ? r.colors : String(r.colors).split(/[;,|]/)).slice(0, 12), out = [], seen = new Set();
    for (const c of arr) {
      const n = clean(c && typeof c === "object" ? c.name || c.n : c, 30).trim();
      if (!n || seen.has(n)) continue;
      seen.add(n);
      const prev = (p.colors || []).find((x) => x.n === n);
      let media = prev ? prev.media || [] : [];
      if (c && typeof c === "object" && c.images !== undefined) { const im = await apiImages(env, c.images, budget); media = im.media; warn.push(...im.warn); }
      out.push({ n: n, media: media });
    }
    p.colors = out;
  }
  if (r.images !== undefined || r.addImages !== undefined || Array.isArray(r.removeImages)) {
    const vids = (p.media || []).filter((m) => m.t !== "i");
    let cur = (p.media || []).filter((m) => m.t === "i");
    if (r.images !== undefined) { const im = await apiImages(env, r.images, budget); cur = im.media; warn.push(...im.warn); }
    if (r.addImages !== undefined) { const im = await apiImages(env, r.addImages, budget); cur = cur.concat(im.media); warn.push(...im.warn); }
    if (Array.isArray(r.removeImages)) cur = cur.filter((m) => r.removeImages.indexOf(m.f) < 0);
    p.media = cur.concat(vids);
  }
  if (r.hidden !== undefined) p.hidden = !!r.hidden;
  else if (stockSet) p.hidden = p.st === 0;
  if (isNew) { p.draft = false; if (p.hidden === undefined) p.hidden = false; }
  norm(p);
  return { warn: warn };
}
async function apiUpload(request, env) {
  const ct = (request.headers.get("Content-Type") || "").split(";")[0].trim().toLowerCase();
  const ext = { "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif" }[ct];
  if (!ext) return json({ ok: false, error: "type", hint: "Content-Type: image/jpeg, image/png, image/webp yoki image/gif" }, 415, "*");
  const buf = await request.arrayBuffer();
  if (buf.byteLength < 100) return json({ ok: false, error: "empty" }, 400, "*");
  if (buf.byteLength > 9 * 1024 * 1024) return json({ ok: false, error: "size", hint: "9 MB dan kichik rasm yuboring" }, 413, "*");
  const send = async (method, field, fname) => {
    const fd = new FormData();
    fd.append("chat_id", String(env.CHAT_ID)); fd.append("disable_notification", "true");
    fd.append(field, new Blob([buf], { type: ct }), fname);
    return fetch("https://api.telegram.org/bot" + env.BOT_TOKEN + "/" + method, { method: "POST", body: fd }).then((x) => x.json()).catch(() => null);
  };
  let r = await send("sendPhoto", "photo", "p." + ext), fid = "", mid = 0;
  if (r && r.ok && r.result && Array.isArray(r.result.photo) && r.result.photo.length) { fid = r.result.photo[r.result.photo.length - 1].file_id; mid = r.result.message_id; }
  else {
    r = await send("sendDocument", "document", "p." + ext);
    if (r && r.ok && r.result && r.result.document) { fid = r.result.document.file_id; mid = r.result.message_id; }
  }
  if (!fid) return json({ ok: false, error: "telegram" }, 502, "*");
  try { await tg(env, "deleteMessage", { chat_id: env.CHAT_ID, message_id: mid }); } catch (e) { /* tozalash ixtiyoriy */ }
  return json({ ok: true, f: fid, url: new URL(request.url).origin + "/m/" + fid }, 200, "*");
}
async function apiAdmin(request, env, url) {
  const au = await apiAuth(request, env);
  if (!au) return json({ ok: false, error: "auth" }, 401, "*");
  const p = url.pathname, m = request.method;
  if (p === "/api/admin/ping" && m === "GET") return json({ ok: true, via: au.via }, 200, "*");
  if (p === "/api/admin/upload" && m === "POST") return apiUpload(request, env);
  if (p === "/api/admin/inbox" && m === "GET") {
    const ls = await env.PRODUCTS.list({ prefix: "pcq:" }), out = [];
    for (const k of ls.keys.slice(0, 5)) { const v = await env.PRODUCTS.get(k.name, "json"); if (v) out.push({ key: k.name, t: v.t, folders: v.folders }); }
    return json({ ok: true, base: url.origin, batches: out }, 200, "*");
  }
  if (p === "/api/admin/inbox/ack" && m === "POST") {
    const b = (await readJson(request, 5000)) || {}, keys = (Array.isArray(b.keys) ? b.keys : []).filter((k) => /^pcq:[a-z0-9]{1,20}$/.test(k)).slice(0, 10);
    for (const k of keys) await env.PRODUCTS.delete(k);
    if (keys.length) await say(env, "💻 Kompyuter qabul qildi: " + (Number(b.folders) || 0) + " ta papka, " + (Number(b.images) || 0) + " ta rasm ✅");
    return json({ ok: true }, 200, "*");
  }
  if (p === "/api/admin/products" && m === "GET") {
    const q = String(url.searchParams.get("q") || "").trim().toLowerCase().slice(0, 200);
    const limit = Math.min(300, Math.max(1, Number(url.searchParams.get("limit")) || 100)), offset = Math.max(0, Number(url.searchParams.get("offset")) || 0);
    let items = (await getList(env)).slice().sort((a, b) => b.id - a.id);
    if (q) {
      const mid = q.match(/(?:[?&]p=|#p|start=p|^p)(\d{1,7})\b/) || q.match(/^(\d{1,7})$/);
      items = mid ? items.filter((x) => x.id === Number(mid[1])) : items.filter((x) => String(x.n || "").toLowerCase().indexOf(q) >= 0);
    }
    const bot = await botName(env);
    return json({ ok: true, total: items.length, products: items.slice(offset, offset + limit).map((x) => apiView(env, x, bot)) }, 200, "*");
  }
  if (p === "/api/admin/products" && m === "POST") {
    const body = await readJson(request, 400000);
    if (!body) return json({ ok: false, error: "json" }, 400, "*");
    const rows = (Array.isArray(body) ? body : Array.isArray(body.products) ? body.products : [body]).slice(0, 20);
    const dup = body && body.onDuplicate === "update" ? "update" : body && body.onDuplicate === "create" ? "create" : "skip";
    const items = await getList(env), bot = await botName(env), budget = { n: 12 }, out = [];
    const byName = new Map(items.map((x) => [impKey(x.n), x]));
    let nid = items.reduce((mx, x) => Math.max(mx, x.id), 0) + 1, changed = false;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i] && typeof rows[i] === "object" ? rows[i] : {};
      try {
        const name = clean(r.name !== undefined ? r.name : r.n, 120).trim(), old = name ? byName.get(impKey(name)) : null;
        if (old && dup === "skip") { out.push({ index: i, status: "exists", id: old.id, product: apiView(env, old, bot) }); continue; }
        if (old && dup === "update") {
          const res = await apiApply(env, old, r, false, budget);
          if (res.err) { out.push({ index: i, status: "error", error: res.err }); continue; }
          changed = true; out.push({ index: i, status: "updated", id: old.id, warn: res.warn, product: apiView(env, old, bot) }); continue;
        }
        const np = { id: nid, n: "", som: 0, y: 0, kg: 0.5, c: "", olcham: [], colors: [], rang: [], av: false, b: BG[nid % BG.length], s: 0, media: [] };
        const res = await apiApply(env, np, r, true, budget);
        if (res.err) { out.push({ index: i, status: "error", error: res.err }); continue; }
        nid++; items.push(np); byName.set(impKey(np.n), np); changed = true;
        out.push({ index: i, status: "created", id: np.id, warn: res.warn, product: apiView(env, np, bot) });
      } catch (e) { out.push({ index: i, status: "error", error: "ichki xato" }); }
    }
    if (changed) await saveList(env, items);
    return json({ ok: true, results: out }, 200, "*");
  }
  const mm = p.match(/^\/api\/admin\/products\/(\d{1,7})$/);
  if (mm) {
    const id = Number(mm[1]), items = await getList(env), cur = items.find((x) => x.id === id);
    if (!cur) return json({ ok: false, error: "notfound" }, 404, "*");
    const bot = await botName(env);
    if (m === "GET") return json({ ok: true, product: apiView(env, cur, bot) }, 200, "*");
    if (m === "PATCH" || m === "PUT") {
      const body = await readJson(request, 400000);
      if (!body || typeof body !== "object") return json({ ok: false, error: "json" }, 400, "*");
      const res = await apiApply(env, cur, body, false, { n: 12 });
      if (res.err) return json({ ok: false, error: res.err }, 400, "*");
      await saveList(env, items);
      return json({ ok: true, warn: res.warn, product: apiView(env, cur, bot) }, 200, "*");
    }
    if (m === "DELETE") { await saveList(env, items.filter((x) => x.id !== id)); return json({ ok: true, deleted: id }, 200, "*"); }
  }
  return json({ ok: false, error: "route" }, 404, "*");
}

// Tovar havolasi (t.me/BOT?start=p123): tovar kartochkasi + Mini App tugmasi
async function sendProductCard(env, chatId, id, origin) {
  const items = await getListPub(env), p = items.find((x) => x.id === id && !x.hidden && !x.draft), site = vSite(env);
  if (!p) return csay(env, chatId, "Bu tovar topilmadi yoki hozir sotuvda yo'q.", { reply_markup: { inline_keyboard: [[{ text: "🛍 Do'konni ochish", web_app: { url: site } }]] } });
  const st = await getSettingsPub(env), price = priceOf(p, st);
  const text = "🛍 " + p.n + "\n💰 " + String(price).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " so'm" + (p.d ? "\n\n" + String(p.d).slice(0, 600) : "");
  const kb = { inline_keyboard: [[{ text: "🛍 Do'konda ochish", web_app: { url: site + "?p=" + id } }]] };
  const fi = p.media.concat(...p.colors.map((c) => c.media)).find((x) => x.t === "i");
  if (fi) { const r = await ctg(env, "sendPhoto", { chat_id: chatId, photo: origin + "/m/" + fi.f, caption: text.slice(0, 1000), reply_markup: kb }); if (r && r.ok) return r; }
  return csay(env, chatId, text, { reply_markup: kb });
}

const PRODUCTS_HTML = "<!doctype html><html lang=\"uz\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><meta name=\"robots\" content=\"noindex\"><title>Tovarlar</title>\n<style>\n:root{--bg:#f4f5fb;--c:#fff;--t:#1B1D45;--m:#6b6f93;--p:#25308F;--ok:#1a8f4a;--er:#c62828;--ln:rgba(128,128,160,.28)}\n@media(prefers-color-scheme:dark){:root{--bg:#0B0D22;--c:#161938;--t:#eef0ff;--m:#9ba0cc;--p:#8f9bff}}\n*{box-sizing:border-box}body{margin:0;font:15px/1.45 system-ui,sans-serif;background:var(--bg);color:var(--t);padding:12px;max-width:900px;margin:auto}\n.c{background:var(--c);border-radius:14px;padding:14px;margin:0 0 12px;box-shadow:0 2px 10px rgba(0,0,0,.06)}\nh1{font-size:19px;margin:0 0 8px}h2{font-size:16px;margin:0 0 10px}a{color:var(--p)}\nbutton,select,input,textarea{font:inherit;padding:9px 11px;border-radius:10px;border:1px solid var(--m);background:var(--c);color:var(--t);max-width:100%}\ninput,textarea,select{width:100%}button{cursor:pointer;width:auto}button.p{background:var(--p);color:#fff;border:0;font-weight:600}button.d{color:var(--er);border-color:var(--er)}\n.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:6px 0}.row>input{flex:1;min-width:140px;width:auto}\n.it{display:flex;gap:10px;padding:10px 0;border-top:1px solid var(--ln);align-items:flex-start}.it img{width:56px;height:56px;object-fit:cover;border-radius:10px;background:var(--ln);flex:none}\n.it .i{flex:1;min-width:0}.it b{word-break:break-word}.m{color:var(--m);font-size:13px}.tag{display:inline-block;font-size:11px;padding:1px 7px;border-radius:9px;background:var(--ln);margin-left:4px}\n.g{display:grid;grid-template-columns:1fr 1fr;gap:8px}.g label,.f label{font-size:12.5px;color:var(--m);display:block;margin-bottom:2px}.f{margin:8px 0}\n.ph{display:flex;gap:8px;flex-wrap:wrap}.ph div{position:relative}.ph img{width:76px;height:76px;object-fit:cover;border-radius:10px}.ph button{position:absolute;top:-6px;right:-6px;padding:0;width:24px;height:24px;border-radius:50%;background:var(--er);color:#fff;border:0;line-height:24px}\n#tt{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#222;color:#fff;padding:9px 16px;border-radius:20px;display:none;z-index:9;font-size:14px}\n</style></head><body>\n<div class=\"c\"><h1>🛍 Tovarlar</h1><a href=\"/admin\">← Panel</a> · <a href=\"/admin/import\">📥 Import</a>\n<div class=\"row\"><input id=\"q\" placeholder=\"Nom, raqam yoki tovar havolasi\"><button class=\"p\" id=\"sb\">Qidirish</button><button id=\"nw\">➕ Yangi</button></div>\n<div id=\"info\" class=\"m\"></div><div id=\"ls\"></div></div>\n<div id=\"ed\"></div><div id=\"tt\"></div>\n<script>\nvar TOK=sessionStorage.getItem(\"adm\"),LIST=[],CUR=null,CATS=[[\"gadjet\",\"Gadjet\"],[\"kompyuter\",\"Kompyuter\"],[\"bolalar\",\"Bolalar\"],[\"kiyim\",\"Kiyim\"],[\"uy\",\"Uy-ro'zg'or\"],[\"gozal\",\"Go'zallik\"],[\"sport\",\"Sport\"],[\"avto\",\"Avto\"]];\nfunction $(i){return document.getElementById(i)}\nfunction E(s){var d=document.createElement(\"div\");d.textContent=s==null?\"\":String(s);return d.innerHTML.replace(/\"/g,\"&quot;\")}\nfunction fm(n){return String(n||0).replace(/\\B(?=(\\d{3})+(?!\\d))/g,\" \")}\nfunction tt(s){var t=$(\"tt\");t.textContent=s;t.style.display=\"block\";setTimeout(function(){t.style.display=\"none\"},2200)}\nfunction api(p,o){o=o||{};o.headers=Object.assign({\"X-Admin\":TOK||\"\"},o.headers||{});return fetch(p,o).then(function(r){return r.json().then(function(j){j._s=r.status;return j})})}\nfunction noauth(){$(\"ls\").innerHTML='<p class=\"er\" style=\"color:var(--er)\">Kirish tugagan. Admin botda /panel yuboring va havola orqali kiring: <a href=\"/admin\">/admin</a></p>'}\nfunction load(){$(\"info\").textContent=\"Yuklanmoqda…\";api(\"/api/admin/products?limit=200&q=\"+encodeURIComponent($(\"q\").value.trim())).then(function(j){\n if(j._s===401){noauth();$(\"info\").textContent=\"\";return}\n LIST=j.products||[];$(\"info\").textContent=\"Jami: \"+(j.total||0)+(j.total>LIST.length?\" (birinchi \"+LIST.length+\" ta)\":\"\");\n $(\"ls\").innerHTML=LIST.map(function(p,i){return '<div class=\"it\"><img src=\"'+(p.images[0]?\"/m/\"+E(p.images[0]):\"data:image/gif;base64,R0lGODlhAQABAAAAACw=\")+'\" alt=\"\"><div class=\"i\"><b>#'+p.id+\" \"+E(p.name)+\"</b>\"+(p.hidden?'<span class=\"tag\">yashirin</span>':\"\")+'<br><span class=\"m\">'+fm(p.price)+\" so'm · \"+E(p.category)+\" · ombor: \"+(p.stock==null?\"—\":p.stock)+'</span><div class=\"row\"><button data-a=\"ed\" data-i=\"'+i+'\">✏️ Tahrirlash</button><button data-a=\"cw\" data-i=\"'+i+'\">🔗 Havola</button><button data-a=\"ct\" data-i=\"'+i+'\">✈️ Telegram</button></div></div></div>'}).join(\"\")||'<p class=\"m\">Tovar topilmadi</p>'}).catch(function(){$(\"info\").textContent=\"Tarmoq xatosi\"})}\nfunction cp(t){if(!t){tt(\"Havola yo'q (bot nomi aniqlanmadi)\");return}(navigator.clipboard?navigator.clipboard.writeText(t):Promise.reject()).then(function(){tt(\"Nusxalandi ✅\")}).catch(function(){prompt(\"Nusxa oling:\",t)})}\n$(\"ls\").onclick=function(e){var b=e.target.closest(\"button\");if(!b)return;var p=LIST[+b.getAttribute(\"data-i\")],a=b.getAttribute(\"data-a\");if(a===\"ed\")edit(p);if(a===\"cw\")cp(p.link);if(a===\"ct\")cp(p.tgLink)};\n$(\"sb\").onclick=load;$(\"q\").onkeydown=function(e){if(e.key===\"Enter\")load()};$(\"nw\").onclick=function(){edit(null)};\nfunction edit(p){CUR=p?JSON.parse(JSON.stringify(p)):{id:0,name:\"\",category:\"gadjet\",price:\"\",kg:0.5,colors:[],sizes:[],stock:null,description:\"\",images:[],hidden:false};\n var c=CUR;$(\"ed\").innerHTML='<div class=\"c\"><h2>'+(c.id?\"✏️ Tovar #\"+c.id:\"➕ Yangi tovar\")+'</h2>'+\n (c.id?'<div class=\"m\">Havola: <a href=\"'+E(c.link)+'\" target=\"_blank\">'+E(c.link)+'</a></div>':\"\")+\n '<div class=\"f\"><label>Nomi</label><input id=\"e_n\" value=\"'+E(c.name)+'\"></div>'+\n '<div class=\"g\"><div class=\"f\"><label>Narx (so\\'m)</label><input id=\"e_p\" inputmode=\"numeric\" value=\"'+E(c.price||\"\")+'\"></div><div class=\"f\"><label>Kategoriya</label><select id=\"e_c\">'+CATS.map(function(x){return '<option value=\"'+x[0]+'\"'+(x[0]===c.category?\" selected\":\"\")+\">\"+x[1]+\"</option>\"}).join(\"\")+'</select></div>'+\n '<div class=\"f\"><label>Vazn (kg)</label><input id=\"e_k\" inputmode=\"decimal\" value=\"'+E(c.kg)+'\"></div><div class=\"f\"><label>Ombor soni (bo\\'sh = cheksiz, 0 = yashirin)</label><input id=\"e_s\" inputmode=\"numeric\" value=\"'+(c.stock==null?\"\":c.stock)+'\"></div></div>'+\n '<div class=\"f\"><label>Ranglar (vergul bilan)</label><input id=\"e_r\" value=\"'+E(c.colors.map(function(x){return x.name}).join(\", \"))+'\"></div>'+\n '<div class=\"f\"><label>O\\'lchamlar (vergul bilan)</label><input id=\"e_o\" value=\"'+E((c.sizes||[]).join(\", \"))+'\"></div>'+\n '<div class=\"f\"><label>Tavsif</label><textarea id=\"e_d\" rows=\"4\">'+E(c.description)+'</textarea></div>'+\n '<div class=\"f\"><label><input type=\"checkbox\" id=\"e_h\" style=\"width:auto\"'+(c.hidden?\" checked\":\"\")+'> Saytda yashirish</label></div>'+\n '<div class=\"f\"><label>Rasmlar</label><div class=\"ph\" id=\"e_i\"></div><div class=\"row\"><input type=\"file\" id=\"e_f\" accept=\"image/*\" multiple></div></div>'+\n '<div class=\"row\"><button class=\"p\" id=\"e_save\">Saqlash</button>'+(c.id?'<button class=\"d\" id=\"e_del\">🗑 O\\'chirish</button>':\"\")+'<button id=\"e_x\">Yopish</button></div><div id=\"e_m\" class=\"m\"></div></div>';\n imgs();$(\"e_x\").onclick=function(){$(\"ed\").innerHTML=\"\";CUR=null};$(\"e_save\").onclick=save;if($(\"e_del\"))$(\"e_del\").onclick=del;\n $(\"e_f\").onchange=function(){var fs=[].slice.call(this.files),n=0;$(\"e_m\").textContent=\"Rasm yuklanmoqda…\";\n  (function nx(){var f=fs.shift();if(!f){$(\"e_m\").textContent=n?n+\" ta rasm qo'shildi. «Saqlash» ni bosing.\":\"\";return}\n   if(f.size>9*1024*1024){tt(\"9 MB dan katta: \"+f.name);return nx()}\n   fetch(\"/api/admin/upload\",{method:\"POST\",headers:{\"X-Admin\":TOK||\"\",\"Content-Type\":f.type||\"image/jpeg\"},body:f}).then(function(r){return r.json()}).then(function(j){if(j&&j.ok){CUR.images.push(j.f);n++;imgs()}else tt(\"Yuklanmadi: \"+f.name);nx()}).catch(function(){tt(\"Tarmoq xatosi\");nx()})})()};\n $(\"ed\").scrollIntoView({behavior:\"smooth\"})}\nfunction imgs(){$(\"e_i\").innerHTML=CUR.images.map(function(f,i){return '<div><img src=\"/m/'+E(f)+'\" alt=\"\"><button data-i=\"'+i+'\">✕</button></div>'}).join(\"\")||'<span class=\"m\">Rasm yo\\'q</span>';\n $(\"e_i\").onclick=function(e){var b=e.target.closest(\"button\");if(b){CUR.images.splice(+b.getAttribute(\"data-i\"),1);imgs()}}}\nfunction lst(s){return s.split(/[;,|]/).map(function(x){return x.trim()}).filter(Boolean)}\nfunction save(){var c=CUR,sv=$(\"e_s\").value.trim(),pl={name:$(\"e_n\").value.trim(),category:$(\"e_c\").value,price:$(\"e_p\").value.replace(/\\s/g,\"\"),kg:$(\"e_k\").value.replace(\",\",\".\"),colors:lst($(\"e_r\").value),sizes:lst($(\"e_o\").value),stock:sv===\"\"?null:Number(sv),description:$(\"e_d\").value.trim(),hidden:$(\"e_h\").checked,images:c.images};\n $(\"e_save\").disabled=true;$(\"e_m\").textContent=\"Saqlanmoqda…\";\n var rq=c.id?api(\"/api/admin/products/\"+c.id,{method:\"PATCH\",headers:{\"Content-Type\":\"application/json\"},body:JSON.stringify(pl)}):api(\"/api/admin/products\",{method:\"POST\",headers:{\"Content-Type\":\"application/json\"},body:JSON.stringify({products:[pl],onDuplicate:\"skip\"})});\n rq.then(function(j){$(\"e_save\").disabled=false;var pr=c.id?j.product:(j.results&&j.results[0]);\n  if(j._s===401){noauth();return}\n  if(!j.ok||(pr&&pr.status===\"error\")){$(\"e_m\").innerHTML='<span style=\"color:var(--er)\">Xato: '+E(j.error||(pr&&pr.error)||j._s)+\"</span>\";return}\n  if(pr&&pr.status===\"exists\"){$(\"e_m\").innerHTML='<span style=\"color:var(--er)\">Bu nomli tovar bor: #'+pr.id+\"</span>\";return}\n  tt(\"Saqlandi ✅ (saytda 1 daqiqagacha kechikishi mumkin)\");$(\"ed\").innerHTML=\"\";CUR=null;load()}).catch(function(){$(\"e_save\").disabled=false;$(\"e_m\").textContent=\"Tarmoq xatosi\"})}\nfunction del(){var c=CUR;if(!c.id||!confirm(\"#\"+c.id+\" tovar butunlay o'chirilsinmi? (Yashirish xavfsizroq)\"))return;\n api(\"/api/admin/products/\"+c.id,{method:\"DELETE\"}).then(function(j){if(j.ok){tt(\"O'chirildi\");$(\"ed\").innerHTML=\"\";CUR=null;load()}else tt(\"Xato\")})}\nif(!TOK)noauth();else load();\n</script></body></html>\n";

async function vRoute(request, env, url, origin) {
  const p = url.pathname;
  if (p.startsWith("/api/admin/")) return apiAdmin(request, env, url);
  if (p === "/admin/products" && request.method === "GET") return new Response(PRODUCTS_HTML, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'" } });
  if (p === "/verify-webhook" && request.method === "POST") return handleVerifyWebhook(request, env);
  if (p === "/setup-verify" && request.method === "GET") {
    if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
    const r = env.ADMIN_BOT_TOKEN ? await vtg(env, "setWebhook", { url: url.origin + "/verify-webhook", secret_token: env.WEBHOOK_SECRET, allowed_updates: ["message", "callback_query"] }) : { ok: true, note: "mavjud admin bot ishlatiladi, webhook o'zgarmadi" };
    await ctg(env, "setMyCommands", { commands: [{ command: "verify", description: "Verifikatsiya holati" }] }); // mijoz botiga faqat buyruq qo'shiladi, token/webhook o'zgarmaydi
    if (env.ADMIN_BOT_TOKEN) await vtg(env, "setMyCommands", { commands: [{ command: "panel", description: "Admin panel" }, { command: "pending", description: "Kutilayotgan so'rovlar" }] });
    return json(r, 200, origin);
  }
  if (p === "/admin" && request.method === "GET") return new Response(ADMIN_HTML, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'" } });
  if (p === "/admin/exchange" && request.method === "POST") {
    if (isLimited(request, "admx", 10)) return json({ ok: false, error: "rate" }, 429, "*");
    const b = (await readJson(request, 2000)) || {}, code = String(b.code || "").replace(/[^a-z0-9]/g, "");
    const c = code ? await env.PRODUCTS.get("adm:c:" + code, "json") : null;
    if (!c || !vIsAdmin(env, c.tg)) return json({ ok: false, error: "code" }, 403, "*");
    await env.PRODUCTS.delete("adm:c:" + code); // bir martalik
    const tok = randomId(40);
    await env.PRODUCTS.put("adm:s:" + tok, JSON.stringify({ tg: c.tg }), { expirationTtl: 7200 });
    await vAudit(env, c.tg, "admin_login", "", "");
    return json({ ok: true, token: tok }, 200, "*");
  }
  if (p === "/admin/import" && request.method === "GET") return new Response(IMPORT_HTML, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'self'; script-src 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'" } });
  if (p === "/admin/api/import" && request.method === "POST") return handleImport(request, env);
  if (p.startsWith("/admin/api/")) { if (!env.DB) return json({ ok: false, error: "config" }, 503, "*"); return vAdminApi(request, env, url); }
  if (p.startsWith("/verify/") || p.startsWith("/badge/") || p.startsWith("/review/") || p === "/reviews" || p === "/review-img") return vCustomerApi(request, env, url, origin);
  return null;
}
// Saqlash muddati: tasdiqlangan hujjat 30 kun, rad etilgan 7 kun, hal qilinmagan 90 kundan keyin xavfsiz o'chiriladi (Cron Trigger orqali)
async function vRetention(env) {
  if (!env.DB) return;
  const now = Date.now(), cond = "((status='approved' AND decided_at<?1) OR (status='rejected' AND decided_at<?2) OR (status IN ('pending','need_info') AND created_at<?3)) AND purged_at IS NULL";
  const args = [now - 30 * 864e5, now - 7 * 864e5, now - 90 * 864e5];
  await env.DB.batch([
    env.DB.prepare("DELETE FROM verification_files WHERE vid IN (SELECT id FROM verifications WHERE " + cond + ")").bind(...args),
    env.DB.prepare("UPDATE verifications SET num_enc=NULL,purged_at=?4 WHERE " + cond).bind(...args, now),
  ]);
}
// ---------- END VERIFIKATSIYA MODULI ----------

const app = {
  async fetch(request, env, ctx) {
    const origin = env.ALLOWED_ORIGIN || "*", url = new URL(request.url);
    if (request.method === "OPTIONS") return json({}, 204, origin);

    // Tezlik limiti: bitta IP juda ko'p so'rov yuborsa to'xtatiladi
    const rule = rateRule(request.method, url.pathname);
    if (rule && isLimited(request, rule[0], rule[1])) {
      const rl = json({ ok: false, error: "rate" }, 429, origin);
      rl.headers.set("Retry-After", "30");
      return rl;
    }

    { const vr = await vRoute(request, env, url, origin); if (vr) return vr; }

    // Tekshiruv: brauzerda /ping ni oching
    if (url.pathname === "/ping") {
      let kv = false;
      try { kv = !!env.PRODUCTS && (await env.PRODUCTS.get("settings")) !== undefined; } catch (e) { kv = false; }
      if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return json({ ok: true }, 200, origin);
      return json({ ok: true, kv: kv, bot: !!env.BOT_TOKEN, chat: !!env.CHAT_ID, secret: !!env.WEBHOOK_SECRET, customerBot: !!(env.SHOP_BOT_TOKEN || env.CUSTOMER_BOT_TOKEN), origin: env.ALLOWED_ORIGIN || null, v: 6 }, 200, origin);
    }

    if (url.pathname === "/setup" && request.method === "GET") {
      if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
      return json(await tg(env, "setWebhook", { url: url.origin + "/webhook", secret_token: env.WEBHOOK_SECRET, allowed_updates: ["message", "callback_query"] }), 200, origin);
    }
    if (url.pathname === "/setup-customer" && request.method === "GET") {
      if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
      const swh = await ctg(env, "setWebhook", { url: url.origin + "/customer-webhook", secret_token: env.WEBHOOK_SECRET, allowed_updates: ["message"] });
      const smb = await ctg(env, "setChatMenuButton", { menu_button: { type: "web_app", text: "Do'konni ochish", web_app: { url: vSite(env) } } });
      try { await ctg(env, "setMyCommands", { commands: [{ command: "start", description: "Do'konni ochish" }] }); } catch (e) { /* ixtiyoriy */ }
      return json({ webhook: swh, menu: smb }, 200, origin);
    }
    if (url.pathname === "/webhook" && request.method === "POST") return handleWebhook(request, env);
    if (url.pathname === "/customer-webhook" && request.method === "POST") return handleCustomerWebhook(request, env);

    if (url.pathname === "/customer-bot" && request.method === "GET") {
      const uname = await memo("cbot", 600000, async () => {
        try { const me = await ctg(env, "getMe", {}); return me && me.ok ? me.result.username : ""; } catch (e) { return ""; }
      });
      return json({ username: uname || "" }, 200, origin, "public, max-age=300");
    }
    if (url.pathname === "/google-start" && request.method === "GET") return handleGoogleStart(env, url);
    if (url.pathname === "/yandex-start" && request.method === "GET") return handleYandexStart(env, url);
    if (url.pathname === "/yandex-cb" && request.method === "GET") return handleYandexCb(env, url);
    if (url.pathname === "/login-methods" && request.method === "GET") return json({ yandex: !!((env.YANDEX_CLIENT_ID || YANDEX_ID) && (env.YANDEX_CLIENT_SECRET || YANDEX_SECRET)) }, 200, origin, "public, max-age=60");
    if (url.pathname === "/google-cb" && request.method === "POST") return handleGoogleCb(request, env);
    if (url.pathname === "/login-status" && request.method === "GET") {
      const v = await env.PRODUCTS.get("login:" + (url.searchParams.get("id") || ""), "json");
      if (!v) return json({ pending: true }, 200, origin);
      await env.PRODUCTS.delete("login:" + url.searchParams.get("id"));
      if (v.needPhone) return json({ ok: true, needPhone: true, ptoken: v.ptoken, name: v.name }, 200, origin);
      return json({ ok: true, token: v.token, name: v.name }, 200, origin);
    }
    if (url.pathname === "/login-exchange" && request.method === "POST") {
      if (origin !== "*" && (request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const xb = await readJson(request, 500);
      const code = String((xb && xb.code) || "").replace(/[^a-z0-9]/g, "").slice(0, 40);
      if (code.length < 16) return json({ ok: false }, 400, origin);
      const v = await env.PRODUCTS.get("lc:" + code, "json");
      if (!v || !v.token) return json({ ok: false, pending: true }, 200, origin);
      await env.PRODUCTS.delete("lc:" + code);
      return json({ ok: true, token: v.token, name: v.name }, 200, origin);
    }
    if (url.pathname === "/me" && request.method === "GET") {
      const sess = await getSession(env, tokenOf(request, url));
      if (!sess) return json({ ok: false }, 401, origin);
      const sp = String(sess.name || "").split(" ");
      const pwrec = sess.phone ? await pwAccount(env, normPhone(sess.phone)) : null;
      return json({ ok: true, m: sess.m, cur: sess.cur, lt: !!(sess.m && sess.m.t), lg: !!(sess.m && (sess.m.g || sess.m.y)), pwSet: !!(pwrec && pwOwnerMatches(pwrec, sess)), name: sess.name, phone: sess.phone, first: sess.f !== undefined ? sess.f : sp[0] || "", last: sess.l !== undefined ? sess.l : sp.slice(1).join(" "), email: sess.email || "" }, 200, origin);
    }
    if (url.pathname === "/my-orders" && request.method === "GET") {
      const sess = await getSession(env, tokenOf(request, url));
      if (!sess) return json({ ok: false }, 401, origin);
      const mine = (await getOrdersMemo(env)).filter((o) => (sess.tgId && o.tg === sess.tgId) || ownsG(sess, o)).slice(0, 30);
      const ownerM = ownerOf(sess);
      if (ownerM) {
        // umumiy ro'yxatdan tushib qolgan eski buyurtmalar mijozning shaxsiy indeksi orqali topiladi (guruhdagi hamma kalit)
        let ids = [];
        for (const ok of ownersOf(sess)) { const part = (await env.PRODUCTS.get("oi:" + ok, { type: "json", cacheTtl: 30 })) || []; ids = ids.concat(part); }
        const have = new Set(mine.map((o) => String(o.id)));
        for (const id of ids.slice(0, 30)) {
          if (mine.length >= 30) break;
          if (have.has(String(id))) continue;
          const ob = await env.PRODUCTS.get("ob:" + id, "json");
          if (ob) { mine.push(ob); have.add(String(id)); }
        }
        mine.sort((a, b) => (b.t || 0) - (a.t || 0));
      }
      return json(mine.map((o) => ({ id: o.id, status: o.status, total: o.total, t: o.t, summary: o.summary, trk: o.trk || "", uzp: o.uzp || "" })), 200, origin);
    }
    if (url.pathname === "/chat" && request.method === "GET") {
      const sess = await getSession(env, (tokenOf(request, url) || "").replace(/[^a-z0-9]/g, ""));
      const th = await threadFor(env, sess, url.searchParams.get("oid") || "gen");
      if (!th) return json({ ok: false }, 401, origin);
      const c = await getChat(env, th.key);
      return json({ ok: true, m: c ? c.m : [] }, 200, origin);
    }
    if (url.pathname === "/chat-unread" && request.method === "GET") {
      const sess = await getSession(env, (tokenOf(request, url) || "").replace(/[^a-z0-9]/g, ""));
      const owner = sess ? ownerOf(sess) : "";
      if (!owner) return json({ ok: false }, 401, origin);
      const cu = (await env.PRODUCTS.get("cu:" + owner, { type: "json", cacheTtl: 30 })) || {}, out = {};
      Object.keys(cu).forEach((k) => { out[k.indexOf("gen-") === 0 ? "gen" : k] = cu[k]; });
      return json({ ok: true, cu: out }, 200, origin);
    }
    if (url.pathname === "/push-key" && request.method === "GET") return json({ key: env.VAPID_PUBLIC || "" }, 200, origin, "public, max-age=3600");
    if (url.pathname === "/push-keygen" && request.method === "GET") {
      if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
      const kp = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign"]);
      const jwk = await crypto.subtle.exportKey("jwk", kp.privateKey);
      return json({ VAPID_PUBLIC: b64u(await crypto.subtle.exportKey("raw", kp.publicKey)), VAPID_PRIVATE: jwk.d }, 200, origin);
    }
    if (request.method === "POST" && url.pathname === "/push-sub") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let pb2;
      pb2 = await readJson(request, 20000); if (!pb2) return json({ ok: false, error: "json" }, 400, origin);
      return handlePushSub(env, pb2, origin);
    }
    if (url.pathname === "/ref-info" && request.method === "GET") return handleRefInfo(env, tokenOf(request, url), origin);
    if (request.method === "POST" && url.pathname === "/ref-claim") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let rb;
      rb = await readJson(request, 20000); if (!rb) return json({ ok: false, error: "json" }, 400, origin);
      return handleRefClaim(env, rb, origin);
    }
    if (url.pathname === "/uzpost-offices" && request.method === "GET") return uzpostOffices(env, origin);
    // Monitoring uchun (UptimeRobot): KV va Telegram ishlayaptimi
    if (url.pathname === "/health" && request.method === "GET") {
      const good = await memo("health", 30000, async () => {
        try { await env.PRODUCTS.get("settings"); const me = await tg(env, "getMe", {}); return me && me.ok ? "ok" : ""; } catch (e) { return ""; }
      });
      return json({ ok: !!good }, good ? 200 : 503, origin);
    }
    // Zaxira nusxani hoziroq Telegramga yuborish: /backup?key=WEBHOOK_SECRET
    if (url.pathname === "/backup" && request.method === "GET") {
      if (url.searchParams.get("key") !== env.WEBHOOK_SECRET) return new Response("forbidden", { status: 403 });
      return json(await backupToTelegram(env), 200, origin);
    }
    if (request.method === "POST" && url.pathname === "/logout") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const lb = await readJson(request, 2000);
      const tk = String((lb && lb.token) || "").replace(/[^a-z0-9]/g, "");
      if (tk) await env.PRODUCTS.delete("sess:" + tk);
      return json({ ok: true }, 200, origin);
    }
    // Tovarlar va sozlamalar: Worker xotirasida 20 soniya, brauzer/CDN da 15-30 soniya saqlanadi (katta kampaniyada KV va CPU tejaladi)
    if (url.pathname === "/products" && request.method === "GET") {
      // Sayt tayyor narxni oladi: yuan narxi, kurs va ustama foizi (tannarx) ochiq berilmaydi
      const body = await memo("products", 20000, async () => {
        const st = await getSettingsPub(env);
        return JSON.stringify((await getListPub(env)).filter((p) => !p.hidden && !p.draft).map((p) => pubProduct(p, st)));
      });
      return json(body, 200, origin, "public, max-age=15, s-maxage=30, stale-while-revalidate=60");
    }
    if (url.pathname === "/settings" && request.method === "GET") {
      const body = await memo("settings", 20000, async () => {
        const s = await getSettingsPub(env);
        return JSON.stringify({ rate: 1, usd: s.usd, markup: 0, cargoAuto: s.cargoAuto, cargoAvia: s.cargoAvia, hideStatic: !!s.hideStatic, promos: s.promos });
      });
      return json(body, 200, origin, "public, max-age=15, s-maxage=30, stale-while-revalidate=60");
    }
    if ((url.pathname.startsWith("/m/") || url.pathname.startsWith("/img/")) && request.method === "GET") {
      return serveMedia(request, env, ctx, url.pathname.replace(/^\/(m|img)\//, ""));
    }
    if (request.method === "POST" && (url.pathname === "/google-login" || url.pathname === "/google-phone")) {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let gb;
      gb = await readJson(request, 20000); if (!gb) return json({ ok: false, error: "json" }, 400, origin);
      return url.pathname === "/google-login" ? handleGoogleLogin(env, gb, origin) : handleGooglePhone(env, gb, origin);
    }
    if (request.method === "POST" && ["/password-login", "/password-status", "/password-set", "/password-reset-request", "/password-reset-confirm"].includes(url.pathname)) {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const pbw = await readJson(request, 5000); if (!pbw) return json({ ok: false, error: "json" }, 400, origin);
      if (url.pathname === "/password-login") return handlePasswordLogin(env, pbw, origin);
      if (url.pathname === "/password-status") return handlePasswordStatus(env, pbw, origin);
      if (url.pathname === "/password-set") return handlePasswordSet(env, pbw, origin);
      if (url.pathname === "/password-reset-request") return handlePasswordResetRequest(env, pbw, origin);
      return handlePasswordResetConfirm(env, pbw, origin);
    }
    if (request.method === "POST" && url.pathname === "/chat-send") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let cb;
      cb = await readJson(request, 20000); if (!cb) return json({ ok: false, error: "json" }, 400, origin);
      return handleChatSend(env, cb, origin);
    }
    if (request.method === "POST" && url.pathname === "/unlink") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const ub = await readJson(request, 3000);
      if (!ub) return json({ ok: false, error: "json" }, 400, origin);
      return handleUnlink(env, ub, origin);
    }
    if (request.method === "POST" && url.pathname === "/link-start") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const lb = await readJson(request, 3000);
      if (!lb) return json({ ok: false, error: "json" }, 400, origin);
      return handleLinkStart(env, lb, origin);
    }
    if (request.method === "POST" && url.pathname === "/tg-login") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      const tb = await readJson(request, 6000);
      if (!tb) return json({ ok: false, error: "json" }, 400, origin);
      return handleTgLogin(env, tb, origin);
    }
    if (request.method === "POST" && url.pathname === "/profile") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let pb;
      pb = await readJson(request, 20000); if (!pb) return json({ ok: false, error: "json" }, 400, origin);
      return handleProfile(env, pb, origin);
    }
    if (request.method === "POST") {
      if ((request.headers.get("Origin") || "") !== origin) return json({ ok: false, error: "origin" }, 403, origin);
      let body;
      body = await readJson(request, 4000000); if (!body) return json({ ok: false, error: "json" }, 400, origin);
      return handleOrder(env, body, origin);
    }
    return new Response("not found", { status: 404 });
  },
};

// Har qanday xatoda ham CORS bilan javob beradi; barcha javoblarga xavfsizlik headerlari qo'shiladi
export default {
  async fetch(request, env, ctx) {
    let res;
    try { res = await app.fetch(request, env, ctx); }
    catch (e) {
      console.error("worker xato:", (e && e.message) || e); // xato matni mijozga emas, faqat Cloudflare logiga yoziladi
      res = json({ ok: false, error: "server" }, 500, env.ALLOWED_ORIGIN || "*");
    }
    const out = new Response(res.body, res);
    Object.keys(SEC_HEADERS).forEach((k) => out.headers.set(k, SEC_HEADERS[k]));
    return out;
  },
  // Cloudflare'da Cron Trigger qo'shilsa (masalan har kuni), zaxira nusxa avtomatik Telegramga keladi
  async scheduled(event, env, ctx) {
    ctx.waitUntil(backupToTelegram(env));
    ctx.waitUntil(vRetention(env));
  },
};
